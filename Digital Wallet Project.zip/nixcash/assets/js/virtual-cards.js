(function () {
    // Flip: tap/click the card (not action buttons). Nested 3D tilt was removed — it caused blank faces in many browsers.
    document.querySelectorAll(".js-card-wrap").forEach((wrap) => {
        const flipCard = wrap.querySelector(".js-flip-card");
        const flipBtn = wrap.querySelector(".js-flip-toggle");
        const scene = wrap.querySelector(".vcp-card-scene");
        if (!flipCard || !scene) return;

        scene.addEventListener("click", (e) => {
            const target = e.target;
            if (!(target instanceof Element)) return;
            if (target.closest("button, form, input, select, a")) return;
            if (wrap.getAttribute("data-card-blocked") === "1") return;
            flipCard.classList.toggle("is-flipped");
        });

        flipBtn?.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (wrap.getAttribute("data-card-blocked") === "1") return;
            flipCard.classList.toggle("is-flipped");
        });
    });

    // Copy currently visible number on card.
    document.querySelectorAll(".js-copy-number").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
            e.preventDefault();
            const wrap = btn.closest(".js-card-wrap");
            if (wrap?.getAttribute("data-card-blocked") === "1") return;
            const numberEl = wrap?.querySelector(".js-card-number");
            const value = numberEl?.textContent?.trim() || "";
            if (!value) return;
            try {
                await navigator.clipboard.writeText(value);
                const prev = btn.textContent || "Copy";
                btn.textContent = "Copied";
                setTimeout(() => {
                    btn.textContent = prev;
                }, 900);
            } catch (err) {
                window.alert("Copy failed");
            }
        });
    });

    const revealModalEl = document.getElementById("revealModal");
    const revealModal = revealModalEl ? new bootstrap.Modal(revealModalEl) : null;
    const revealForm = document.getElementById("revealForm");
    const revealCardId = document.getElementById("revealCardId");
    const revealPassword = document.getElementById("revealPassword");
    const revealError = document.getElementById("revealError");

    document.querySelectorAll(".js-show-details").forEach((btn) => {
        btn.addEventListener("click", () => {
            if (!window.nixVirtualCards?.revealEnabled) {
                window.alert("Card reveal is disabled for your account.");
                return;
            }
            const wrap = btn.closest(".js-card-wrap");
            if (wrap?.getAttribute("data-card-blocked") === "1") {
                window.alert("This card is suspended.");
                return;
            }
            const cardId = wrap?.getAttribute("data-card-id") || "";
            if (!cardId || !revealModal) return;
            revealCardId.value = cardId;
            revealPassword.value = "";
            revealError.textContent = "";
            revealError.classList.add("d-none");
            revealModal.show();
        });
    });

    revealForm?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const payload = new URLSearchParams({
            card_id: revealCardId.value,
            password: revealPassword.value,
        });
        try {
            const res = await fetch(window.nixVirtualCards.revealUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                    Accept: "application/json",
                    "X-Requested-With": "XMLHttpRequest",
                },
                body: payload.toString(),
                credentials: "same-origin",
            });
            const raw = await res.text();
            let data;
            try {
                data = JSON.parse(raw);
            } catch {
                revealError.textContent = "Server error. Try again or refresh the page.";
                revealError.classList.remove("d-none");
                return;
            }
            if (!data.ok) {
                revealError.textContent = data.message || "Password verification failed.";
                revealError.classList.remove("d-none");
                return;
            }

            const wrap = document.querySelector(`.js-card-wrap[data-card-id="${revealCardId.value}"]`);
            if (!wrap) {
                revealError.textContent = "Card not found on this page.";
                revealError.classList.remove("d-none");
                return;
            }
            const numberEl = wrap.querySelector(".js-card-number");
            const cvvEl = wrap.querySelector(".js-card-cvv");
            if (numberEl) numberEl.textContent = data.card_number;
            if (cvvEl) cvvEl.textContent = data.cvv;
            // Show CVV on the physical back face; flip so user immediately sees it.
            const flipCard = wrap.querySelector(".js-flip-card");
            if (flipCard) flipCard.classList.add("is-flipped");
            wrap.scrollIntoView({ behavior: "smooth", block: "nearest" });
            revealModal.hide();
        } catch (err) {
            revealError.textContent = "Unable to reveal card details.";
            revealError.classList.remove("d-none");
        }
    });
})();
