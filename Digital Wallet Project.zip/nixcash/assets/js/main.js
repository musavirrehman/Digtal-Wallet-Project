/**
 * NixCash — balance visibility (localStorage) + small UX helpers
 */
(function () {
  const KEY = 'nixcash_hide_balance';
  const THEME_KEY = 'nixcash_theme';

  function getCaptureBg() {
    try {
      var v = getComputedStyle(document.documentElement).getPropertyValue('--nix-capture-bg');
      v = (v || '').trim();
      return v || '#1e2329';
    } catch (e) {
      return '#1e2329';
    }
  }

  function syncThemeButtons() {
    var mode = document.documentElement.getAttribute('data-bs-theme') || 'dark';
    document.querySelectorAll('[data-nix-theme]').forEach(function (btn) {
      var t = btn.getAttribute('data-nix-theme');
      if (t !== 'light' && t !== 'dark') {
        return;
      }
      var on = t === mode;
      btn.classList.toggle('active', on);
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }

  function setTheme(mode) {
    if (mode !== 'light' && mode !== 'dark') {
      return;
    }
    document.documentElement.setAttribute('data-bs-theme', mode);
    try {
      localStorage.setItem(THEME_KEY, mode);
    } catch (e) {
      // ignore
    }
    syncThemeButtons();
  }

  function initNixTheme() {
    syncThemeButtons();
    document.querySelectorAll('[data-nix-theme]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var mode = btn.getAttribute('data-nix-theme');
        if (mode !== 'light' && mode !== 'dark') {
          return;
        }
        setTheme(mode);
        if (btn.closest('#nixMenu')) {
          var menu = document.getElementById('nixMenu');
          if (menu && typeof bootstrap !== 'undefined' && bootstrap.Offcanvas) {
            var oc = bootstrap.Offcanvas.getInstance(menu);
            if (oc) {
              oc.hide();
            }
          }
        }
      });
    });
  }

  function applyBalanceVisibility(hidden) {
    document.querySelectorAll('[data-balance-toggle]').forEach(function (root) {
      root.setAttribute('data-balance-hidden', hidden ? 'true' : 'false');
    });
    document.querySelectorAll('[data-balance-eye]').forEach(function (icon) {
      icon.classList.toggle('bi-eye-slash-fill', hidden);
      icon.classList.toggle('bi-eye-fill', !hidden);
    });
  }

  function initBalanceToggle() {
    var hidden = localStorage.getItem(KEY) === '1';
    applyBalanceVisibility(hidden);

    document.querySelectorAll('[data-balance-toggle-btn]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        hidden = !hidden;
        localStorage.setItem(KEY, hidden ? '1' : '0');
        applyBalanceVisibility(hidden);
      });
    });
  }

  function initQuickSend() {
    document.querySelectorAll('[data-send-email]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var em = btn.getAttribute('data-send-email');
        var nm = btn.getAttribute('data-send-name');
        var inp = document.getElementById('sendEmail');
        if (inp && em) {
          inp.value = em;
        }
        var hint = document.getElementById('sendRecipientHint');
        if (hint && em && nm) {
          hint.innerHTML =
            '<i class="bi bi-person-check me-1"></i>Recipient: <strong>' +
            escapeQuick(nm) +
            '</strong> <span class="text-muted">(' +
            escapeQuick(em) +
            ')</span>';
          hint.classList.remove('d-none');
        } else if (hint) {
          hint.classList.add('d-none');
          hint.innerHTML = '';
        }
      });
    });
  }

  function escapeQuick(s) {
    var d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
  }

  function initSendEmailSuggest() {
    var cfg = document.getElementById('nix-page-config');
    var baseUrl = cfg && cfg.getAttribute('data-user-suggest-url');
    if (!baseUrl) {
      return;
    }

    var input = document.getElementById('sendEmail');
    var box = document.getElementById('sendEmailSuggest');
    var hint = document.getElementById('sendRecipientHint');
    if (!input || !box) {
      return;
    }

    var debounceTimer = null;
    var lastPickedEmail = '';

    function hideSuggest() {
      box.classList.add('d-none');
      box.innerHTML = '';
    }

    function showHint(name, email) {
      if (!hint) {
        return;
      }
      hint.innerHTML =
        '<i class="bi bi-person-check me-1"></i>Recipient: <strong>' +
        escapeHtml(name) +
        '</strong> <span class="text-muted">(' +
        escapeHtml(email) +
        ')</span>';
      hint.classList.remove('d-none');
      lastPickedEmail = email;
    }

    function escapeHtml(s) {
      var d = document.createElement('div');
      d.textContent = s == null ? '' : String(s);
      return d.innerHTML;
    }

    function renderSuggestions(users) {
      box.innerHTML = '';
      users.forEach(function (u) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'list-group-item list-group-item-action nix-suggest-item';
        b.setAttribute('role', 'option');
        b.dataset.email = u.email;
        b.dataset.name = u.name;
        var t1 = document.createElement('div');
        t1.className = 'fw-medium';
        t1.textContent = u.name;
        var t2 = document.createElement('div');
        t2.className = 'text-muted';
        t2.style.fontSize = '0.8rem';
        t2.textContent = u.email;
        b.appendChild(t1);
        b.appendChild(t2);
        box.appendChild(b);
      });
      box.classList.remove('d-none');
    }

    input.addEventListener('input', function () {
      if (hint && input.value.trim() !== lastPickedEmail) {
        hint.classList.add('d-none');
        lastPickedEmail = '';
      }
      var q = input.value.trim();
      clearTimeout(debounceTimer);
      if (q.length < 2) {
        hideSuggest();
        return;
      }
      debounceTimer = setTimeout(function () {
        fetch(baseUrl + '?q=' + encodeURIComponent(q), { credentials: 'same-origin' })
          .then(function (r) {
            return r.json();
          })
          .then(function (data) {
            var users = data.users || [];
            if (users.length === 0) {
              hideSuggest();
              return;
            }
            renderSuggestions(users);
          })
          .catch(function () {
            hideSuggest();
          });
      }, 280);
    });

    box.addEventListener('click', function (e) {
      var btn = e.target.closest('.nix-suggest-item');
      if (!btn || !btn.dataset.email) {
        return;
      }
      input.value = btn.dataset.email;
      showHint(btn.dataset.name || '', btn.dataset.email);
      hideSuggest();
      input.focus();
    });

    document.addEventListener('click', function (e) {
      if (!input.contains(e.target) && !box.contains(e.target)) {
        hideSuggest();
      }
    });

    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        hideSuggest();
      }
    });
  }

  /**
   * Split bill member rows: fetch name + email suggestions (api/user-suggest.php).
   */
  function initSplitMemberEmailSuggest() {
    var cfg = document.getElementById('nix-page-config');
    var baseUrl = cfg && cfg.getAttribute('data-user-suggest-url');
    var container = document.getElementById('split_member_rows');
    if (!baseUrl || !container) {
      return;
    }

    var debouncers = new Map();

    function hideSuggestBox(box) {
      if (!box) {
        return;
      }
      box.classList.add('d-none');
      box.innerHTML = '';
    }

    function hideAllSuggestBoxes() {
      container.querySelectorAll('.nix-split-email-suggest').forEach(hideSuggestBox);
    }

    function renderInto(box, users) {
      container.querySelectorAll('.nix-split-email-suggest').forEach(function (bx) {
        if (bx !== box) {
          hideSuggestBox(bx);
        }
      });
      box.innerHTML = '';
      users.forEach(function (u) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'list-group-item list-group-item-action nix-suggest-item';
        b.setAttribute('role', 'option');
        b.dataset.email = u.email;
        b.dataset.name = u.name || '';
        var t1 = document.createElement('div');
        t1.className = 'fw-medium';
        t1.textContent = u.name || u.email;
        var t2 = document.createElement('div');
        t2.className = 'text-muted';
        t2.style.fontSize = '0.8rem';
        t2.textContent = u.email;
        b.appendChild(t1);
        b.appendChild(t2);
        box.appendChild(b);
      });
      box.classList.remove('d-none');
    }

    container.addEventListener('input', function (e) {
      var input = e.target.closest && e.target.closest('.split-member-email');
      if (!input) {
        return;
      }
      var wrap = input.closest('.position-relative');
      var box = wrap && wrap.querySelector('.nix-split-email-suggest');
      if (!box) {
        return;
      }
      var prev = debouncers.get(input);
      if (prev) {
        clearTimeout(prev);
      }
      var q = input.value.trim();
      if (q.length < 2) {
        hideSuggestBox(box);
        debouncers.delete(input);
        return;
      }
      var tid = setTimeout(function () {
        debouncers.delete(input);
        fetch(baseUrl + '?q=' + encodeURIComponent(q), { credentials: 'same-origin' })
          .then(function (r) {
            return r.json();
          })
          .then(function (data) {
            var users = data.users || [];
            if (users.length === 0) {
              hideSuggestBox(box);
              return;
            }
            renderInto(box, users);
          })
          .catch(function () {
            hideSuggestBox(box);
          });
      }, 280);
      debouncers.set(input, tid);
    });

    container.addEventListener('click', function (e) {
      var btn = e.target.closest('.nix-split-email-suggest .nix-suggest-item');
      if (!btn || !btn.dataset.email) {
        return;
      }
      var wrap = btn.closest('.position-relative');
      var inp = wrap && wrap.querySelector('.split-member-email');
      if (inp) {
        inp.value = btn.dataset.email;
      }
      hideSuggestBox(wrap && wrap.querySelector('.nix-split-email-suggest'));
      if (inp) {
        inp.focus();
      }
    });

    document.addEventListener('click', function (e) {
      if (!container.contains(e.target)) {
        hideAllSuggestBoxes();
      }
    });

    container.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') {
        return;
      }
      var input = e.target.closest && e.target.closest('.split-member-email');
      if (!input) {
        return;
      }
      var wrap = input.closest('.position-relative');
      hideSuggestBox(wrap && wrap.querySelector('.nix-split-email-suggest'));
    });
  }

  function loadHtml2Canvas(done, onFail) {
    if (typeof window.html2canvas === 'function') {
      done(window.html2canvas);
      return;
    }
    var existing = document.querySelector('script[data-lib="html2canvas"]');
    if (existing) {
      if (existing.getAttribute('data-loaded') === '1') {
        done(window.html2canvas);
      } else {
        existing.addEventListener('load', function () {
          done(window.html2canvas);
        });
        existing.addEventListener('error', function () {
          if (onFail) {
            onFail();
          }
        });
      }
      return;
    }
    var s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js';
    s.async = true;
    s.setAttribute('data-lib', 'html2canvas');
    s.onload = function () {
      s.setAttribute('data-loaded', '1');
      done(window.html2canvas);
    };
    s.onerror = function () {
      if (onFail) {
        onFail();
      }
      alert('Could not load image export. Please check your connection and try again.');
    };
    document.head.appendChild(s);
  }

  function triggerDownload(dataUrl, filename) {
    var a = document.createElement('a');
    a.href = dataUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  function bindReceiptImageExport(captureId, getPayload, btnPngId, btnJpgId) {
    function exportReceiptImage(format) {
      var cap = document.getElementById(captureId);
      if (!cap) {
        return;
      }
      var payload = typeof getPayload === 'function' ? getPayload() : null;
      if (!payload || typeof payload !== 'object') {
        return;
      }
      var btnPng = document.getElementById(btnPngId);
      var btnJpg = document.getElementById(btnJpgId);
      var activeBtn = format === 'jpg' ? btnJpg : btnPng;
      var busy = activeBtn;
      var prevHtml = busy ? busy.innerHTML : '';
      if (busy) {
        busy.disabled = true;
        busy.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Preparing…';
      }

      function resetBtn() {
        if (busy) {
          busy.disabled = false;
          busy.innerHTML = prevHtml;
        }
      }

      loadHtml2Canvas(
        function (html2canvas) {
          html2canvas(cap, {
            scale: 2,
            useCORS: true,
            allowTaint: false,
            backgroundColor: getCaptureBg(),
            logging: false,
            scrollX: 0,
            scrollY: -window.scrollY,
          })
            .then(function (canvas) {
              var base =
                'nixcash-receipt-' +
                String(payload.reference).replace(/[^a-z0-9-]/gi, '_').toLowerCase();
              if (format === 'jpg') {
                var jpgUrl = canvas.toDataURL('image/jpeg', 0.92);
                triggerDownload(jpgUrl, base + '.jpg');
              } else {
                var pngUrl = canvas.toDataURL('image/png');
                triggerDownload(pngUrl, base + '.png');
              }
            })
            .catch(function () {
              alert('Could not create the image. Try again or use another browser.');
            })
            .then(function () {
              resetBtn();
            });
        },
        function () {
          resetBtn();
        }
      );
    }

    var btnPng = document.getElementById(btnPngId);
    var btnJpg = document.getElementById(btnJpgId);
    if (btnPng) {
      btnPng.addEventListener('click', function () {
        exportReceiptImage('png');
      });
    }
    if (btnJpg) {
      btnJpg.addEventListener('click', function () {
        exportReceiptImage('jpg');
      });
    }
  }

  function syncBackdropZIndex() {
    document.querySelectorAll('.modal-backdrop').forEach(function (b) {
      // Keep backdrop below receipt modals (which use z-index 2000)
      b.style.zIndex = '1980';
    });
  }

  function cleanupModalState() {
    // In case Bootstrap leaves the page in a stuck state (mobile browsers / nested modals)
    document.querySelectorAll('.modal-backdrop').forEach(function (b) {
      b.parentNode && b.parentNode.removeChild(b);
    });
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('overflow');
    document.body.style.removeProperty('padding-right');
  }

  function hideBsModal(modalEl) {
    var BS = typeof bootstrap !== 'undefined' ? bootstrap : window.bootstrap;
    if (BS && BS.Modal) {
      var inst = BS.Modal.getOrCreateInstance(modalEl);
      inst.hide();
      return;
    }
    modalEl.classList.remove('show');
    modalEl.style.display = 'none';
    modalEl.setAttribute('aria-hidden', 'true');
    cleanupModalState();
  }

  var nixModalNav = {
    open: false,
    closing: false,
    el: null,
  };

  function enableBackToCloseOnce(modalEl) {
    if (!window.history || typeof window.history.pushState !== 'function') {
      return;
    }
    nixModalNav.open = true;
    nixModalNav.el = modalEl;
    window.history.pushState({ nixModal: true }, '');
  }

  function showBsModal(modalEl) {
    if (modalEl.parentNode !== document.body) {
      document.body.appendChild(modalEl);
    }
    var BS = typeof bootstrap !== 'undefined' ? bootstrap : window.bootstrap;
    if (!BS || !BS.Modal) {
      modalEl.classList.add('show');
      modalEl.style.display = 'block';
      modalEl.removeAttribute('aria-hidden');
      document.body.classList.add('modal-open');
      syncBackdropZIndex();
      return;
    }
    var inst = BS.Modal.getOrCreateInstance(modalEl, { backdrop: true, keyboard: true });
    modalEl.addEventListener(
      'shown.bs.modal',
      function onShown() {
        modalEl.removeEventListener('shown.bs.modal', onShown);
        syncBackdropZIndex();
      },
      false
    );
    modalEl.addEventListener(
      'hidden.bs.modal',
      function onHidden() {
        modalEl.removeEventListener('hidden.bs.modal', onHidden);
        cleanupModalState();
        syncBackdropZIndex();

        // If user closed via X/outside tap, consume the pushed history state
        if (nixModalNav.open && nixModalNav.el === modalEl && !nixModalNav.closing) {
          try {
            nixModalNav.closing = true;
            window.history.back();
          } catch (e) {
            // ignore
          }
        }
        if (nixModalNav.el === modalEl) {
          nixModalNav.open = false;
          nixModalNav.el = null;
          setTimeout(function () {
            nixModalNav.closing = false;
          }, 0);
        }
      },
      false
    );
    inst.show();
  }

  function initSendReceiptModal() {
    var payloadEl = document.getElementById('nix-receipt-payload');
    var modalEl = document.getElementById('modalSendReceipt');
    if (!payloadEl || !modalEl) {
      return;
    }

    var raw = (payloadEl.textContent || '').trim();
    var payload;
    try {
      payload = JSON.parse(raw);
    } catch (err) {
      return;
    }
    if (!payload || typeof payload !== 'object') {
      return;
    }

    bindReceiptImageExport('nixReceiptCapture', function () {
      return payload;
    }, 'btnDownloadReceiptPng', 'btnDownloadReceiptJpg');

    setTimeout(function () {
      enableBackToCloseOnce(modalEl);
      showBsModal(modalEl);
    }, 150);
  }

  function formatCategoryLabel(cat) {
    var s = cat == null ? '' : String(cat);
    if (!s) {
      return 'Transfer';
    }
    return s.replace(/_/g, ' ').replace(/\b\w/g, function (c) {
      return c.toUpperCase();
    });
  }

  function fillTxReceiptModal(payload) {
    var amtEl = document.getElementById('nixTxRxAmount');
    var refEl = document.getElementById('nixTxRxRef');
    var whenEl = document.getElementById('nixTxRxWhen');
    var typeEl = document.getElementById('nixTxRxTypeLabel');
    var fn = document.getElementById('nixTxRxFromName');
    var fe = document.getElementById('nixTxRxFromEmail');
    var tn = document.getElementById('nixTxRxToName');
    var te = document.getElementById('nixTxRxToEmail');
    var catEl = document.getElementById('nixTxRxCat');
    var noteRow = document.getElementById('nixTxRxNoteRow');
    var noteEl = document.getElementById('nixTxRxNote');
    if (!amtEl || !refEl) {
      return;
    }
    amtEl.textContent = 'Rs. ' + String(payload.amount || '');
    refEl.textContent = String(payload.reference || '');
    if (whenEl) {
      whenEl.textContent = String(payload.date || '');
    }
    if (typeEl) {
      typeEl.textContent = 'Money sent';
    }
    if (fn) {
      fn.textContent = String(payload.fromName || '');
    }
    if (fe) {
      fe.textContent = String(payload.fromEmail || '');
    }
    if (tn) {
      tn.textContent = String(payload.toName || '');
    }
    if (te) {
      te.textContent = String(payload.toEmail || '');
    }
    if (catEl) {
      catEl.textContent = formatCategoryLabel(payload.category);
    }
    var note = (payload.note && String(payload.note).trim()) || '';
    if (noteRow && noteEl) {
      if (note) {
        noteEl.textContent = note;
        noteRow.classList.remove('d-none');
      } else {
        noteEl.textContent = '';
        noteRow.classList.add('d-none');
      }
    }
  }

  function initBillReceiptExport() {
    var cap = document.getElementById('nixBillReceiptCapture');
    var payloadEl = document.getElementById('nix-bill-receipt-payload');
    if (!cap || !payloadEl) {
      return;
    }
    var raw = (payloadEl.textContent || '').trim();
    var payload;
    try {
      payload = JSON.parse(raw);
    } catch (e) {
      return;
    }
    if (!payload || typeof payload !== 'object') {
      return;
    }
    bindReceiptImageExport(
      'nixBillReceiptCapture',
      function () {
        return payload;
      },
      'btnDownloadBillReceiptPng',
      'btnDownloadBillReceiptJpg'
    );
  }

  function initTransactionsReceipt() {
    var modalEl = document.getElementById('modalTxReceipt');
    if (!modalEl) {
      return;
    }

    var currentPayload = null;
    bindReceiptImageExport(
      'nixReceiptCaptureTx',
      function () {
        return currentPayload;
      },
      'btnDownloadReceiptPngTx',
      'btnDownloadReceiptJpgTx'
    );

    document.querySelectorAll('.nix-tx-receipt-btn[data-nix-receipt]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var raw = btn.getAttribute('data-nix-receipt');
        if (!raw) {
          return;
        }
        try {
          currentPayload = JSON.parse(raw);
        } catch (e) {
          return;
        }
        if (!currentPayload || typeof currentPayload !== 'object') {
          return;
        }
        fillTxReceiptModal(currentPayload);
        enableBackToCloseOnce(modalEl);
        showBsModal(modalEl);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initNixTheme();
    initBalanceToggle();
    initQuickSend();
    initSendEmailSuggest();
    initSplitMemberEmailSuggest();
    initSendReceiptModal();
    initBillReceiptExport();
    initTransactionsReceipt();
  });

  window.addEventListener('popstate', function () {
    if (nixModalNav.open && nixModalNav.el) {
      nixModalNav.closing = true;
      hideBsModal(nixModalNav.el);
      nixModalNav.open = false;
      nixModalNav.el = null;
      setTimeout(function () {
        nixModalNav.closing = false;
      }, 0);
    }
  });
})();
