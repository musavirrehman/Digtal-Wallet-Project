<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

require_login();
nixcash_refresh_user_role_session($pdo);

$uid = current_user_id();
$pageTitle = 'Home';

$canAdminPanel = nixcash_can_open_admin_panel($pdo);
$adminCreditUsers = [];
if ($canAdminPanel) {
    try {
        $adminCreditUsers = $pdo->query('SELECT email, name FROM users ORDER BY name ASC')->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $adminCreditUsers = [];
    }
}

$sendReceipt = null;
if (!empty($_SESSION['pending_send_receipt'])) {
    $pendingId = (int) $_SESSION['pending_send_receipt'];
    unset($_SESSION['pending_send_receipt']);
    if ($pendingId > 0) {
        $recSt = $pdo->prepare(
            'SELECT t.transaction_id, t.amount, t.type, t.category, t.description, t.created_at,
                    sr.name AS sender_name, sr.email AS sender_email,
                    rr.name AS recv_name, rr.email AS recv_email
             FROM transactions t
             INNER JOIN users sr ON sr.user_id = t.sender_id
             INNER JOIN users rr ON rr.user_id = t.receiver_id
             WHERE t.transaction_id = ? AND t.sender_id = ? AND t.type = ?'
        );
        $recSt->execute([$pendingId, $uid, 'send']);
        $row = $recSt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $sendReceipt = $row;
        }
    }
}

$balance = user_balance($pdo, $uid);

$recent = $pdo->prepare(
    'SELECT t.*, us.name AS sname, ur.name AS rname
     FROM transactions t
     LEFT JOIN users us ON us.user_id = t.sender_id
     LEFT JOIN users ur ON ur.user_id = t.receiver_id
     WHERE t.sender_id = ? OR t.receiver_id = ?
     ORDER BY t.created_at DESC
     LIMIT 8'
);
$recent->execute([$uid, $uid]);
$recentRows = $recent->fetchAll();

$notifRows = [];
try {
    $nst = $pdo->prepare(
        'SELECT notification_id, message, created_at FROM user_notifications
         WHERE user_id = ? ORDER BY created_at DESC LIMIT 8'
    );
    $nst->execute([$uid]);
    $notifRows = $nst->fetchAll();
} catch (Throwable $e) {
    $notifRows = [];
}

$activityFeed = [];
foreach ($notifRows as $nr) {
    $activityFeed[] = ['kind' => 'notice', 'created_at' => $nr['created_at'], 'data' => $nr];
}
foreach ($recentRows as $tr) {
    $activityFeed[] = ['kind' => 'tx', 'created_at' => $tr['created_at'], 'data' => $tr];
}
usort($activityFeed, static function ($a, $b) {
    return strcmp((string) $b['created_at'], (string) $a['created_at']);
});
$activityFeed = array_slice($activityFeed, 0, 12);

$monthStart = date('Y-m-01 00:00:00');
$inc = $pdo->prepare(
    "SELECT COALESCE(SUM(amount), 0) AS v FROM transactions
     WHERE receiver_id = ? AND created_at >= ?
     AND type IN ('add_money', 'send', 'split_pay', 'loan')"
);
$inc->execute([$uid, $monthStart]);
$income = (float) $inc->fetch()['v'];

$exp = $pdo->prepare(
    "SELECT COALESCE(SUM(amount), 0) AS v FROM transactions
     WHERE sender_id = ? AND created_at >= ?
     AND type IN ('send','withdraw','bill','recharge','goal','card_load','card_payment','split_pay')"
);
$exp->execute([$uid, $monthStart]);
$expense = (float) $exp->fetch()['v'];

$contacts = $pdo->prepare(
    'SELECT DISTINCT u.user_id, u.name, u.email FROM transactions t
     JOIN users u ON u.user_id = IF(t.sender_id = ?, t.receiver_id, t.sender_id)
     WHERE (t.sender_id = ? OR t.receiver_id = ?) AND t.type = \'send\'
     ORDER BY t.created_at DESC LIMIT 5'
);
$contacts->execute([$uid, $uid, $uid]);
$contactRows = $contacts->fetchAll();

// Get user profile image
$userProfile = $pdo->prepare('SELECT profile_image FROM users WHERE user_id = ?');
$userProfile->execute([$uid]);
$profileImage = $userProfile->fetchColumn();

require __DIR__ . '/partials/header.php';
?>
<header class="nix-page-header d-flex align-items-center justify-content-between px-3 pt-3">
    <div class="d-flex align-items-center gap-2">
        <a href="<?= esc(url_for('pages/profile.php')) ?>" class="nix-dash-avatar-link">
            <div class="rounded-circle nix-dash-avatar d-flex align-items-center justify-content-center">
                <?php if ($profileImage): ?>
                    <img src="<?= esc(url_for('assets/images/profiles/' . $profileImage)) ?>" alt="Profile" class="w-100 h-100 object-fit-cover rounded-circle">
                <?php else: ?>
                    <i class="bi bi-person-fill text-muted"></i>
                <?php endif; ?>
            </div>
        </a>
        <div>
            <p class="text-muted small mb-0">Hello,</p>
            <h1 class="h5 mb-0 fw-semibold"><?= esc($_SESSION['user_name'] ?? 'User') ?></h1>
        </div>
    </div>
    <div class="d-flex align-items-center gap-1 nix-dash-actions">
        <?php if ($canAdminPanel): ?>
        <a href="<?= esc(url_for('admin/dashboard.php')) ?>" class="btn btn-sm btn-nix-primary rounded-pill" title="Admin Panel" aria-label="Admin Panel">
            <i class="bi bi-shield-lock-fill me-1" aria-hidden="true"></i>Admin Panel
        </a>
        <?php endif; ?>
        <button class="btn btn-sm nix-btn-ghost nix-dash-iconbtn rounded-circle" type="button" data-bs-toggle="offcanvas" data-bs-target="#nixNotify" aria-label="Notifications">
            <i class="bi bi-bell-fill" aria-hidden="true"></i>
        </button>
        <div class="nix-dash-theme-pill d-flex align-items-center" role="group" aria-label="Theme">
            <button type="button" class="btn btn-sm nix-theme-ico" data-nix-theme="light" title="Light theme" aria-label="Light theme" aria-pressed="false">
                <i class="bi bi-sun-fill" aria-hidden="true"></i>
            </button>
            <button type="button" class="btn btn-sm nix-theme-ico" data-nix-theme="dark" title="Dark theme" aria-label="Dark theme" aria-pressed="false">
                <i class="bi bi-moon-stars-fill" aria-hidden="true"></i>
            </button>
        </div>
        <a href="<?= esc(url_for('logout.php')) ?>" class="btn btn-outline-danger btn-sm rounded-pill" title="Logout"><i class="bi bi-box-arrow-right"></i></a>
    </div>
</header>

<div class="offcanvas offcanvas-end nix-notify-panel" tabindex="-1" id="nixNotify" aria-labelledby="nixNotifyLabel">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title mb-0" id="nixNotifyLabel"><i class="bi bi-bell me-2"></i>Activity</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body p-0">
        <?php if (count($activityFeed) === 0): ?>
            <p class="text-muted small px-3 py-4 mb-0">No recent activity yet.</p>
        <?php else: ?>
            <div class="list-group list-group-flush">
                <?php foreach ($activityFeed as $feedItem): ?>
                    <?php if ($feedItem['kind'] === 'notice'): ?>
                        <?php
                        $nr = $feedItem['data'];
                        $whenN = date('M j, g:i a', strtotime($nr['created_at']));
                        ?>
                        <div class="list-group-item nix-notify-item border-0 border-bottom">
                            <div class="d-flex justify-content-between align-items-start gap-2">
                                <div class="d-flex gap-2 min-w-0">
                                    <span class="nix-notify-dot note flex-shrink-0" aria-hidden="true"></span>
                                    <div class="min-w-0">
                                        <div class="small fw-semibold"><?= esc($nr['message']) ?></div>
                                        <div class="text-muted" style="font-size:0.72rem;"><?= esc($whenN) ?></div>
                                    </div>
                                </div>
                                <span class="small text-muted flex-shrink-0">Alert</span>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php
                        $n = $feedItem['data'];
                        $isOutN = (int) $n['sender_id'] === $uid;
                        $amtN = (float) $n['amount'];
                        $labelN = $n['description'] ?: ucfirst(str_replace('_', ' ', $n['type']));
                        $whenN = date('M j, g:i a', strtotime($n['created_at']));
                        ?>
                        <div class="list-group-item nix-notify-item border-0 border-bottom">
                            <div class="d-flex justify-content-between align-items-start gap-2">
                                <div class="d-flex gap-2 min-w-0">
                                    <span class="nix-notify-dot flex-shrink-0 <?= $isOutN ? 'out' : 'in' ?>" aria-hidden="true"></span>
                                    <div class="min-w-0">
                                        <div class="small fw-semibold text-truncate"><?= esc($labelN) ?></div>
                                        <div class="text-muted" style="font-size:0.72rem;"><?= esc($whenN) ?></div>
                                    </div>
                                </div>
                                <span class="small fw-semibold flex-shrink-0 <?= $isOutN ? 'text-danger' : 'text-success' ?>">
                                    <?= $isOutN ? '−' : '+' ?>Rs. <?= esc(format_money($amtN)) ?>
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <div class="p-3 border-top d-grid gap-2">
                <a href="<?= esc(url_for('pages/split-bills.php')) ?>" class="btn btn-outline-secondary btn-sm rounded-3">Split bills</a>
                <a href="<?= esc(url_for('pages/transactions.php')) ?>" class="btn btn-nix-primary w-100 btn-sm rounded-3">View all transactions</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<main class="px-3 pb-4 flex-grow-1">
    <div class="nix-balance-card mb-4" data-balance-toggle>
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
                <p class="small text-muted mb-1">Total balance</p>
                <p class="h3 mb-0 fw-bold nix-balance-val" data-balance-val>
                    Rs. <?= esc(format_money($balance)) ?>
                </p>
            </div>
            <button type="button" class="btn btn-sm nix-icon-roundbtn rounded-circle" data-balance-toggle-btn title="Show / hide balance">
                <i class="bi bi-eye-fill" data-balance-eye></i>
            </button>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <span class="nix-chip">PKR</span>
            <span class="nix-chip nix-chip-success">Active</span>
        </div>
    </div>

    <div class="row g-2 mb-4">
        <div class="<?= $canAdminPanel ? 'col-3' : 'col-4' ?>">
            <a href="#" class="nix-action-btn w-100" data-bs-toggle="modal" data-bs-target="#modalSend">
                <i class="bi bi-send-fill"></i>Send
            </a>
        </div>
        <?php if ($canAdminPanel): ?>
        <div class="col-3">
            <a href="#" class="nix-action-btn w-100" data-bs-toggle="modal" data-bs-target="#modalAdd">
                <i class="bi bi-plus-circle-fill"></i>Add
            </a>
        </div>
        <?php endif; ?>
        <div class="<?= $canAdminPanel ? 'col-3' : 'col-4' ?>">
            <a href="#" class="nix-action-btn w-100" data-bs-toggle="modal" data-bs-target="#modalWithdraw">
                <i class="bi bi-bank"></i>Cash out
            </a>
        </div>
        <div class="<?= $canAdminPanel ? 'col-3' : 'col-4' ?>">
            <a href="#" class="nix-action-btn w-100" data-bs-toggle="modal" data-bs-target="#modalQr">
                <i class="bi bi-qr-code-scan"></i>Scan
            </a>
        </div>
    </div>

    <div class="row g-2 mb-4">
        <?php if ($canAdminPanel): ?>
        <div class="col-4">
            <a href="<?= esc(url_for('admin/dashboard.php')) ?>" class="nix-action-btn w-100" style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: white;">
                <i class="bi bi-shield-lock-fill"></i>Admin
            </a>
        </div>
        <div class="col-4">
            <a href="<?= esc(url_for('pages/bill-payment.php')) ?>" class="nix-action-btn w-100">
                <i class="bi bi-receipt"></i>Bills
            </a>
        </div>
        <div class="col-4">
            <a href="<?= esc(url_for('pages/mobile-recharge.php')) ?>" class="nix-action-btn w-100">
                <i class="bi bi-phone-fill"></i>Recharge
            </a>
        </div>
        <?php else: ?>
        <div class="col-4">
            <a href="<?= esc(url_for('pages/bill-payment.php')) ?>" class="nix-action-btn w-100">
                <i class="bi bi-receipt"></i>Bills
            </a>
        </div>
        <div class="col-4">
            <a href="<?= esc(url_for('pages/mobile-recharge.php')) ?>" class="nix-action-btn w-100">
                <i class="bi bi-phone-fill"></i>Recharge
            </a>
        </div>
        <div class="col-4">
            <a href="<?= esc(url_for('pages/split-bills.php')) ?>" class="nix-action-btn w-100">
                <i class="bi bi-people-fill"></i>Split
            </a>
        </div>
        <?php endif; ?>
    </div>
    <?php if (!$canAdminPanel): ?>
    <div class="row g-2 mb-4">
        <div class="col-4">
            <a href="<?= esc(url_for('pages/loan.php')) ?>" class="nix-action-btn w-100" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white;">
                <i class="bi bi-bank2"></i>Loan
            </a>
        </div>
        <div class="col-4">
            <a href="<?= esc(url_for('pages/goals.php')) ?>" class="nix-action-btn w-100" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white;">
                <i class="bi bi-bullseye"></i>Goals
            </a>
        </div>
        <div class="col-4">
            <a href="<?= esc(url_for('pages/virtual-cards.php')) ?>" class="nix-action-btn w-100" style="background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); color: white;">
                <i class="bi bi-credit-card-fill"></i>Cards
            </a>
        </div>
    </div>
    <?php endif; ?>
    <?php if ($canAdminPanel): ?>
    <div class="row g-2 mb-4">
        <div class="col-4">
            <a href="<?= esc(url_for('pages/split-bills.php')) ?>" class="nix-action-btn w-100">
                <i class="bi bi-people-fill"></i>Split
            </a>
        </div>
    </div>
    <?php endif; ?>

    <div class="glass-card p-3 mb-4">
        <h2 class="h6 mb-3">This month</h2>
        <?php $totalIE = $income + $expense; $ip = $totalIE > 0 ? round(100 * $income / $totalIE) : 50; ?>
        <div class="d-flex justify-content-between small mb-1">
            <span class="text-success"><i class="bi bi-arrow-down-left"></i> In <?= esc(format_money($income)) ?></span>
            <span class="text-danger"><i class="bi bi-arrow-up-right"></i> Out <?= esc(format_money($expense)) ?></span>
        </div>
        <div class="nix-progress mb-2">
            <div class="nix-progress-bar" style="width: <?= (int) $ip ?>%"></div>
        </div>
        <p class="text-muted small mb-0">Income vs spending snapshot</p>
    </div>

    <?php if (count($contactRows) > 0): ?>
    <div class="mb-4">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h6 mb-0">Send again</h2>
        </div>
        <div class="d-flex gap-2 overflow-auto pb-1">
            <?php foreach ($contactRows as $c): ?>
                <button type="button" class="btn nix-btn-ghost rounded-4 text-start text-nowrap"
                        data-bs-toggle="modal" data-bs-target="#modalSend"
                        data-send-email="<?= esc($c['email']) ?>"
                        data-send-name="<?= esc($c['name']) ?>">
                    <i class="bi bi-person-fill me-1"></i><?= esc($c['name']) ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="glass-card p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="h6 mb-0">Recent activity</h2>
            <a href="<?= esc(url_for('pages/transactions.php')) ?>" class="small link-nix">See all</a>
        </div>
        <?php if (count($recentRows) === 0): ?>
            <p class="text-muted small mb-0">No transactions yet. Send money to a friend or use other services.</p>
        <?php else: ?>
            <?php foreach ($recentRows as $tx): ?>
                <?php
                $isOut = (int) $tx['sender_id'] === $uid;
                $amt = (float) $tx['amount'];
                $label = $tx['description'] ?: ucfirst(str_replace('_', ' ', $tx['type']));
                ?>
                <div class="nix-tx-item d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-2">
                        <span class="nix-tx-avatar">
                            <i class="bi <?= $isOut ? 'bi-arrow-up-right text-danger' : 'bi-arrow-down-left text-success' ?>"></i>
                        </span>
                        <div>
                            <div class="small fw-medium"><?= esc($label) ?></div>
                            <div class="text-muted" style="font-size:0.75rem;"><?= esc(date('M j, g:i a', strtotime($tx['created_at']))) ?></div>
                        </div>
                    </div>
                    <span class="fw-semibold <?= $isOut ? 'text-danger' : 'text-success' ?>">
                        <?= $isOut ? '-' : '+' ?>Rs. <?= esc(format_money($amt)) ?>
                    </span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>

<!-- Modals -->
<div class="modal fade" id="modalSend" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content nix-modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Send money</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= esc(url_for('actions/send-money.php')) ?>">
                <div class="modal-body">
                    <div class="position-relative mb-3 nix-send-email-wrap">
                        <label class="form-label" for="sendEmail">Recipient</label>
                        <input type="email" class="form-control" name="to_email" id="sendEmail" required placeholder="Search name or email…" autocomplete="off" autocapitalize="off" spellcheck="false">
                        <div id="sendEmailSuggest" class="nix-send-suggest list-group d-none" role="listbox" aria-label="Matching users"></div>
                    </div>
                    <p class="small text-muted mb-3 d-none" id="sendRecipientHint"></p>
                    <label class="form-label">Amount (PKR)</label>
                    <input type="number" step="0.01" min="0.01" class="form-control mb-3" name="amount" required>
                    <label class="form-label">Note (optional)</label>
                    <input type="text" class="form-control" name="note" maxlength="200" placeholder="Lunch, rent...">
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-nix-primary w-100">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($canAdminPanel): ?>
<div class="modal fade" id="modalAdd" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content nix-modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add money (admin)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= esc(url_for('actions/add-money.php')) ?>">
                <div class="modal-body">
                    <p class="small text-muted">Credit a user wallet. Only you can perform this action.</p>
                    <label class="form-label" for="adminCreditEmail">Recipient</label>
                    <select class="form-select mb-3" name="to_email" id="adminCreditEmail" required>
                        <option value="" disabled selected>Select user email</option>
                        <?php foreach ($adminCreditUsers as $cu): ?>
                            <option value="<?= esc($cu['email']) ?>"><?= esc($cu['name']) ?> — <?= esc($cu['email']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label class="form-label">Amount (PKR)</label>
                    <input type="number" step="0.01" min="0.01" class="form-control" name="amount" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-nix-primary w-100">Credit wallet</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="modal fade" id="modalWithdraw" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content nix-modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Withdraw</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= esc(url_for('actions/withdraw.php')) ?>">
                <div class="modal-body">
                    <p class="small text-muted">Demo: sends to your linked bank account.</p>
                    <label class="form-label">Amount (PKR)</label>
                    <input type="number" step="0.01" min="0.01" class="form-control" name="amount" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-nix-primary w-100">Withdraw</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="modalQr" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content nix-modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Scan QR</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <i class="bi bi-qr-code display-1 text-secondary"></i>
                <p class="mt-3 mb-0 text-muted">QR payments are coming soon. Use Send money for now.</p>
            </div>
        </div>
    </div>
</div>

<div id="nix-page-config" class="d-none" data-user-suggest-url="<?= esc(url_for('api/user-suggest.php')) ?>"></div>

<?php if (!empty($sendReceipt)): ?>
<?php
$rxAmt = (float) $sendReceipt['amount'];
$rxRef = 'TXN-' . (int) $sendReceipt['transaction_id'];
$rxWhen = date('M j, Y \a\t g:i A', strtotime($sendReceipt['created_at']));
$rxNote = trim((string) ($sendReceipt['description'] ?? ''));
$rxJson = [
    'reference' => $rxRef,
    'amount' => format_money($rxAmt),
    'currency' => 'PKR',
    'date' => $rxWhen,
    'fromName' => $sendReceipt['sender_name'],
    'fromEmail' => $sendReceipt['sender_email'],
    'toName' => $sendReceipt['recv_name'],
    'toEmail' => $sendReceipt['recv_email'],
    'category' => $sendReceipt['category'] ?: 'Transfer',
    'note' => $rxNote,
];
?>
<script type="application/json" id="nix-receipt-payload"><?= json_encode($rxJson, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>

<div class="modal fade" id="modalSendReceipt" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content nix-modal-content nix-receipt-modal">
            <div class="modal-header border-0 pb-0">
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-0">
                <div id="nixReceiptCapture" class="nix-receipt-capture-sheet">
                    <div class="nix-receipt-card text-center mb-4">
                        <div class="nix-receipt-success-icon mx-auto mb-3" aria-hidden="true">
                            <span class="nix-receipt-check">&#10003;</span>
                        </div>
                        <p class="text-muted small mb-1">Payment successful</p>
                        <h2 class="h3 fw-bold mb-1">Rs. <?= esc(format_money($rxAmt)) ?></h2>
                        <p class="text-muted small mb-0"><?= esc($rxRef) ?></p>
                    </div>

                    <div class="nix-receipt-details rounded-4 p-3 mb-2">
                        <div class="row g-3 small">
                            <div class="col-6">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Date &amp; time</div>
                                <div class="fw-medium"><?= esc($rxWhen) ?></div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Type</div>
                                <div class="fw-medium">Money sent</div>
                            </div>
                            <div class="col-12">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">From</div>
                                <div class="fw-medium"><?= esc($sendReceipt['sender_name']) ?></div>
                                <div class="text-muted" style="font-size:0.8rem;"><?= esc($sendReceipt['sender_email']) ?></div>
                            </div>
                            <div class="col-12 border-top border-secondary pt-3 mt-1">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">To</div>
                                <div class="fw-medium"><?= esc($sendReceipt['recv_name']) ?></div>
                                <div class="text-muted" style="font-size:0.8rem;"><?= esc($sendReceipt['recv_email']) ?></div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Category</div>
                                <div class="fw-medium"><?= esc(ucfirst(str_replace('_', ' ', $sendReceipt['category'] ?: 'transfer'))) ?></div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Status</div>
                                <div class="text-success fw-medium"><span class="me-1" aria-hidden="true">&#9679;</span>Completed</div>
                            </div>
                            <?php if ($rxNote !== ''): ?>
                            <div class="col-12 border-top border-secondary pt-3 mt-1">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Note</div>
                                <div class="fw-medium"><?= esc($rxNote) ?></div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p class="text-center text-muted small mb-0 pt-1 nix-receipt-brand">NixCash</p>
                </div>

                <p class="text-center text-muted small mb-3 mb-md-4 mt-3">Saved to your activity. Download your receipt as an image.</p>

                <div class="d-grid gap-2">
                    <button type="button" class="btn btn-nix-primary" id="btnDownloadReceiptPng">
                        <i class="bi bi-file-earmark-image me-2"></i>Download as PNG
                    </button>
                    <button type="button" class="btn nix-btn-ghost rounded-4" id="btnDownloadReceiptJpg">
                        <i class="bi bi-file-earmark-image me-2"></i>Download as JPG
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/partials/footer.php'; ?>
