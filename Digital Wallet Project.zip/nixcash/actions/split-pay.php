<?php
/**
 * Pay your share — debits payer, credits bill creator, updates status.
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/split-bills.php');
}

$uid = current_user_id();
$billId = post_int('bill_id');

if ($billId <= 0) {
    set_flash('error', 'Invalid bill.');
    redirect('pages/split-bills.php');
}

try {
    $pdo->beginTransaction();

    $m = $pdo->prepare(
        'SELECT sbm.amount, sbm.paid_status, sb.created_by
         FROM split_bill_members sbm
         JOIN split_bills sb ON sb.bill_id = sbm.bill_id
         WHERE sbm.bill_id = ? AND sbm.user_id = ? FOR UPDATE'
    );
    $m->execute([$billId, $uid]);
    $row = $m->fetch();
    if (!$row || (int) $row['paid_status'] === 1) {
        $pdo->rollBack();
        set_flash('error', 'Nothing to pay or already paid.');
        redirect('pages/split-bills.php');
    }

    $amount = (float) $row['amount'];
    $creatorId = (int) $row['created_by'];

    if ($uid === $creatorId) {
        /* Organizer marks own share — no wallet transfer (already covered the bill). */
        $pdo->prepare('UPDATE split_bill_members SET paid_status = 1 WHERE bill_id = ? AND user_id = ?')
            ->execute([$billId, $uid]);
    } else {
        $ids = [$uid, $creatorId];
        sort($ids, SORT_NUMERIC);
        $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE')->execute([$ids[0]]);
        $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE')->execute([$ids[1]]);

        $ws = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ?');
        $ws->execute([$uid]);
        $w = $ws->fetch();
        if (!$w || (float) $w['balance'] < $amount) {
            $pdo->rollBack();
            set_flash('error', 'Insufficient balance.');
            redirect('pages/split-bills.php');
        }

        $pdo->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id = ?')->execute([$amount, $uid]);
        $pdo->prepare('UPDATE wallets SET balance = balance + ? WHERE user_id = ?')->execute([$amount, $creatorId]);

        $pdo->prepare('UPDATE split_bill_members SET paid_status = 1 WHERE bill_id = ? AND user_id = ?')
            ->execute([$billId, $uid]);

        $tx = $pdo->prepare(
            'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $tx->execute([$uid, $creatorId, $amount, 'split_pay', 'split', 'Split bill #' . $billId]);
    }

    $cnt = $pdo->prepare('SELECT COUNT(*) AS c FROM split_bill_members WHERE bill_id = ? AND paid_status = 0');
    $cnt->execute([$billId]);
    $left = (int) $cnt->fetch()['c'];
    $status = $left === 0 ? 'paid' : 'partial';
    $pdo->prepare('UPDATE split_bills SET status = ? WHERE bill_id = ?')->execute([$status, $billId]);

    $pdo->commit();

    $bt = $pdo->prepare('SELECT title FROM split_bills WHERE bill_id = ?');
    $bt->execute([$billId]);
    $billTitle = (string) (($bt->fetch())['title'] ?? 'Split bill');
    $pn = $pdo->prepare('SELECT name FROM users WHERE user_id = ?');
    $pn->execute([$uid]);
    $payerName = (string) (($pn->fetch())['name'] ?? 'Someone');
    $ms = $pdo->prepare('SELECT user_id FROM split_bill_members WHERE bill_id = ?');
    $ms->execute([$billId]);
    $notifyIds = array_map('intval', array_column($ms->fetchAll(), 'user_id'));
    if (!in_array($creatorId, $notifyIds, true)) {
        $notifyIds[] = $creatorId;
    }
    if ($left === 0) {
        $msg = $payerName . ' paid their share on "' . $billTitle . '". The split is fully paid.';
    } else {
        $msg = $payerName . ' paid their share on "' . $billTitle . '". ' . $left . ' share(s) still pending.';
    }
    foreach ($notifyIds as $oid) {
        if ($oid === $uid) {
            continue;
        }
        nix_notify_user($pdo, $oid, 'split_paid', $msg, $billId);
    }

    set_flash('success', 'Your share paid.');
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Payment failed.');
}

redirect('pages/split-bills.php');
