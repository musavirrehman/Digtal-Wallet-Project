<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/goals.php');
}

$uid = current_user_id();
$title = post_string('title', 120) ?: 'Savings Goal';
$target = post_money('target_amount');
$deadline = post_string('deadline', 20);

if ($target <= 0) {
    set_flash('error', 'Enter a valid target amount.');
    redirect('pages/goals.php');
}

$d = null;
if ($deadline !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $deadline)) {
    $d = $deadline;
}

try {
    $st = $pdo->prepare(
        'INSERT INTO goals (user_id, title, target_amount, saved_amount, deadline) VALUES (?, ?, ?, 0, ?)'
    );
    $st->execute([$uid, $title, $target, $d]);
    set_flash('success', 'Goal created.');
} catch (Throwable $e) {
    set_flash('error', 'Could not create goal.');
}

redirect('pages/goals.php');
