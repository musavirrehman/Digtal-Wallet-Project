<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/bill-companies.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/bill-payment.php');
}

$uid = current_user_id();
$category = post_string('category', 40);
$amount = post_money('amount');
$companySlug = post_string('company', 64);
$billId = post_string('bill_id', 80);

$allowed = ['electricity' => 'Electricity', 'gas' => 'Gas', 'internet' => 'Internet'];
$label = $allowed[$category] ?? '';

if ($label === '') {
    set_flash('error', 'Choose a valid bill type.');
    redirect('pages/bill-payment.php');
}

$companyLabel = bill_company_label($category, $companySlug);
if ($companySlug === '' || $companyLabel === null) {
    set_flash('error', 'Choose a company that matches the bill type.');
    redirect('pages/bill-payment.php');
}

if ($amount <= 0) {
    set_flash('error', 'Enter a valid amount.');
    redirect('pages/bill-payment.php');
}

$descParts = [$companyLabel, $label . ' bill'];
if ($billId !== '') {
    $descParts[] = 'Bill ID: ' . $billId;
}
$description = implode(' — ', $descParts);
if (strlen($description) > 255) {
    $description = substr($description, 0, 252) . '...';
}

try {
    $pdo->beginTransaction();
    $ws = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE');
    $ws->execute([$uid]);
    $w = $ws->fetch();
    if (!$w || (float) $w['balance'] < $amount) {
        $pdo->rollBack();
        set_flash('error', 'Insufficient balance.');
        redirect('pages/bill-payment.php');
    }

    $pdo->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id = ?')->execute([$amount, $uid]);
    $tx = $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (?, NULL, ?, ?, ?, ?)'
    );
    $tx->execute([$uid, $amount, 'bill', $category, $description]);
    $newTxId = (int) $pdo->lastInsertId();

    $pdo->commit();
    redirect('pages/bill-receipt.php?id=' . $newTxId);
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Payment failed.');
}

redirect('pages/bill-payment.php');
