<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/loan-schema.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/loan.php');
}

$uid = current_user_id();
if ($uid === null) {
    redirect('login.php');
}

$amount = post_money('amount');
$note = post_string('note', 255);

if ($amount <= 0) {
    set_flash('error', 'Enter a valid loan amount.');
    redirect('pages/loan.php');
}

if ($amount > 10000) {
    set_flash('error', 'Maximum loan amount is Rs. 10,000.');
    redirect('pages/loan.php');
}

try {
    ensure_loan_schema($pdo);
    $pdo->prepare(
        'INSERT INTO loan_applications (user_id, amount, note, status) VALUES (?, ?, ?, ?)'
    )->execute([$uid, $amount, $note !== '' ? $note : null, 'pending']);

    $nm = $_SESSION['user_name'] ?? 'User';
    nix_notify_all_admins(
        $pdo,
        'loan',
        $nm . ' applied for a loan of Rs. ' . format_money($amount) . '. Review it in Admin → Loans.'
    );
    set_flash('success', 'Loan application submitted. An admin will review it soon.');
} catch (Throwable $e) {
    set_flash('error', 'Could not submit your application. Try again later.');
}

redirect('pages/loan.php');
