<?php
/**
 * Send money — wallet debit/credit + transaction row (PDO transaction).
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}

$uid = current_user_id();
$toEmail = post_email('to_email');
$amount = post_money('amount');
$note = post_string('note', 200);

if ($amount <= 0) {
    set_flash('error', 'Enter a valid amount.');
    redirect('index.php');
}

$rbac = nixcash_users_table_has_rbac_columns($pdo);
$find = $pdo->prepare(
    $rbac
        ? 'SELECT user_id, name FROM users WHERE email = ? AND (status = \'active\' OR status IS NULL) LIMIT 1'
        : 'SELECT user_id, name FROM users WHERE email = ? LIMIT 1'
);
$find->execute([$toEmail]);
$recv = $find->fetch();

if (!$recv) {
    set_flash('error', 'No user found with that email.');
    redirect('index.php');
}

$rid = (int) $recv['user_id'];
if ($rid === $uid) {
    set_flash('error', 'You cannot send money to yourself.');
    redirect('index.php');
}

try {
    $pdo->beginTransaction();

    $ws = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE');
    $ws->execute([$uid]);
    $senderRow = $ws->fetch();
    if (!$senderRow || (float) $senderRow['balance'] < $amount) {
        $pdo->rollBack();
        set_flash('error', 'Insufficient balance.');
        redirect('index.php');
    }

    $wr = $pdo->prepare('SELECT wallet_id, balance FROM wallets WHERE user_id = ? FOR UPDATE');
    $wr->execute([$rid]);
    $recvWallet = $wr->fetch();
    if (!$recvWallet) {
        $pdo->rollBack();
        set_flash('error', 'Recipient wallet not found.');
        redirect('index.php');
    }

    $pdo->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id = ?')->execute([$amount, $uid]);
    $pdo->prepare('UPDATE wallets SET balance = balance + ? WHERE user_id = ?')->execute([$amount, $rid]);

    $desc = $note !== '' ? $note : 'Transfer to ' . $recv['name'];
    $tx = $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    $tx->execute([$uid, $rid, $amount, 'send', 'transfer', $desc]);

    // Must read before commit — after commit, lastInsertId() can be 0 with PDO MySQL.
    $newTxId = (int) $pdo->lastInsertId();
    $pdo->commit();
    if ($newTxId > 0) {
        $_SESSION['pending_send_receipt'] = $newTxId;
    }
    set_flash('success', 'Money sent successfully.');
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Transfer failed. Please try again.');
}

redirect('index.php');
