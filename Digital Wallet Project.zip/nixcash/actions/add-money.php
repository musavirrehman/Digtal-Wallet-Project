<?php
/**
 * Add money to a user's wallet — primary admin only. Credits recipient selected by email.
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();
nixcash_refresh_user_role_session($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}

if (!nixcash_can_open_admin_panel($pdo)) {
    set_flash('error', 'You are not allowed to add money.');
    redirect('index.php');
}

$toEmail = strtolower(trim(post_string('to_email', 255)));
$amount = post_money('amount');

if ($amount <= 0) {
    set_flash('error', 'Enter a valid amount.');
    redirect('index.php');
}

if ($toEmail === '' || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
    set_flash('error', 'Choose a valid recipient email.');
    redirect('index.php');
}

$st = $pdo->prepare('SELECT user_id, name FROM users WHERE LOWER(TRIM(email)) = ? LIMIT 1');
$st->execute([$toEmail]);
$recv = $st->fetch(PDO::FETCH_ASSOC);
if (!$recv) {
    set_flash('error', 'No user found with that email.');
    redirect('index.php');
}

$recvId = (int) $recv['user_id'];
$recvName = (string) $recv['name'];

try {
    $pdo->beginTransaction();
    $pdo->prepare('UPDATE wallets SET balance = balance + ? WHERE user_id = ?')->execute([$amount, $recvId]);
    $tx = $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (NULL, ?, ?, ?, ?, ?)'
    );
    $tx->execute([
        $recvId,
        $amount,
        'add_money',
        'admin_credit',
        'Admin credit to ' . $recvName,
    ]);
    $pdo->commit();
    set_flash('success', 'Added Rs. ' . format_money($amount) . ' to ' . $recvName . ' (' . $toEmail . ').');
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Could not add money.');
}

redirect('index.php');
