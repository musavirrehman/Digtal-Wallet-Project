<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/split-bills.php');
}

$uid = current_user_id();
$title = post_string('title', 120) ?: 'Group expense';
$total = post_money('total_amount');
$divideMode = post_string('divide_mode', 16);
if ($divideMode !== 'custom') {
    $divideMode = 'equal';
}
$includeMe = !empty($_POST['include_me']);

if ($total <= 0) {
    set_flash('error', 'Enter a valid total amount.');
    redirect('pages/split-bills.php');
}

$emailRows = isset($_POST['member_email']) && is_array($_POST['member_email']) ? $_POST['member_email'] : [];
$amountRows = isset($_POST['member_amount']) && is_array($_POST['member_amount']) ? $_POST['member_amount'] : [];
$creatorShare = post_money('creator_share');

$otherUsers = []; // user_id => amount (for custom from rows; filled later for equal)
$rbacUsers = nixcash_users_table_has_rbac_columns($pdo);

for ($i = 0; $i < count($emailRows); $i++) {
    $raw = isset($emailRows[$i]) ? trim((string) $emailRows[$i]) : '';
    if ($raw === '') {
        continue;
    }
    if (!filter_var($raw, FILTER_VALIDATE_EMAIL)) {
        set_flash('error', 'One of the member emails is invalid.');
        redirect('pages/split-bills.php');
    }
    $q = $pdo->prepare(
        $rbacUsers
            ? 'SELECT user_id FROM users WHERE email = ? AND (status = \'active\' OR status IS NULL) LIMIT 1'
            : 'SELECT user_id FROM users WHERE email = ? LIMIT 1'
    );
    $q->execute([$raw]);
    $r = $q->fetch();
    if (!$r) {
        set_flash('error', 'Each member email must belong to a registered user (check: ' . $raw . ').');
        redirect('pages/split-bills.php');
    }
    $mid = (int) $r['user_id'];
    if ($mid === $uid) {
        if ($includeMe) {
            continue;
        }
        set_flash('error', 'Remove your own email from the list when you are not included in the split.');
        redirect('pages/split-bills.php');
    }
    $amtRow = isset($amountRows[$i]) ? max(0, round((float) str_replace(',', '', (string) $amountRows[$i]), 2)) : 0.0;
    if (isset($otherUsers[$mid])) {
        set_flash('error', 'Duplicate member email in the list.');
        redirect('pages/split-bills.php');
    }
    $otherUsers[$mid] = $divideMode === 'custom' ? $amtRow : 0.0;
}

if (count($otherUsers) === 0) {
    set_flash('error', 'Add at least one member with a valid registered email.');
    redirect('pages/split-bills.php');
}

$shares = [];

if ($divideMode === 'equal') {
    $participants = array_keys($otherUsers);
    if ($includeMe) {
        $participants[] = $uid;
    }
    $participants = array_values(array_unique($participants));
    sort($participants, SORT_NUMERIC);
    $n = count($participants);
    if ($n < 1) {
        set_flash('error', 'No participants in this split.');
        redirect('pages/split-bills.php');
    }
    $each = round($total / $n, 2);
    $remainder = round($total - ($each * $n), 2);
    foreach ($participants as $k => $pid) {
        $amt = $each;
        if ($k === 0) {
            $amt += $remainder;
        }
        $shares[(int) $pid] = $amt;
    }
} else {
    $sumOthers = 0.0;
    foreach ($otherUsers as $mid => $a) {
        $sumOthers += $a;
    }
    if ($includeMe) {
        $sumOthers += $creatorShare;
    }
    if (abs($sumOthers - $total) > 0.05) {
        set_flash('error', 'Custom shares must add up to the total amount (within 0.05).');
        redirect('pages/split-bills.php');
    }
    foreach ($otherUsers as $mid => $a) {
        if ($a <= 0) {
            set_flash('error', 'Each custom share must be greater than zero.');
            redirect('pages/split-bills.php');
        }
        $shares[$mid] = $a;
    }
    if ($includeMe) {
        if ($creatorShare <= 0) {
            set_flash('error', 'Enter your own share for a custom split.');
            redirect('pages/split-bills.php');
        }
        $shares[$uid] = $creatorShare;
    }
}

if (count($shares) === 0) {
    set_flash('error', 'Could not build shares for this split.');
    redirect('pages/split-bills.php');
}

try {
    $pdo->beginTransaction();
    $pdo->prepare(
        'INSERT INTO split_bills (created_by, title, total_amount, divide_mode, status) VALUES (?, ?, ?, ?, ?)'
    )->execute([$uid, $title, $total, $divideMode, 'pending']);
    $bid = (int) $pdo->lastInsertId();

    ksort($shares, SORT_NUMERIC);
    foreach ($shares as $mid => $amt) {
        $pdo->prepare(
            'INSERT INTO split_bill_members (bill_id, user_id, amount, paid_status) VALUES (?, ?, ?, 0)'
        )->execute([$bid, (int) $mid, $amt]);
    }

    $pdo->commit();

    foreach (array_keys($shares) as $mid) {
        $own = (float) $shares[$mid];
        $msg = 'Split bill "' . $title . '": your share is Rs ' . format_money($own) . ' (pending).';
        nix_notify_user($pdo, (int) $mid, 'split_created', $msg, $bid);
    }

    set_flash('success', 'Split bill created. Everyone involved was notified.');
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Could not create split bill. If this persists, apply the database patch in database/patch_split_bill_v2.sql.');
}

redirect('pages/split-bills.php');
