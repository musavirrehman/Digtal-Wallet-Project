<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/virtual-card-schema.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();
ensure_virtual_card_schema($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/virtual-cards.php');
}

$uid = current_user_id();
$holder = post_string('cardholder_name', 100);
$cardNumberRaw = preg_replace('/\D/', '', post_string('card_number', 32));
$expiry = post_string('expiry_date', 7);
$cvv = preg_replace('/\D/', '', post_string('cvv', 4));
$brand = strtolower(post_string('brand', 20));
if (!in_array($brand, ['visa', 'mastercard'], true)) {
    $brand = 'visa';
}

if ($holder === '' || !preg_match('/^\d{16}$/', $cardNumberRaw) || !preg_match('/^\d{2}\/\d{2}$/', $expiry) || !preg_match('/^\d{3,4}$/', $cvv)) {
    set_flash('error', 'Please provide valid card details.');
    redirect('pages/virtual-cards.php');
}

$formatted = substr($cardNumberRaw, 0, 4) . ' ' . substr($cardNumberRaw, 4, 4) . ' ' . substr($cardNumberRaw, 8, 4) . ' ' . substr($cardNumberRaw, 12, 4);

try {
    $pdo->beginTransaction();
    $countSt = $pdo->prepare('SELECT COUNT(*) FROM virtual_cards WHERE user_id = ?');
    $countSt->execute([$uid]);
    $isDefault = ((int) $countSt->fetchColumn() === 0) ? 1 : 0;

    $hasLegacyExpiry = nixcash_column_exists($pdo, 'virtual_cards', 'expiry');
    $hasBalance = nixcash_column_exists($pdo, 'virtual_cards', 'balance');
    if ($hasLegacyExpiry && $hasBalance) {
        $st = $pdo->prepare(
            'INSERT INTO virtual_cards (user_id, cardholder_name, brand, card_number, expiry_date, expiry, cvv, is_default, pin_hash, balance)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, 0.00)'
        );
        $st->execute([$uid, $holder, $brand, $formatted, $expiry, $expiry, $cvv, $isDefault]);
    } elseif ($hasLegacyExpiry) {
        $st = $pdo->prepare(
            'INSERT INTO virtual_cards (user_id, cardholder_name, brand, card_number, expiry_date, expiry, cvv, is_default, pin_hash)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)'
        );
        $st->execute([$uid, $holder, $brand, $formatted, $expiry, $expiry, $cvv, $isDefault]);
    } elseif ($hasBalance) {
        $st = $pdo->prepare(
            'INSERT INTO virtual_cards (user_id, cardholder_name, brand, card_number, expiry_date, cvv, is_default, pin_hash, balance)
             VALUES (?, ?, ?, ?, ?, ?, ?, NULL, 0.00)'
        );
        $st->execute([$uid, $holder, $brand, $formatted, $expiry, $cvv, $isDefault]);
    } else {
        $st = $pdo->prepare(
            'INSERT INTO virtual_cards (user_id, cardholder_name, brand, card_number, expiry_date, cvv, is_default, pin_hash)
             VALUES (?, ?, ?, ?, ?, ?, ?, NULL)'
        );
        $st->execute([$uid, $holder, $brand, $formatted, $expiry, $cvv, $isDefault]);
    }
    $pdo->commit();
    set_flash('success', 'Card added successfully.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    set_flash('error', 'Could not add card.');
}

redirect('pages/virtual-cards.php');

