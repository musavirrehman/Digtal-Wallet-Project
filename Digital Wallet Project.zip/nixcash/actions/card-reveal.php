<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/virtual-card-schema.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();
ensure_virtual_card_schema($pdo);

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed']);
    exit;
}

$uid = current_user_id();
$cardId = post_int('card_id');
$password = post_string('password', 255);

if ($cardId <= 0 || $password === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $u = $pdo->prepare('SELECT password FROM users WHERE user_id = ? LIMIT 1');
    $u->execute([$uid]);
    $user = $u->fetch();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Unauthorized']);
        exit;
    }
    if (!password_verify($password, (string) $user['password'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Incorrect password']);
        exit;
    }

    $st = $pdo->prepare(
        'SELECT card_number, cvv, COALESCE(status, \'active\') AS card_status FROM virtual_cards WHERE card_id = ? AND user_id = ? LIMIT 1'
    );
    $st->execute([$cardId, $uid]);
    $card = $st->fetch();
    if (!$card) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Card not found']);
        exit;
    }
    if (($card['card_status'] ?? 'active') === 'blocked') {
        http_response_code(403);
        echo json_encode(['ok' => false, 'message' => 'This card has been suspended.']);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'card_number' => (string) $card['card_number'],
        'cvv' => (string) $card['cvv'],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not reveal card']);
}

