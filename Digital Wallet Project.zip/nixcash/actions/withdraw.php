<?php
/**
 * Withdraw to bank (demo — debits wallet).
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}

$uid = current_user_id();
$amount = post_money('amount');

if ($amount <= 0) {
    set_flash('error', 'Enter a valid amount.');
    redirect('index.php');
}

try {
    $pdo->beginTransaction();
    $ws = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE');
    $ws->execute([$uid]);
    $row = $ws->fetch();
    if (!$row || (float) $row['balance'] < $amount) {
        $pdo->rollBack();
        set_flash('error', 'Insufficient balance.');
        redirect('index.php');
    }

    $pdo->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id = ?')->execute([$amount, $uid]);
    $tx = $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (?, NULL, ?, ?, ?, ?)'
    );
    $tx->execute([$uid, $amount, 'withdraw', 'bank', 'Withdrawal to bank']);
    $pdo->commit();
    set_flash('success', 'Withdrawal processed.');
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Withdrawal failed.');
}

redirect('index.php');
