<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/mobile-recharge.php');
}

$uid = current_user_id();
$phone = post_string('phone', 20);
$amount = post_money('amount');

if ($phone === '' || $amount <= 0) {
    set_flash('error', 'Enter phone number and amount.');
    redirect('pages/mobile-recharge.php');
}

try {
    $pdo->beginTransaction();
    $ws = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE');
    $ws->execute([$uid]);
    $w = $ws->fetch();
    if (!$w || (float) $w['balance'] < $amount) {
        $pdo->rollBack();
        set_flash('error', 'Insufficient balance.');
        redirect('pages/mobile-recharge.php');
    }

    $pdo->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id = ?')->execute([$amount, $uid]);
    $tx = $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (?, NULL, ?, ?, ?, ?)'
    );
    $tx->execute([$uid, $amount, 'recharge', 'mobile', 'Mobile recharge — ' . $phone]);

    $pdo->commit();
    set_flash('success', 'Recharge successful.');
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Recharge failed.');
}

redirect('pages/mobile-recharge.php');
