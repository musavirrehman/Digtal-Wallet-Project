<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/virtual-card-schema.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();
ensure_virtual_card_schema($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/virtual-cards.php');
}

$uid = current_user_id();
$cardId = post_int('card_id');

if ($cardId <= 0) {
    set_flash('error', 'Invalid card.');
    redirect('pages/virtual-cards.php');
}

try {
    $pdo->beginTransaction();
    $st = $pdo->prepare('SELECT card_id, is_default FROM virtual_cards WHERE card_id = ? AND user_id = ? LIMIT 1');
    $st->execute([$cardId, $uid]);
    $card = $st->fetch();
    if (!$card) {
        $pdo->rollBack();
        set_flash('error', 'Card not found.');
        redirect('pages/virtual-cards.php');
    }

    $pdo->prepare('DELETE FROM virtual_cards WHERE card_id = ? AND user_id = ?')->execute([$cardId, $uid]);

    if ((int) $card['is_default'] === 1) {
        $next = $pdo->prepare('SELECT card_id FROM virtual_cards WHERE user_id = ? ORDER BY created_at DESC LIMIT 1');
        $next->execute([$uid]);
        $nextCard = $next->fetch();
        if ($nextCard) {
            $pdo->prepare('UPDATE virtual_cards SET is_default = 1 WHERE card_id = ? AND user_id = ?')->execute([(int) $nextCard['card_id'], $uid]);
        }
    }
    $pdo->commit();
    set_flash('success', 'Card deleted.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    set_flash('error', 'Could not delete card.');
}

redirect('pages/virtual-cards.php');

