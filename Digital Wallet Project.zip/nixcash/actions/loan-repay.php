<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/loan-schema.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/loan.php');
}

$uid = current_user_id();
if ($uid === null) {
    redirect('login.php');
}

$loanId = post_int('loan_id');

if ($loanId <= 0) {
    set_flash('error', 'Invalid loan ID.');
    redirect('pages/loan.php');
}

try {
    ensure_loan_schema($pdo);
    
    // Fetch the loan details
    $st = $pdo->prepare(
        'SELECT loan_id, user_id, amount, status, due_date, remaining_amount, penalty_applied 
         FROM loan_applications 
         WHERE loan_id = ? AND user_id = ? LIMIT 1'
    );
    $st->execute([$loanId, $uid]);
    $loan = $st->fetch(PDO::FETCH_ASSOC);
    
    if (!$loan) {
        set_flash('error', 'Loan not found.');
        redirect('pages/loan.php');
    }
    
    if ($loan['status'] !== 'approved') {
        set_flash('error', 'This loan is not eligible for repayment.');
        redirect('pages/loan.php');
    }
    
    $remainingAmount = (float) $loan['remaining_amount'];
    $dueDate = $loan['due_date'];
    $isLate = $dueDate !== null && strtotime($dueDate) < time();
    
    // Calculate tax and penalty
    $tax = 50; // Rs. 50 tax if paid within month
    $penalty = 200; // Rs. 200 penalty if late
    
    if ($isLate) {
        // Late payment: apply penalty if not already applied
        if ((int) $loan['penalty_applied'] === 0) {
            $totalDue = $remainingAmount + $penalty;
            $penaltyApplied = true;
        } else {
            $totalDue = $remainingAmount;
            $penaltyApplied = false;
        }
        $description = 'Late loan repayment #' . $loanId . ' (includes Rs. ' . $penalty . ' penalty)';
    } else {
        // On-time payment: apply tax
        $totalDue = $remainingAmount + $tax;
        $penaltyApplied = false;
        $description = 'Loan repayment #' . $loanId . ' (includes Rs. ' . $tax . ' tax)';
    }
    
    // Check user wallet balance
    $walletSt = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? LIMIT 1');
    $walletSt->execute([$uid]);
    $wallet = $walletSt->fetch(PDO::FETCH_ASSOC);
    
    if (!$wallet || (float) $wallet['balance'] < $totalDue) {
        set_flash('error', 'Insufficient balance. You need Rs. ' . format_money($totalDue) . ' to repay this loan.');
        redirect('pages/loan.php');
    }
    
    $pdo->beginTransaction();
    
    // Deduct from wallet
    $pdo->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id = ?')->execute([$totalDue, $uid]);
    
    // Update loan status to repaid
    $pdo->prepare(
        'UPDATE loan_applications SET status = ?, remaining_amount = 0, penalty_applied = ? WHERE loan_id = ? LIMIT 1'
    )->execute(['repaid', $penaltyApplied ? 1 : (int) $loan['penalty_applied'], $loanId]);
    
    // Record transaction
    $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (?, NULL, ?, ?, ?, ?)'
    )->execute([
        $uid,
        $totalDue,
        'loan_repayment',
        'loan',
        $description,
    ]);
    
    $pdo->commit();
    
    set_flash('success', 'Loan repaid successfully. Total paid: Rs. ' . format_money($totalDue));
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Could not process repayment. Try again later.');
}

redirect('pages/loan.php');
