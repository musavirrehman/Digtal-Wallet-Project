<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/profile.php');
}

$uid = current_user_id();

// Handle profile photo upload
if (!empty($_POST['update_photo']) && isset($_FILES['profile_image'])) {
    $uploadDir = dirname(__DIR__) . '/assets/images/profiles/';
    
    // Create directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $file = $_FILES['profile_image'];
    
    // Validate file
    if ($file['error'] !== UPLOAD_ERR_OK) {
        set_flash('error', 'Failed to upload image. Please try again.');
        redirect('pages/profile.php');
    }
    
    // Check file size (max 2MB)
    if ($file['size'] > 2 * 1024 * 1024) {
        set_flash('error', 'Image size must be less than 2MB.');
        redirect('pages/profile.php');
    }
    
    // Validate mime type
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes, true)) {
        set_flash('error', 'Invalid image format. Please use JPG, PNG, GIF, or WebP.');
        redirect('pages/profile.php');
    }
    
    // Generate unique filename
    $extension = match ($mimeType) {
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
        default => 'jpg'
    };
    $filename = 'user_' . $uid . '_' . time() . '.' . $extension;
    $filepath = $uploadDir . $filename;
    
    // Delete old profile image if exists
    try {
        $st = $pdo->prepare('SELECT profile_image FROM users WHERE user_id = ?');
        $st->execute([$uid]);
        $oldImage = $st->fetchColumn();
        if ($oldImage && file_exists($uploadDir . $oldImage)) {
            unlink($uploadDir . $oldImage);
        }
    } catch (Throwable $e) {
        // Ignore errors when deleting old image
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        try {
            $st = $pdo->prepare('UPDATE users SET profile_image = ? WHERE user_id = ?');
            $st->execute([$filename, $uid]);
            set_flash('success', 'Profile photo updated successfully.');
        } catch (Throwable $e) {
            set_flash('error', 'Could not save profile photo.');
        }
    } else {
        set_flash('error', 'Failed to save image. Please try again.');
    }
    
    redirect('pages/profile.php');
}

// Handle regular profile update
$name = post_string('name', 100);
$phone = post_string('phone', 20);
$bio = post_string('bio', 250);
$location = post_string('location', 100);

if ($name === '') {
    set_flash('error', 'Name is required.');
    redirect('pages/profile.php');
}

try {
    $st = $pdo->prepare('UPDATE users SET name = ?, phone = ?, bio = ?, location = ? WHERE user_id = ?');
    $st->execute([$name, $phone ?: null, $bio ?: null, $location ?: null, $uid]);
    $_SESSION['user_name'] = $name;
    set_flash('success', 'Profile updated.');
} catch (Throwable $e) {
    set_flash('error', 'Could not update profile.');
}

redirect('pages/profile.php');
