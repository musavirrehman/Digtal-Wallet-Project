<?php
/**
 * E-statement PDF for a date range (wallet activity).
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/fpdf.php';

require_login();

$uid = current_user_id();

function estatement_parse_date(?string $v): ?string
{
    if ($v === null || $v === '') {
        return null;
    }
    $v = trim($v);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) {
        return null;
    }
    $ts = strtotime($v . ' 12:00:00');
    if ($ts === false) {
        return null;
    }
    return date('Y-m-d', $ts);
}

function estatement_pdf_safe(string $s): string
{
    if (function_exists('iconv')) {
        $t = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $s);
        if ($t !== false) {
            return $t;
        }
    }
    return preg_replace('/[^\x20-\x7E]/', '?', $s);
}

$start = estatement_parse_date(isset($_GET['start']) ? (string) $_GET['start'] : null);
$end = estatement_parse_date(isset($_GET['end']) ? (string) $_GET['end'] : null);

if ($start === null || $end === null) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Invalid or missing start/end date. Use YYYY-MM-DD.';
    exit;
}

if (strcmp($start, $end) > 0) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Start date must be on or before end date.';
    exit;
}

$startTs = strtotime($start . ' 00:00:00');
$endTs = strtotime($end . ' 23:59:59');
if ($startTs === false || $endTs === false) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Invalid date range.';
    exit;
}

$maxRange = 366 * 86400;
if ($endTs - $startTs > $maxRange) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Date range cannot exceed one year.';
    exit;
}

$startDt = date('Y-m-d H:i:s', $startTs);
$endDt = date('Y-m-d H:i:s', $endTs);

$st = $pdo->prepare(
    'SELECT t.*, us.name AS sender_name, ur.name AS recv_name
     FROM transactions t
     LEFT JOIN users us ON us.user_id = t.sender_id
     LEFT JOIN users ur ON ur.user_id = t.receiver_id
     WHERE (t.sender_id = ? OR t.receiver_id = ?)
       AND t.created_at >= ? AND t.created_at <= ?
     ORDER BY t.created_at ASC'
);
$st->execute([$uid, $uid, $startDt, $endDt]);
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

$userName = isset($_SESSION['user_name']) ? (string) $_SESSION['user_name'] : 'User';
$userEmail = isset($_SESSION['user_email']) ? (string) $_SESSION['user_email'] : '';

$totalDebit = 0.0;
$totalCredit = 0.0;
foreach ($rows as $r) {
    $amt = (float) $r['amount'];
    if ($r['sender_id'] !== null && (int) $r['sender_id'] === $uid) {
        $totalDebit += $amt;
    }
    if ($r['receiver_id'] !== null && (int) $r['receiver_id'] === $uid) {
        $totalCredit += $amt;
    }
}

$pdf = new FPDF('L', 'mm', 'A4');
$pdf->SetMargins(10, 10, 10);
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 8, estatement_pdf_safe('NixCash — Account e-statement'), 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 6, estatement_pdf_safe($userName . ($userEmail !== '' ? ' · ' . $userEmail : '')), 0, 1);
$pdf->Cell(0, 6, estatement_pdf_safe('Period: ' . $start . ' to ' . $end . ' · Generated: ' . date('Y-m-d H:i')), 0, 1);
$pdf->Ln(3);

$pdf->SetFont('Arial', 'B', 9);
$wDate = 42;
$wType = 32;
$wDesc = 108;
$wOut = 34;
$wIn = 34;
$pdf->Cell($wDate, 7, estatement_pdf_safe('Date & time'), 1, 0, 'L');
$pdf->Cell($wType, 7, estatement_pdf_safe('Type'), 1, 0, 'L');
$pdf->Cell($wDesc, 7, estatement_pdf_safe('Description'), 1, 0, 'L');
$pdf->Cell($wOut, 7, estatement_pdf_safe('Debit (PKR)'), 1, 0, 'R');
$pdf->Cell($wIn, 7, estatement_pdf_safe('Credit (PKR)'), 1, 1, 'R');

$pdf->SetFont('Arial', '', 8);
foreach ($rows as $r) {
    $amt = (float) $r['amount'];
    $isOut = $r['sender_id'] !== null && (int) $r['sender_id'] === $uid;
    $isIn = $r['receiver_id'] !== null && (int) $r['receiver_id'] === $uid;
    $debit = '';
    $credit = '';
    if ($isOut) {
        $debit = format_money($amt);
    }
    if ($isIn) {
        $credit = format_money($amt);
    }

    $when = date('Y-m-d H:i', strtotime($r['created_at']));
    $typeLabel = estatement_pdf_safe(str_replace('_', ' ', (string) $r['type']));
    $desc = (string) ($r['description'] ?? '');
    if ($desc === '') {
        $desc = ucfirst(str_replace('_', ' ', (string) $r['type']));
    }
    if ($r['type'] === 'send' && !empty($r['sender_name']) && !empty($r['recv_name'])) {
        $desc .= ' · ' . $r['sender_name'] . ' -> ' . $r['recv_name'];
    }
    if (function_exists('mb_substr')) {
        $desc = mb_substr($desc, 0, 120, 'UTF-8');
    } else {
        $desc = substr($desc, 0, 120);
    }
    $desc = estatement_pdf_safe($desc);

    $lineH = 6;
    $pdf->Cell($wDate, $lineH, estatement_pdf_safe($when), 1, 0, 'L');
    $pdf->Cell($wType, $lineH, $typeLabel, 1, 0, 'L');
    $pdf->Cell($wDesc, $lineH, $desc, 1, 0, 'L');
    $pdf->Cell($wOut, $lineH, $debit !== '' ? estatement_pdf_safe($debit) : '', 1, 0, 'R');
    $pdf->Cell($wIn, $lineH, $credit !== '' ? estatement_pdf_safe($credit) : '', 1, 1, 'R');

    if ($pdf->GetY() > 185) {
        $pdf->AddPage();
    }
}

$pdf->Ln(2);
$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell($wDate + $wType + $wDesc, 7, estatement_pdf_safe('Totals for period'), 1, 0, 'R');
$pdf->Cell($wOut, 7, estatement_pdf_safe(format_money($totalDebit)), 1, 0, 'R');
$pdf->Cell($wIn, 7, estatement_pdf_safe(format_money($totalCredit)), 1, 1, 'R');

$pdf->SetFont('Arial', 'I', 8);
$pdf->Ln(2);
$pdf->MultiCell(0, 5, estatement_pdf_safe('Debit = money you sent or spent; Credit = money you received. This is a demo statement for your records.'));

$fname = 'NixCash-estatement-' . $start . '-to-' . $end . '.pdf';
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . str_replace(['"', "\r", "\n"], '', $fname) . '"');
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');
$pdf->Output('D');
