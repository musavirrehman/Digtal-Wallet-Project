<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/virtual-card-schema.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();
ensure_virtual_card_schema($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/virtual-cards.php');
}

$uid = current_user_id();
$amount = post_money('amount');
$cardType = isset($_POST['card_type']) ? strtolower(trim($_POST['card_type'])) : 'visa';

// Validate card type
if (!in_array($cardType, ['visa', 'mastercard'], true)) {
    $cardType = 'visa';
}

if ($amount < 1) {
    set_flash('error', 'Enter an amount of at least Rs. 1.00 to load from your wallet onto the new card.');
    redirect('pages/virtual-cards.php');
}

$holderSt = $pdo->prepare('SELECT name FROM users WHERE user_id = ? LIMIT 1');
$holderSt->execute([$uid]);
$holder = (string) ($holderSt->fetchColumn() ?: 'NixCash User');

try {
    $pdo->beginTransaction();

    $ws = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE');
    $ws->execute([$uid]);
    $w = $ws->fetch();
    if (!$w || (float) $w['balance'] < $amount) {
        $pdo->rollBack();
        set_flash('error', 'Insufficient wallet balance.');
        redirect('pages/virtual-cards.php');
    }

    $pdo->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id = ?')->execute([$amount, $uid]);

    $tx = $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (?, NULL, ?, ?, ?, ?)'
    );
    $tx->execute([$uid, $amount, 'virtual_card', 'cards', 'Virtual card issued — load from wallet']);

    $formatted = nixcash_generate_card_number_formatted($cardType);
    $cvv = (string) random_int(100, 999);
    $expiry = (new DateTimeImmutable('+36 months'))->format('m/y');
    $brand = $cardType;

    $countSt = $pdo->prepare('SELECT COUNT(*) FROM virtual_cards WHERE user_id = ?');
    $countSt->execute([$uid]);
    $isDefault = ((int) $countSt->fetchColumn() === 0) ? 1 : 0;

    $hasLegacyExpiry = nixcash_column_exists($pdo, 'virtual_cards', 'expiry');
    $hasBalance = nixcash_column_exists($pdo, 'virtual_cards', 'balance');

    if ($hasLegacyExpiry && $hasBalance) {
        $st = $pdo->prepare(
            'INSERT INTO virtual_cards (user_id, cardholder_name, brand, card_number, expiry_date, expiry, cvv, is_default, pin_hash, balance)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)'
        );
        $st->execute([$uid, $holder, $brand, $formatted, $expiry, $expiry, $cvv, $isDefault, $amount]);
    } elseif ($hasLegacyExpiry) {
        $st = $pdo->prepare(
            'INSERT INTO virtual_cards (user_id, cardholder_name, brand, card_number, expiry_date, expiry, cvv, is_default, pin_hash)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)'
        );
        $st->execute([$uid, $holder, $brand, $formatted, $expiry, $expiry, $cvv, $isDefault]);
    } elseif ($hasBalance) {
        $st = $pdo->prepare(
            'INSERT INTO virtual_cards (user_id, cardholder_name, brand, card_number, expiry_date, cvv, is_default, pin_hash, balance)
             VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?)'
        );
        $st->execute([$uid, $holder, $brand, $formatted, $expiry, $cvv, $isDefault, $amount]);
    } else {
        $st = $pdo->prepare(
            'INSERT INTO virtual_cards (user_id, cardholder_name, brand, card_number, expiry_date, cvv, is_default, pin_hash)
             VALUES (?, ?, ?, ?, ?, ?, ?, NULL)'
        );
        $st->execute([$uid, $holder, $brand, $formatted, $expiry, $cvv, $isDefault]);
    }

    $pdo->commit();
    set_flash('success', 'Virtual card generated and loaded from your wallet.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    set_flash('error', 'Could not generate card. Please try again.');
}

redirect('pages/virtual-cards.php');
