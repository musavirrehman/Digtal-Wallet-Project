<?php
/**
 * Move money from wallet into a savings goal (PDO transaction).
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/goals.php');
}

$uid = current_user_id();
$goalId = post_int('goal_id');
$amount = post_money('amount');

if ($goalId <= 0 || $amount <= 0) {
    set_flash('error', 'Invalid input.');
    redirect('pages/goals.php');
}

try {
    $pdo->beginTransaction();

    $g = $pdo->prepare('SELECT goal_id, target_amount, saved_amount FROM goals WHERE goal_id = ? AND user_id = ? FOR UPDATE');
    $g->execute([$goalId, $uid]);
    $goal = $g->fetch();
    if (!$goal) {
        $pdo->rollBack();
        set_flash('error', 'Goal not found.');
        redirect('pages/goals.php');
    }

    $ws = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE');
    $ws->execute([$uid]);
    $w = $ws->fetch();
    if (!$w) {
        $pdo->rollBack();
        set_flash('error', 'Wallet not found.');
        redirect('pages/goals.php');
    }
    $target = (float) $goal['target_amount'];
    $saved = (float) $goal['saved_amount'];
    $remaining = max(0, $target - $saved);
    if ($remaining <= 0) {
        $pdo->rollBack();
        set_flash('error', 'This goal is already fully funded.');
        redirect('pages/goals.php');
    }

    $debit = min($amount, $remaining);
    if ((float) $w['balance'] < $debit) {
        $pdo->rollBack();
        set_flash('error', 'Insufficient wallet balance.');
        redirect('pages/goals.php');
    }

    $newSaved = $saved + $debit;
    $pdo->prepare('UPDATE wallets SET balance = balance - ? WHERE user_id = ?')->execute([$debit, $uid]);
    $pdo->prepare('UPDATE goals SET saved_amount = ? WHERE goal_id = ?')->execute([$newSaved, $goalId]);

    $tx = $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (?, NULL, ?, ?, ?, ?)'
    );
    $tx->execute([$uid, $debit, 'goal', 'savings', 'Contribution to goal #' . $goalId]);

    $pdo->commit();
    set_flash('success', 'Saved toward your goal.');
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Could not save to goal.');
}

redirect('pages/goals.php');
