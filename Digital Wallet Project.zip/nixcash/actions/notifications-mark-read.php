<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/split-bills.php');
}

$uid = current_user_id();
try {
    $pdo->prepare('UPDATE user_notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0')->execute([$uid]);
    set_flash('success', 'Alerts marked as read.');
} catch (Throwable $e) {
    set_flash('error', 'Could not update alerts.');
}

redirect('pages/split-bills.php');
