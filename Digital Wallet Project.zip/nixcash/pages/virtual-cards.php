<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/virtual-card-schema.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

$uid = current_user_id();
ensure_virtual_card_schema($pdo);
$pageTitle = 'My Cards';
$hideBottomNav = false;

$userSt = $pdo->prepare('SELECT name FROM users WHERE user_id = ? LIMIT 1');
$userSt->execute([$uid]);
$user = $userSt->fetch() ?: ['name' => 'NixCash User'];

$cardSt = $pdo->prepare('SELECT * FROM virtual_cards WHERE user_id = ? ORDER BY is_default DESC, created_at DESC');
$cardSt->execute([$uid]);
$cards = $cardSt->fetchAll();

$walletBal = user_balance($pdo, $uid);

$nixVcpCssPath = dirname(__DIR__) . '/assets/css/virtual-cards.css';
$nixVcpCssVer = is_file($nixVcpCssPath) ? (int) filemtime($nixVcpCssPath) : time();

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
?>
<link rel="stylesheet" href="<?= esc(url_for('assets/css/virtual-cards.css')) ?>?v=<?= $nixVcpCssVer ?>">

<main class="vcp-page px-3 pb-4">
    <header class="vcp-header">
        <a href="<?= esc(url_for('index.php')) ?>" class="vcp-header-back" aria-label="Back to dashboard">
            <i class="bi bi-chevron-left"></i>
        </a>
        <h1 class="vcp-title">My Cards</h1>
        <button type="button" class="vcp-icon-btn" data-bs-toggle="offcanvas" data-bs-target="#nixMenu" aria-label="Menu"><i class="bi bi-three-dots"></i></button>
    </header>

    <section class="vcp-cards">
        <?php foreach ($cards as $index => $card): ?>
            <?php
            $cardId = (int) $card['card_id'];
            $number = (string) $card['card_number'];
            $digits = preg_replace('/\D/', '', $number);
            $last4 = strlen($digits) >= 4 ? substr($digits, -4) : '0000';
            $brand = strtolower((string) ($card['brand'] ?? 'visa'));
            $brand = in_array($brand, ['visa', 'mastercard'], true) ? $brand : 'visa';
            $holder = (string) ($card['cardholder_name'] ?? $user['name']);
            $expiry = (string) ($card['expiry_date'] ?? ($card['expiry'] ?? '01/30'));
            $cvvRaw = (string) ($card['cvv'] ?? '');
            $cvvMasked = $cvvRaw !== '' ? str_repeat('•', max(3, strlen($cvvRaw))) : '•••';
            $masked = mask_card($number);
            $cardBlocked = (($card['status'] ?? 'active') === 'blocked');
            ?>
            <article
                class="vcp-card-wrap js-card-wrap<?= $cardBlocked ? ' opacity-75' : '' ?>"
                data-card-id="<?= $cardId ?>"
                data-card-number="<?= esc($number) ?>"
                data-card-cvv="<?= esc($cvvRaw) ?>"
                data-card-blocked="<?= $cardBlocked ? '1' : '0' ?>"
            >
                <div class="vcp-card-scene">
                    <div class="vcp-card js-flip-card vcp-theme-<?= ($index % 2) + 1 ?>">
                        <div class="vcp-face vcp-front">
                            <div class="vcp-front-top">
                                <div class="vcp-brand-logo">
                                    <?php if ($brand === 'mastercard'): ?>
                                        <span class="vcp-mc-logo" aria-label="Mastercard">
                                            <span></span><span></span>
                                        </span>
                                    <?php else: ?>
                                        <?= strtoupper($brand) ?>
                                    <?php endif; ?>
                                </div>
                                <?php if ((int) ($card['is_default'] ?? 0) === 1): ?>
                                    <span class="vcp-default">Default</span>
                                <?php endif; ?>
                                <?php if ($cardBlocked): ?>
                                    <span class="badge text-bg-danger ms-1">Blocked</span>
                                <?php endif; ?>
                            </div>

                            <div class="vcp-number js-card-number"><?= esc($masked) ?></div>

                            <div class="vcp-front-bottom">
                                <div class="vcp-label-col">
                                    <span class="vcp-label">Name</span>
                                    <strong><?= esc($holder) ?></strong>
                                </div>
                                <div class="vcp-label-col text-end">
                                    <span class="vcp-label">Valid Thru</span>
                                    <strong><?= esc($expiry) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="vcp-face vcp-card-back">
                            <p class="vcp-back-micro">This card remains the property of NixCash and must be returned upon request. Use only as authorized.</p>
                            <div class="vcp-mag-strip" aria-hidden="true"></div>
                            <p class="vcp-back-micro vcp-back-micro--below">Virtual debit for online and eligible merchant purchases. Not for cash advance.</p>
                            <div class="vcp-signature-panel">
                                <div class="vcp-signature-lines" aria-hidden="true"></div>
                                <div class="vcp-signature-ghost" aria-hidden="true"><?= esc($masked) ?></div>
                                <span class="vcp-cvv-print js-card-cvv" data-masked="<?= esc($cvvMasked) ?>"><?= esc($cvvMasked) ?></span>
                            </div>
                            <div class="vcp-back-terms">
                                <p>By using this card you agree to the NixCash Virtual Card Terms. NixCash may suspend or cancel the card for suspected fraud, misuse, or breach of these terms. You are responsible for all charges made with this card until it is reported lost or stolen.</p>
                                <p>Disputes must be reported within sixty (60) days of the transaction date. NixCash is not liable for merchant refusal, system outages, or third-party errors. For support, sign in to your NixCash wallet and contact customer care.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="vcp-actions">
                    <?php if ($cardBlocked): ?>
                        <p class="small text-danger mb-2 w-100">This card is suspended by an administrator.</p>
                    <?php endif; ?>
                    <button type="button" class="btn btn-sm nix-btn-ghost js-flip-toggle" <?= $cardBlocked ? 'disabled' : '' ?>>Flip</button>
                    <button type="button" class="btn btn-sm btn-nix-primary js-copy-number" <?= $cardBlocked ? 'disabled' : '' ?>>Copy</button>
                    <button type="button" class="btn btn-sm nix-btn-ghost js-show-details" <?= $cardBlocked ? 'disabled' : '' ?>>Details</button>
                    <form method="post" action="<?= esc(url_for('actions/card-set-default.php')) ?>">
                        <input type="hidden" name="card_id" value="<?= $cardId ?>">
                        <button type="submit" class="btn btn-sm nix-btn-ghost" <?= $cardBlocked ? 'disabled' : '' ?>>Set default</button>
                    </form>
                    <form method="post" action="<?= esc(url_for('actions/card-delete.php')) ?>" onsubmit="return confirm('Delete this card?');">
                        <input type="hidden" name="card_id" value="<?= $cardId ?>">
                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <?php if (count($cards) === 0): ?>
        <section class="vcp-empty text-center">
            <p class="text-muted small mb-2">No cards added yet.</p>
            <p class="text-muted small mb-0">Use “Generate card” to create a NixCash virtual card from your wallet.</p>
        </section>
    <?php endif; ?>

    <button type="button" class="btn vcp-add-btn w-100 mt-3" data-bs-toggle="modal" data-bs-target="#generateCardModal">
        <i class="bi bi-credit-card-2-front"></i> Generate card
    </button>
</main>

<div class="modal fade" id="generateCardModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content nix-modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title">Generate virtual card</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= esc(url_for('actions/card-generate.php')) ?>" id="generateCardForm">
                <div class="modal-body pt-2">
                    <p class="small text-muted mb-3">
                        Wallet balance: <strong class="text-body">Rs. <?= esc(format_money($walletBal)) ?></strong>
                    </p>
                    <p class="small text-muted mb-3">
                        Select your preferred card type and load amount. We'll create a card with a <strong class="text-body">random number</strong>, <strong class="text-body">CVV</strong>, and <strong class="text-body">expiry</strong>.
                    </p>
                    <div class="mb-3">
                        <label class="form-label">Card Type</label>
                        <div class="row g-2">
                            <div class="col-6">
                                <input type="radio" class="btn-check" name="card_type" id="cardTypeVisa" value="visa" checked>
                                <label class="btn btn-outline-primary w-100" for="cardTypeVisa">
                                    <i class="bi bi-credit-card me-1"></i> Visa
                                </label>
                            </div>
                            <div class="col-6">
                                <input type="radio" class="btn-check" name="card_type" id="cardTypeMastercard" value="mastercard">
                                <label class="btn btn-outline-primary w-100" for="cardTypeMastercard">
                                    <i class="bi bi-credit-card me-1"></i> Mastercard
                                </label>
                            </div>
                        </div>
                    </div>
                    <label class="form-label">Load amount from wallet (PKR)</label>
                    <input type="number" name="amount" class="form-control" step="0.01" min="1" value="500" required>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="submit" class="btn vcp-add-btn w-100">Generate card</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="revealModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content nix-modal-content">
                <div class="modal-header border-0">
                <h5 class="modal-title">Confirm it’s you</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="revealForm">
                <div class="modal-body pt-0">
                    <input type="hidden" id="revealCardId">
                    <p class="small text-muted mb-2">Enter your <strong class="text-body">NixCash account password</strong> to show the full card number and CVV on this card.</p>
                    <label class="form-label">Account password</label>
                    <input type="password" class="form-control" id="revealPassword" autocomplete="current-password" required>
                    <div id="revealError" class="text-danger small mt-2 d-none"></div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" class="btn vcp-add-btn w-100">Reveal card details</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$nixAfterBootstrapHtml = '<script>window.nixVirtualCards = { revealUrl: ' . json_encode(url_for('actions/card-reveal.php'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ', revealEnabled: true };</script>'
    . '<script src="' . esc(url_for('assets/js/virtual-cards.js')) . '"></script>';
require dirname(__DIR__) . '/partials/footer.php';
