<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/loan-schema.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

$uid = current_user_id();
ensure_loan_schema($pdo);

$pageTitle = 'Loan';
$subTitle = 'Apply for a loan';

$pending = $pdo->prepare(
    'SELECT loan_id, amount, note, status, created_at, approved_at, due_date, remaining_amount, penalty_applied 
     FROM loan_applications
     WHERE user_id = ? ORDER BY created_at DESC LIMIT 10'
);
$pending->execute([$uid]);
$myLoans = $pending->fetchAll(PDO::FETCH_ASSOC);

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
require dirname(__DIR__) . '/partials/subheader.php';
?>
<main class="px-3 pb-4 flex-grow-1">
    <div class="glass-card p-3 mb-3">
        <h2 class="h6 mb-2">Request a loan</h2>
        <p class="text-muted small mb-3">Submit an amount. An admin will review your request and, if approved, the funds will be added to your NixCash wallet.</p>
        <form method="post" action="<?= esc(url_for('actions/loan-apply.php')) ?>">
            <label class="form-label">Amount (PKR) <span class="text-muted">(Max: Rs. 10,000)</span></label>
            <input type="number" name="amount" class="form-control mb-2" step="0.01" min="1" max="10000" required placeholder="e.g. 5000">
            <label class="form-label">Note (optional)</label>
            <input type="text" name="note" class="form-control mb-3" maxlength="255" placeholder="Purpose of the loan">
            <button type="submit" class="btn btn-nix-primary w-100">Submit application</button>
        </form>
    </div>

    <div class="glass-card p-3">
        <h2 class="h6 mb-3">Your applications</h2>
        <?php if (count($myLoans) === 0): ?>
            <p class="text-muted small mb-0">No applications yet.</p>
        <?php else: ?>
            <?php foreach ($myLoans as $L): ?>
                <?php
                $st = (string) $L['status'];
                $badge = $st === 'approved' ? 'success' : ($st === 'rejected' ? 'danger' : ($st === 'repaid' ? 'info' : 'warning'));
                $isApproved = $st === 'approved';
                $isRepaid = $st === 'repaid';
                $dueDate = $L['due_date'];
                $isLate = $dueDate !== null && strtotime($dueDate) < time();
                $remainingAmount = (float) ($L['remaining_amount'] ?? $L['amount']);
                ?>
                <div class="d-flex justify-content-between align-items-start border-bottom py-2 nix-tx-item">
                    <div class="flex-grow-1">
                        <div class="small fw-medium">Rs. <?= esc(format_money((float) $L['amount'])) ?></div>
                        <div class="text-muted" style="font-size:0.75rem;">Applied: <?= esc(date('M j, Y g:i a', strtotime((string) $L['created_at']))) ?></div>
                        <?php if (!empty($L['note'])): ?>
                            <div class="text-muted small mt-1"><?= esc((string) $L['note']) ?></div>
                        <?php endif; ?>
                        
                        <?php if ($isApproved || $isRepaid): ?>
                            <?php if ($isApproved): ?>
                                <div class="mt-2 p-2 rounded" style="background-color: rgba(255,255,255,0.1);">
                                    <div class="small text-white"><strong>Remaining:</strong> Rs. <?= esc(format_money($remainingAmount)) ?></div>
                                    <?php if ($dueDate): ?>
                                        <div class="small <?= $isLate ? 'text-danger' : 'text-white-50' ?>">
                                            <strong>Due Date:</strong> <?= esc(date('M j, Y', strtotime((string) $dueDate))) ?>
                                            <?php if ($isLate): ?>
                                                <span class="badge bg-danger ms-1">OVERDUE - Rs. 200 Penalty</span>
                                            <?php else: ?>
                                                <span class="badge bg-success ms-1">On Time - Rs. 50 Tax</span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="mt-2 p-2 rounded" style="background-color: rgba(255,255,255,0.1);">
                                    <div class="small text-success"><strong>Status:</strong> Fully Repaid</div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex flex-column align-items-end ms-2">
                        <span class="badge text-bg-<?= esc($badge) ?>"><?= esc(ucfirst($st)) ?></span>
                        <?php if ($isApproved): ?>
                            <form method="post" action="<?= esc(url_for('actions/loan-repay.php')) ?>" class="mt-2">
                                <input type="hidden" name="loan_id" value="<?= esc($L['loan_id']) ?>">
                                <button type="submit" class="btn btn-sm btn-nix-primary">Repay</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>
<?php require dirname(__DIR__) . '/partials/footer.php'; ?>
