<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

$uid = current_user_id();
$pageTitle = 'Transactions';
$subTitle = 'Transactions';

$sentSt = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) AS v FROM transactions WHERE sender_id = ?');
$sentSt->execute([$uid]);
$totalSent = (float) $sentSt->fetch(PDO::FETCH_ASSOC)['v'];

$recvSt = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) AS v FROM transactions WHERE receiver_id = ?');
$recvSt->execute([$uid]);
$totalReceived = (float) $recvSt->fetch(PDO::FETCH_ASSOC)['v'];

$st = $pdo->prepare(
    'SELECT t.*,
            us.name AS sender_name, us.email AS sender_email,
            ur.name AS recv_name, ur.email AS recv_email
     FROM transactions t
     LEFT JOIN users us ON us.user_id = t.sender_id
     LEFT JOIN users ur ON ur.user_id = t.receiver_id
     WHERE t.sender_id = ? OR t.receiver_id = ?
     ORDER BY t.created_at DESC
     LIMIT 100'
);
$st->execute([$uid, $uid]);
$rows = $st->fetchAll();

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
require dirname(__DIR__) . '/partials/subheader.php';
?>
<main class="px-3 pb-4 flex-grow-1">
    <div class="row g-2 mb-3">
        <div class="col-6">
            <div class="glass-card p-3 h-100">
                <p class="small text-muted mb-1">Total received</p>
                <p class="h5 mb-0 text-success">+Rs. <?= esc(format_money($totalReceived)) ?></p>
            </div>
        </div>
        <div class="col-6">
            <div class="glass-card p-3 h-100">
                <p class="small text-muted mb-1">Total sent</p>
                <p class="h5 mb-0 text-danger">−Rs. <?= esc(format_money($totalSent)) ?></p>
            </div>
        </div>
    </div>

    <div class="glass-card p-3">
        <?php if (count($rows) === 0): ?>
            <p class="text-muted small mb-0">No transactions yet.</p>
        <?php else: ?>
            <?php foreach ($rows as $tx): ?>
                <?php
                $isOut = $tx['sender_id'] !== null && (int) $tx['sender_id'] === $uid;
                $isIn = $tx['receiver_id'] !== null && (int) $tx['receiver_id'] === $uid;
                if (!$isOut && !$isIn) {
                    $isOut = false;
                    $isIn = true;
                }
                $amt = (float) $tx['amount'];
                $label = $tx['description'] ?: ucfirst(str_replace('_', ' ', $tx['type']));
                $isBill = ($tx['type'] === 'bill' && $isOut);
                $billReceiptUrl = $isBill
                    ? url_for('pages/bill-receipt.php?id=' . (int) $tx['transaction_id'])
                    : '';
                $canReceipt = ($tx['type'] === 'send'
                    && $tx['sender_id'] !== null && $tx['receiver_id'] !== null
                    && !empty($tx['sender_email']) && !empty($tx['recv_email']));
                $receiptJson = null;
                if ($canReceipt) {
                    $rxRef = 'TXN-' . (int) $tx['transaction_id'];
                    $rxWhen = date('M j, Y \a\t g:i A', strtotime($tx['created_at']));
                    $rxNote = trim((string) ($tx['description'] ?? ''));
                    $receiptJson = [
                        'reference' => $rxRef,
                        'amount' => format_money($amt),
                        'currency' => 'PKR',
                        'date' => $rxWhen,
                        'fromName' => (string) $tx['sender_name'],
                        'fromEmail' => (string) $tx['sender_email'],
                        'toName' => (string) $tx['recv_name'],
                        'toEmail' => (string) $tx['recv_email'],
                        'category' => $tx['category'] ?: 'transfer',
                        'note' => $rxNote,
                    ];
                }
                ?>
                <div class="nix-tx-item d-flex justify-content-between align-items-center gap-2">
                    <div class="min-w-0 flex-grow-1">
                        <div class="small fw-medium"><?= esc($label) ?></div>
                        <div class="text-muted" style="font-size:0.75rem;">
                            <?= esc($tx['type']) ?> · <?= esc(date('M j, Y g:i a', strtotime($tx['created_at']))) ?>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2 flex-shrink-0">
                        <?php if ($isBill && $billReceiptUrl !== ''): ?>
                            <a href="<?= esc($billReceiptUrl) ?>"
                                class="btn btn-link btn-sm text-secondary p-1"
                                title="View bill receipt"
                                aria-label="View bill receipt">
                                <i class="bi bi-receipt" style="font-size:1.15rem;"></i>
                            </a>
                        <?php elseif ($canReceipt && $receiptJson !== null): ?>
                            <button type="button"
                                class="btn btn-link btn-sm text-secondary p-1 nix-tx-receipt-btn"
                                title="View receipt"
                                aria-label="View receipt"
                                data-nix-receipt="<?= esc(json_encode($receiptJson, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)) ?>">
                                <i class="bi bi-receipt" style="font-size:1.15rem;"></i>
                            </button>
                        <?php endif; ?>
                        <span class="fw-semibold <?= $isOut ? 'text-danger' : 'text-success' ?>">
                            <?= $isOut ? '-' : '+' ?>Rs. <?= esc(format_money($amt)) ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>

<?php require dirname(__DIR__) . '/partials/tx-receipt-modal.php'; ?>
<?php require dirname(__DIR__) . '/partials/footer.php'; ?>
