<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

$uid = current_user_id();
$tid = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($tid <= 0) {
    set_flash('error', 'Invalid receipt.');
    redirect('pages/bill-payment.php');
}

$st = $pdo->prepare(
    'SELECT transaction_id, amount, type, category, description, created_at
     FROM transactions
     WHERE transaction_id = ? AND sender_id = ? AND type = ?
     LIMIT 1'
);
$st->execute([$tid, $uid, 'bill']);
$tx = $st->fetch(PDO::FETCH_ASSOC);

if (!$tx) {
    set_flash('error', 'Receipt not found.');
    redirect('pages/bill-payment.php');
}

$amt = (float) $tx['amount'];
$ref = 'TXN-' . (int) $tx['transaction_id'];
$when = date('M j, Y \a\t g:i A', strtotime((string) $tx['created_at']));
$catKey = (string) ($tx['category'] ?? '');
$catLabels = ['electricity' => 'Electricity', 'gas' => 'Gas', 'internet' => 'Internet'];
$catLabel = $catLabels[$catKey] ?? ucfirst($catKey ?: 'Bill');
$detail = trim((string) ($tx['description'] ?? ''));
$name = (string) ($_SESSION['user_name'] ?? 'Account holder');
$email = (string) ($_SESSION['user_email'] ?? '');

$pageTitle = 'Bill receipt';
$subTitle = 'Bill receipt';

$exportPayload = [
    'reference' => $ref,
    'amount' => format_money($amt),
];

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
require dirname(__DIR__) . '/partials/subheader.php';
?>
<main class="px-3 pb-4 flex-grow-1">
    <p class="text-center text-muted small mb-3">Keep this screen as your payment confirmation.</p>

    <div class="glass-card p-3 nix-receipt-modal mb-3">
        <div id="nixBillReceiptCapture" class="nix-receipt-capture-sheet">
            <div class="nix-receipt-card text-center mb-4">
                <div class="nix-receipt-success-icon mx-auto mb-3" aria-hidden="true">
                    <span class="nix-receipt-check">&#10003;</span>
                </div>
                <p class="text-muted small mb-1">Bill payment successful</p>
                <h2 class="h3 fw-bold mb-1">Rs. <?= esc(format_money($amt)) ?></h2>
                <p class="text-muted small mb-0"><?= esc($ref) ?></p>
            </div>

            <div class="nix-receipt-details rounded-4 p-3 mb-2">
                <div class="row g-3 small">
                    <div class="col-6">
                        <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Date &amp; time</div>
                        <div class="fw-medium"><?= esc($when) ?></div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Type</div>
                        <div class="fw-medium">Bill payment</div>
                    </div>
                    <div class="col-12 border-top border-secondary pt-3 mt-1">
                        <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Paid by</div>
                        <div class="fw-medium"><?= esc($name) ?></div>
                        <?php if ($email !== ''): ?>
                            <div class="text-muted" style="font-size:0.8rem;"><?= esc($email) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 border-top border-secondary pt-3 mt-1">
                        <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Bill category</div>
                        <div class="fw-medium"><?= esc($catLabel) ?></div>
                    </div>
                    <?php if ($detail !== ''): ?>
                        <div class="col-12 border-top border-secondary pt-3 mt-1">
                            <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Details</div>
                            <div class="fw-medium text-break"><?= esc($detail) ?></div>
                        </div>
                    <?php endif; ?>
                    <div class="col-12 border-top border-secondary pt-3 mt-1">
                        <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Status</div>
                        <div class="text-success fw-medium"><span class="me-1" aria-hidden="true">&#9679;</span>Completed</div>
                    </div>
                </div>
            </div>
            <p class="text-center text-muted small mb-0 pt-1 nix-receipt-brand">NixCash</p>
        </div>
    </div>

    <script type="application/json" id="nix-bill-receipt-payload"><?= json_encode($exportPayload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>

    <p class="text-center text-muted small mb-3">Download your receipt as an image.</p>
    <div class="d-grid gap-2 mb-3">
        <button type="button" class="btn btn-nix-primary" id="btnDownloadBillReceiptPng">
            <i class="bi bi-file-earmark-image me-2"></i>Download as PNG
        </button>
        <button type="button" class="btn nix-btn-ghost rounded-4" id="btnDownloadBillReceiptJpg">
            <i class="bi bi-file-earmark-image me-2"></i>Download as JPG
        </button>
    </div>

    <div class="d-grid gap-2">
        <a href="<?= esc(url_for('pages/bill-payment.php')) ?>" class="btn nix-btn-ghost rounded-4">Pay another bill</a>
        <a href="<?= esc(url_for('pages/transactions.php')) ?>" class="btn nix-btn-ghost rounded-4">View activity</a>
    </div>
</main>
<?php require dirname(__DIR__) . '/partials/footer.php'; ?>
