<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

$uid = current_user_id();
$pageTitle = 'Split bills';
$subTitle = 'Split bills';

$st = $pdo->prepare(
    'SELECT sb.*, u.name AS creator_name FROM split_bills sb
     JOIN users u ON u.user_id = sb.created_by
     WHERE sb.created_by = ? OR sb.bill_id IN (SELECT bill_id FROM split_bill_members WHERE user_id = ?)
     ORDER BY sb.created_at DESC'
);
$st->execute([$uid, $uid]);
$bills = $st->fetchAll();

$membersByBill = [];
if (count($bills) > 0) {
    $ids = array_column($bills, 'bill_id');
    $in = implode(',', array_map('intval', $ids));
    $m = $pdo->query(
        "SELECT sbm.*, u.name, u.email FROM split_bill_members sbm
         JOIN users u ON u.user_id = sbm.user_id
         WHERE sbm.bill_id IN ($in)"
    );
    foreach ($m->fetchAll() as $row) {
        $bid = (int) $row['bill_id'];
        if (!isset($membersByBill[$bid])) {
            $membersByBill[$bid] = [];
        }
        $membersByBill[$bid][] = $row;
    }
}

$splitAlerts = [];
try {
    $as = $pdo->prepare(
        'SELECT notification_id, message, created_at FROM user_notifications
         WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT 12'
    );
    $as->execute([$uid]);
    $splitAlerts = $as->fetchAll();
} catch (Throwable $e) {
    $splitAlerts = [];
}

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
require dirname(__DIR__) . '/partials/subheader.php';
?>
<main class="px-3 pb-4 flex-grow-1">
    <div id="nix-page-config" class="d-none" data-user-suggest-url="<?= esc(url_for('api/user-suggest.php')) ?>"></div>
    <?php if (count($splitAlerts) > 0): ?>
        <div class="glass-card p-3 mb-3 border border-info border-opacity-25">
            <h2 class="h6 mb-2 d-flex align-items-center gap-2">
                <i class="bi bi-bell-fill text-info"></i> Split updates
            </h2>
            <ul class="list-unstyled small mb-0">
                <?php foreach ($splitAlerts as $al): ?>
                    <li class="py-2 border-bottom border-secondary border-opacity-25">
                        <?= esc($al['message']) ?>
                        <span class="text-muted d-block" style="font-size:0.72rem;">
                            <?= esc(date('M j, g:i a', strtotime($al['created_at']))) ?>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <form method="post" action="<?= esc(url_for('actions/notifications-mark-read.php')) ?>" class="mt-2 mb-0">
                <button type="submit" class="btn btn-sm btn-outline-secondary w-100 rounded-3">Mark alerts as read</button>
            </form>
        </div>
    <?php endif; ?>

    <div class="glass-card p-3 mb-4 nix-split-create">
        <h2 class="h6 mb-1">New split bill</h2>
        <p class="text-muted small mb-3">One email field per person. Choose equal or custom shares, and whether you count as a participant.</p>
        <form method="post" action="<?= esc(url_for('actions/split-create.php')) ?>" id="nix-split-form">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control mb-2" maxlength="120" placeholder="Dinner, rent, trip…" required>

            <label class="form-label">Total (PKR)</label>
            <input type="number" step="0.01" min="0.01" name="total_amount" id="split_total" class="form-control mb-3" required>

            <div class="mb-3">
                <span class="form-label d-block mb-2">How to divide</span>
                <div class="btn-group w-100" role="group" aria-label="Divide mode">
                    <input type="radio" class="btn-check" name="divide_mode" id="dm_equal" value="equal" checked>
                    <label class="btn btn-outline-secondary" for="dm_equal">Equal</label>
                    <input type="radio" class="btn-check" name="divide_mode" id="dm_custom" value="custom">
                    <label class="btn btn-outline-secondary" for="dm_custom">Custom</label>
                </div>
            </div>

            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="include_me" id="split_include_me" value="1" checked>
                <label class="form-check-label" for="split_include_me">Include me in the split <span class="text-muted">(I am part of the expense)</span></label>
            </div>

            <div id="split_creator_share_wrap" class="mb-3 d-none">
                <label class="form-label" for="creator_share">Your share (PKR)</label>
                <input type="number" step="0.01" min="0.01" name="creator_share" id="creator_share" class="form-control" placeholder="Your portion">
            </div>

            <label class="form-label mb-2">Members <span class="text-muted fw-normal">(registered emails only)</span></label>
            <div id="split_member_rows" class="mb-2">
                <?php for ($r = 0; $r < 4; $r++): ?>
                    <div class="row g-2 mb-2 align-items-end nix-split-member-row">
                        <div class="col-12 col-md-7 position-relative">
                            <input type="email" name="member_email[]" class="form-control split-member-email" placeholder="Start typing name or email…" autocomplete="off" spellcheck="false" aria-autocomplete="list">
                            <div class="nix-split-email-suggest list-group shadow-sm d-none position-absolute start-0 end-0 mt-1 rounded-3 border" style="z-index: 1060; max-height: 11rem; overflow-y: auto;"></div>
                        </div>
                        <div class="col-12 col-md-5 split_amount_col d-none">
                            <input type="number" step="0.01" min="0" name="member_amount[]" class="form-control" placeholder="Share (PKR)">
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
            <button type="button" class="btn btn-sm btn-outline-secondary mb-3" id="split_add_member_row">+ Add member row</button>

            <p class="small text-muted mb-3" id="split_equal_hint">The total is divided evenly across you (if included) and every member with a valid email.</p>
            <p class="small text-warning mb-3 d-none" id="split_custom_hint">Enter each person’s share; all amounts (including yours if included) must add up to the total.</p>

            <button type="submit" class="btn btn-nix-primary w-100 rounded-3">Create split bill</button>
        </form>
    </div>

    <?php foreach ($bills as $b): ?>
        <?php
        $bid = (int) $b['bill_id'];
        $mems = $membersByBill[$bid] ?? [];
        $mode = isset($b['divide_mode']) ? (string) $b['divide_mode'] : 'equal';
        $statusLabel = [
            'pending' => 'Pending',
            'partial' => 'Partially paid',
            'paid' => 'Fully paid',
        ][$b['status']] ?? ucfirst((string) $b['status']);
        ?>
        <div class="glass-card p-3 mb-3">
            <div class="d-flex justify-content-between align-items-start mb-2 gap-2">
                <div class="min-w-0">
                    <h3 class="h6 mb-1 text-truncate"><?= esc($b['title']) ?></h3>
                    <p class="text-muted small mb-0">
                        Total Rs. <?= esc(format_money((float) $b['total_amount'])) ?>
                        <span class="text-muted">·</span>
                        <span class="badge rounded-pill <?= $b['status'] === 'paid' ? 'bg-success' : ($b['status'] === 'partial' ? 'bg-info text-dark' : 'bg-secondary') ?>">
                            <?= esc($statusLabel) ?>
                        </span>
                    </p>
                </div>
                <span class="badge bg-dark bg-opacity-25 text-nowrap"><?= $mode === 'custom' ? 'Custom' : 'Equal' ?></span>
            </div>
            <p class="small text-muted mb-2">Organizer: <?= esc($b['creator_name']) ?></p>
            <ul class="list-unstyled small mb-3">
                <?php foreach ($mems as $mm): ?>
                    <li class="d-flex justify-content-between align-items-center py-2 border-bottom border-secondary border-opacity-25 gap-2">
                        <span class="text-truncate"><?= esc($mm['name']) ?></span>
                        <span class="text-nowrap text-end">
                            Rs. <?= esc(format_money((float) $mm['amount'])) ?>
                            <?php if ((int) $mm['paid_status'] === 1): ?>
                                <span class="badge bg-success ms-1">Paid</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark ms-1">Pending</span>
                            <?php endif; ?>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <?php
            $mine = null;
            foreach ($mems as $mm) {
                if ((int) $mm['user_id'] === $uid) {
                    $mine = $mm;
                    break;
                }
            }
            ?>
            <?php if ($mine && (int) $mine['paid_status'] === 0): ?>
                <form method="post" action="<?= esc(url_for('actions/split-pay.php')) ?>">
                    <input type="hidden" name="bill_id" value="<?= $bid ?>">
                    <button type="submit" class="btn btn-nix-primary w-100 rounded-3">Pay my share (Rs. <?= esc(format_money((float) $mine['amount'])) ?>)</button>
                </form>
            <?php elseif ($mine && (int) $mine['paid_status'] === 1): ?>
                <p class="small text-success mb-0"><i class="bi bi-check-circle me-1"></i>You have paid your share.</p>
            <?php elseif (!$mine): ?>
                <p class="small text-muted mb-0">You are the organizer for this split (not listed as owing a share).</p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <?php if (count($bills) === 0): ?>
        <p class="text-muted text-center small">No split bills yet.</p>
    <?php endif; ?>
</main>
<script>
(function () {
  var form = document.getElementById('nix-split-form');
  if (!form) return;

  function refreshDivideUI() {
    var custom = document.getElementById('dm_custom').checked;
    var includeMe = document.getElementById('split_include_me').checked;
    document.querySelectorAll('.split_amount_col').forEach(function (el) {
      el.classList.toggle('d-none', !custom);
    });
    var cr = document.getElementById('split_creator_share_wrap');
    if (cr) {
      cr.classList.toggle('d-none', !custom || !includeMe);
    }
    document.getElementById('split_equal_hint').classList.toggle('d-none', custom);
    document.getElementById('split_custom_hint').classList.toggle('d-none', !custom);
  }

  document.getElementById('dm_equal').addEventListener('change', refreshDivideUI);
  document.getElementById('dm_custom').addEventListener('change', refreshDivideUI);
  document.getElementById('split_include_me').addEventListener('change', refreshDivideUI);

  document.getElementById('split_add_member_row').addEventListener('click', function () {
    var wrap = document.getElementById('split_member_rows');
    var first = wrap.querySelector('.nix-split-member-row');
    if (!first) return;
    var clone = first.cloneNode(true);
    clone.querySelectorAll('input').forEach(function (inp) { inp.value = ''; });
    clone.querySelectorAll('.nix-split-email-suggest').forEach(function (bx) {
      bx.innerHTML = '';
      bx.classList.add('d-none');
    });
    wrap.appendChild(clone);
    refreshDivideUI();
  });

  refreshDivideUI();
})();
</script>
<?php require dirname(__DIR__) . '/partials/footer.php'; ?>
