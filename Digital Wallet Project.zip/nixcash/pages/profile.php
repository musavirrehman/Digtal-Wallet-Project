<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

$uid = current_user_id();
$pageTitle = 'Profile';
$subTitle = 'Profile';

$st = $pdo->prepare('SELECT name, email, phone, created_at, profile_image FROM users WHERE user_id = ?');
$st->execute([$uid]);
$user = $st->fetch();
$bal = user_balance($pdo, $uid);

$profileImage = $user['profile_image'] ?? null;

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
require dirname(__DIR__) . '/partials/subheader.php';
?>
<main class="px-3 pb-4 flex-grow-1">
    <div class="glass-card p-4 text-center mb-3 position-relative">
        <div class="position-relative d-inline-block mb-3">
            <div class="rounded-circle nix-avatar-ring d-inline-flex align-items-center justify-content-center nix-profile-avatar" style="width:80px;height:80px;overflow:hidden;">
                <?php if ($profileImage): ?>
                    <img src="<?= esc(url_for('assets/images/profiles/' . $profileImage)) ?>" alt="Profile" class="w-100 h-100 object-fit-cover">
                <?php else: ?>
                    <i class="bi bi-person-fill display-5 text-muted"></i>
                <?php endif; ?>
            </div>
            <button type="button" class="btn btn-sm btn-nix-primary rounded-circle position-absolute nix-profile-camera-btn" data-bs-toggle="modal" data-bs-target="#modalUpdatePhoto" title="Update photo" aria-label="Update photo">
                <i class="bi bi-camera-fill" aria-hidden="true"></i>
            </button>
        </div>
        <h2 class="h5 mb-1"><?= esc($user['name']) ?></h2>
        <p class="text-muted small mb-0"><?= esc($user['email']) ?></p>
        <p class="text-muted small">Member since <?= esc(date('M Y', strtotime($user['created_at']))) ?></p>
        <p class="mb-0 fw-semibold">Wallet: Rs. <?= esc(format_money($bal)) ?></p>
    </div>

    <div class="glass-card p-3 mb-3">
        <h3 class="h6 mb-3">Edit profile</h3>
        <form method="post" action="<?= esc(url_for('actions/profile-update.php')) ?>" enctype="multipart/form-data">
            <label class="form-label">Name</label>
            <input type="text" name="name" class="form-control mb-2" required maxlength="100" value="<?= esc($user['name']) ?>">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control mb-2" maxlength="20" value="<?= esc((string) $user['phone']) ?>" placeholder="Optional">
            <label class="form-label">Bio</label>
            <textarea name="bio" class="form-control mb-2" maxlength="250" rows="2" placeholder="Tell us a little about yourself..."><?= esc((string) ($user['bio'] ?? '')) ?></textarea>
            <label class="form-label">Location</label>
            <input type="text" name="location" class="form-control mb-3" maxlength="100" value="<?= esc((string) ($user['location'] ?? '')) ?>" placeholder="City, Country">
            <button type="submit" class="btn btn-nix-primary w-100">Save changes</button>
        </form>
    </div>

    <!-- Update Photo Modal -->
    <div class="modal fade" id="modalUpdatePhoto" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content nix-modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Update Profile Photo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post" action="<?= esc(url_for('actions/profile-update.php')) ?>" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="text-center mb-3">
                            <div class="rounded-circle nix-avatar-ring d-inline-flex align-items-center justify-content-center mb-3" style="width:100px;height:100px;overflow:hidden;">
                                <?php if ($profileImage): ?>
                                    <img src="<?= esc(url_for('assets/images/profiles/' . $profileImage)) ?>" alt="Profile" class="w-100 h-100 object-fit-cover" id="photoPreview">
                                <?php else: ?>
                                    <i class="bi bi-person-fill display-4 text-muted" id="photoPreviewIcon"></i>
                                    <img src="" alt="Profile" class="w-100 h-100 object-fit-cover d-none" id="photoPreview">
                                <?php endif; ?>
                            </div>
                        </div>
                        <label class="form-label">Choose photo</label>
                        <input type="file" name="profile_image" class="form-control mb-3" accept="image/jpeg,image/png,image/gif,image/webp" required onchange="previewProfilePhoto(this)">
                        <p class="text-muted small mb-0">Max size: 2MB. Supported: JPG, PNG, GIF, WebP</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn nix-btn-ghost rounded-4" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_photo" value="1" class="btn btn-nix-primary">Upload Photo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function previewProfilePhoto(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                var preview = document.getElementById('photoPreview');
                var icon = document.getElementById('photoPreviewIcon');
                if (preview) {
                    preview.src = e.target.result;
                    preview.classList.remove('d-none');
                }
                if (icon) {
                    icon.classList.add('d-none');
                }
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>

    <div class="d-grid gap-2">
        <a href="<?= esc(url_for('pages/transactions.php')) ?>" class="btn nix-btn-ghost rounded-4">Transaction history</a>
        <a href="<?= esc(url_for('logout.php')) ?>" class="btn btn-outline-danger rounded-4">Sign out</a>
    </div>
</main>
<?php require dirname(__DIR__) . '/partials/footer.php'; ?>
