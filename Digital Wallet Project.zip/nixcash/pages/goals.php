<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

$uid = current_user_id();
$pageTitle = 'Goals';
$subTitle = 'Savings goals';

$st = $pdo->prepare(
    'SELECT * FROM goals WHERE user_id = ? ORDER BY created_at DESC'
);
$st->execute([$uid]);
$goals = $st->fetchAll();

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
require dirname(__DIR__) . '/partials/subheader.php';
?>
<main class="px-3 pb-4 flex-grow-1">
    <div class="glass-card p-3 mb-3">
        <h2 class="h6 mb-3">New goal</h2>
        <form method="post" action="<?= esc(url_for('actions/goal-create.php')) ?>">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control mb-2" maxlength="120" placeholder="Vacation fund">
            <label class="form-label">Target (PKR)</label>
            <input type="number" step="0.01" min="0.01" name="target_amount" class="form-control mb-2" required>
            <label class="form-label">Deadline (optional)</label>
            <input type="date" name="deadline" class="form-control mb-3">
            <button type="submit" class="btn btn-nix-primary w-100">Create goal</button>
        </form>
    </div>

    <?php foreach ($goals as $g): ?>
        <?php
        $target = (float) $g['target_amount'];
        $saved = (float) $g['saved_amount'];
        $pct = $target > 0 ? min(100, round(100 * $saved / $target)) : 0;
        $remaining = max(0, $target - $saved);
        $isFunded = $remaining <= 0.00001;

        $deadlineRaw = (string) ($g['deadline'] ?? '');
        $deadlineTs = null;
        if ($deadlineRaw !== '') {
            $deadlineTs = strtotime($deadlineRaw . ' 23:59:59');
            if ($deadlineTs === false) {
                $deadlineTs = null;
            }
        }
        $daysLeft = null;
        $isOverdue = false;
        if ($deadlineTs !== null) {
            $todayTs = strtotime(date('Y-m-d') . ' 00:00:00');
            $diffDays = (int) floor(($deadlineTs - $todayTs) / 86400);
            $daysLeft = max(0, $diffDays);
            $isOverdue = $diffDays < 0 && !$isFunded;
        }
        ?>
        <div class="glass-card p-3 mb-3">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <div>
                    <h3 class="h6 mb-0"><?= esc($g['title']) ?></h3>
                    <p class="text-muted small mb-0">
                        Rs. <?= esc(format_money($saved)) ?> / <?= esc(format_money($target)) ?>
                        <?php if ($deadlineRaw !== ''): ?> · due <?= esc($deadlineRaw) ?><?php endif; ?>
                    </p>
                </div>
                <div class="text-end">
                    <?php if ($isFunded): ?>
                        <span class="badge bg-success bg-opacity-25 text-success rounded-pill">Funded</span>
                    <?php elseif ($isOverdue): ?>
                        <span class="badge bg-danger bg-opacity-25 text-danger rounded-pill">Overdue</span>
                    <?php else: ?>
                        <span class="badge bg-info bg-opacity-25 text-info rounded-pill">In progress</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="nix-progress mb-3">
                <div class="nix-progress-bar" style="width: <?= (int) $pct ?>%"></div>
                <div class="nix-progress-label"><?= (int) $pct ?>%</div>
            </div>
            <div class="row g-2 small mb-3">
                <div class="col-6">
                    <div class="text-muted" style="font-size:0.7rem;letter-spacing:0.06em;text-transform:uppercase;">Remaining</div>
                    <div class="fw-semibold">Rs. <?= esc(format_money($remaining)) ?></div>
                </div>
                <div class="col-6 text-end">
                    <div class="text-muted" style="font-size:0.7rem;letter-spacing:0.06em;text-transform:uppercase;">Deadline</div>
                    <div class="fw-semibold">
                        <?php if ($deadlineRaw !== ''): ?>
                            <?= esc($deadlineRaw) ?>
                            <?php if (!$isFunded && $daysLeft !== null): ?>
                                <span class="text-muted fw-normal">(<?= (int) $daysLeft ?>d left)</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="text-muted">No deadline</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <form method="post" action="<?= esc(url_for('actions/goal-contribute.php')) ?>" class="row g-2 align-items-end">
                <input type="hidden" name="goal_id" value="<?= (int) $g['goal_id'] ?>">
                <div class="col-8">
                    <label class="form-label small">Add from wallet</label>
                    <input type="number" step="0.01" min="0.01" name="amount" class="form-control form-control-sm" required>
                </div>
                <div class="col-4">
                    <button type="submit" class="btn btn-nix-primary w-100 btn-sm">Save</button>
                </div>
            </form>
        </div>
    <?php endforeach; ?>

    <?php if (count($goals) === 0): ?>
        <p class="text-muted text-center small">No goals yet. Create one above.</p>
    <?php endif; ?>
</main>
<?php require dirname(__DIR__) . '/partials/footer.php'; ?>
