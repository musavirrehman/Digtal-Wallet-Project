<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

require_once dirname(__DIR__) . '/includes/bill-companies.php';

$uid = current_user_id();
$pageTitle = 'Bill payment';
$subTitle = 'Pay bills';
$bal = user_balance($pdo, $uid);
$billCompanyJson = json_encode(
    pakistani_bill_company_map(),
    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
) ?: '{}';

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
require dirname(__DIR__) . '/partials/subheader.php';
?>
<main class="px-3 pb-4 flex-grow-1">
    <div class="glass-card p-3 mb-3">
        <p class="small text-muted mb-1">Wallet balance</p>
        <p class="h4 mb-0">Rs. <?= esc(format_money($bal)) ?></p>
    </div>

    <div class="glass-card p-3">
        <form method="post" action="<?= esc(url_for('actions/bill-pay.php')) ?>" id="billPayForm">
            <label class="form-label">Bill type</label>
            <select name="category" id="billCategory" class="form-select mb-3" required>
                <option value="electricity">Electricity</option>
                <option value="gas">Gas</option>
                <option value="internet">Internet</option>
            </select>
            <label class="form-label">Company (Pakistan)</label>
            <select name="company" id="billCompany" class="form-select mb-3" required>
                <option value="">Select company</option>
            </select>
            <label class="form-label">Bill ID / consumer number</label>
            <input type="text" name="bill_id" id="billConsumerId" class="form-control mb-3" maxlength="80" autocomplete="off" placeholder="">
            <label class="form-label">Amount (PKR)</label>
            <input type="number" step="0.01" min="0.01" name="amount" class="form-control mb-3" required>
            <button type="submit" class="btn btn-nix-primary w-100">Complete payment</button>
        </form>
    </div>
</main>
<script>
(function () {
  var map = <?= $billCompanyJson ?>;
  var cat = document.getElementById('billCategory');
  var comp = document.getElementById('billCompany');
  if (!cat || !comp || !map) return;
  function refill() {
    var c = cat.value;
    var list = map[c] || {};
    var prev = comp.value;
    comp.innerHTML = '';
    var opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = 'Select company';
    comp.appendChild(opt0);
    Object.keys(list).forEach(function (slug) {
      var o = document.createElement('option');
      o.value = slug;
      o.textContent = list[slug];
      comp.appendChild(o);
    });
    if (list[prev]) comp.value = prev;
  }
  cat.addEventListener('change', refill);
  refill();
})();
</script>
<?php require dirname(__DIR__) . '/partials/footer.php'; ?>
