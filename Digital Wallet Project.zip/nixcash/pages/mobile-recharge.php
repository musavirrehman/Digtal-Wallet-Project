<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

require_login();

$uid = current_user_id();
$pageTitle = 'Recharge';
$subTitle = 'Mobile recharge';
$bal = user_balance($pdo, $uid);

require dirname(__DIR__) . '/partials/header.php';
require dirname(__DIR__) . '/partials/top-menu.php';
require dirname(__DIR__) . '/partials/subheader.php';
?>
<main class="px-3 pb-4 flex-grow-1">
    <div class="glass-card p-3 mb-3">
        <p class="small text-muted mb-1">Wallet balance</p>
        <p class="h4 mb-0">Rs. <?= esc(format_money($bal)) ?></p>
    </div>

    <div class="glass-card p-3">
        <form method="post" action="<?= esc(url_for('actions/recharge.php')) ?>">
            <label class="form-label">Mobile number</label>
            <input type="text" name="phone" class="form-control mb-3" required maxlength="20" placeholder="03xx xxxxxxx">
            <label class="form-label">Amount (PKR)</label>
            <input type="number" step="0.01" min="0.01" name="amount" class="form-control mb-3" required>
            <button type="submit" class="btn btn-nix-primary w-100">Recharge now</button>
        </form>
    </div>
</main>
<?php require dirname(__DIR__) . '/partials/footer.php'; ?>
