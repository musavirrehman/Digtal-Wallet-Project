-- NixCash — Loan Repayment Feature Patch
-- Adds columns for loan repayment tracking

USE nixcash;

-- Add new columns to existing loan_applications table
ALTER TABLE loan_applications
    ADD COLUMN IF NOT EXISTS approved_at TIMESTAMP NULL DEFAULT NULL AFTER reviewed_at,
    ADD COLUMN IF NOT EXISTS due_date TIMESTAMP NULL DEFAULT NULL AFTER approved_at,
    ADD COLUMN IF NOT EXISTS remaining_amount DECIMAL(12,2) DEFAULT NULL AFTER due_date,
    ADD COLUMN IF NOT EXISTS penalty_applied TINYINT(1) NOT NULL DEFAULT 0 AFTER remaining_amount;

-- Modify status enum to include 'repaid'
ALTER TABLE loan_applications
    MODIFY COLUMN status ENUM('pending','approved','rejected','repaid') NOT NULL DEFAULT 'pending';
