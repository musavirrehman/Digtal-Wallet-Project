-- Patch: Add profile fields for user profile update feature
-- Adds profile_image, bio, and location columns to users table

ALTER TABLE users 
ADD COLUMN profile_image VARCHAR(255) DEFAULT NULL AFTER phone,
ADD COLUMN bio VARCHAR(250) DEFAULT NULL AFTER profile_image,
ADD COLUMN location VARCHAR(100) DEFAULT NULL AFTER bio;
