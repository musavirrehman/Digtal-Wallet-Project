-- NixCash admin panel — run once on existing database (phpMyAdmin or mysql client).
USE nixcash;

ALTER TABLE users
  ADD COLUMN role ENUM('user','admin') NOT NULL DEFAULT 'user' AFTER password,
  ADD COLUMN status ENUM('active','blocked') NOT NULL DEFAULT 'active' AFTER role;

UPDATE users
SET role = 'admin'
WHERE LOWER(TRIM(name)) = 'musavir rehman';

ALTER TABLE transactions
  ADD COLUMN admin_flagged TINYINT(1) NOT NULL DEFAULT 0 AFTER description;

ALTER TABLE virtual_cards
  ADD COLUMN status ENUM('active','blocked') NOT NULL DEFAULT 'active' AFTER is_default;
