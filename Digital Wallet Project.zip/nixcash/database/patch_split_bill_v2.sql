-- Run once on existing NixCash DB (phpMyAdmin or mysql client).
-- Adds split bill divide mode + in-app notifications.

USE nixcash;

CREATE TABLE IF NOT EXISTS user_notifications (
  notification_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  kind VARCHAR(32) NOT NULL,
  message VARCHAR(500) NOT NULL,
  bill_id INT UNSIGNED DEFAULT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (notification_id),
  KEY idx_un_user_created (user_id, created_at),
  CONSTRAINT fk_un_user FOREIGN KEY (user_id) REFERENCES users (user_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_un_bill FOREIGN KEY (bill_id) REFERENCES split_bills (bill_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE split_bills
  ADD COLUMN divide_mode ENUM('equal','custom') NOT NULL DEFAULT 'equal'
  AFTER total_amount;
