# NixCash

Digital wallet web app (PHP + MySQL), inspired by mobile money apps. Dark fintech UI with Bootstrap 5.

## Requirements

- PHP 8.0+ (with PDO MySQL)
- MySQL 5.7+ / MariaDB 10+
- Apache (e.g. XAMPP on Windows)

## Install on XAMPP (Windows)

1. Copy the `nixcash` folder into your XAMPP web root, for example:
   `C:\xampp\htdocs\nixcash`

2. Start **Apache** and **MySQL** from the XAMPP Control Panel.

3. Create the database:
   - Open `http://localhost/phpmyadmin`
   - Click **Import**, choose `database/nixcash.sql`, and run it  
   - Or from a terminal (XAMPP shell):
     ```bash
     cd C:\xampp\mysql\bin
     mysql -u root -p < C:\xampp\htdocs\nixcash\database\nixcash.sql
     ```

4. Configure DB credentials if needed:
   - Edit `config/config.php`
   - Default XAMPP MySQL user is `root` with an empty password (already set).

5. If your URL is not `http://localhost/nixcash/`, set `base_url` in `config/config.php` to match your folder path (e.g. `/myfolder`).

6. Open the app:
   `http://localhost/nixcash/register.php` — create an account, then use the dashboard.

## Features

- Register / login (password hashing, sessions)
- Wallet: add money, send to another user by email, withdraw
- Transaction history with income vs expense snapshot
- Savings goals with progress bar
- Split bills (registered users by email), pay share with wallet transfers
- Virtual cards (generated dummy numbers), load from wallet, pay merchant (demo)
- Bill payment (electricity, gas, internet) and mobile recharge (deducts wallet)
- Profile edit

Money movements that affect two wallets use **PDO transactions** (`BEGIN` / `COMMIT` / `ROLLBACK`) in the action scripts.

## Project layout

- `config/` — app config and PDO bootstrap
- `includes/` — session bootstrap, helpers, auth
- `partials/` — header, footer, navigation, menu
- `pages/` — main app screens
- `actions/` — POST handlers (forms)
- `assets/` — CSS and JavaScript
- `database/nixcash.sql` — schema and empty tables

## Security notes

This is a **demo** for learning. For production you would add HTTPS, CSRF tokens, stricter validation, rate limiting, and proper payment gateways.
