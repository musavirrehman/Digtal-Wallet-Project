<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

if (current_user_id() !== null) {
    redirect('index.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = post_string('name', 100);
    $email = post_email('email');
    $phone = post_string('phone', 20);
    $pass = isset($_POST['password']) ? (string) $_POST['password'] : '';
    $pass2 = isset($_POST['password_confirm']) ? (string) $_POST['password_confirm'] : '';

    if ($name === '' || $email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid name and email.';
    } elseif (strlen($pass) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($pass !== $pass2) {
        $error = 'Passwords do not match.';
    } else {
        $check = $pdo->prepare('SELECT user_id FROM users WHERE email = ? LIMIT 1');
        $check->execute([$email]);
        if ($check->fetch()) {
            $error = 'An account with this email already exists.';
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            try {
                $pdo->beginTransaction();
                if (nixcash_users_table_has_rbac_columns($pdo)) {
                    $ins = $pdo->prepare(
                        'INSERT INTO users (name, email, phone, password, role, status) VALUES (?, ?, ?, ?, \'user\', \'active\')'
                    );
                } else {
                    $ins = $pdo->prepare(
                        'INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)'
                    );
                }
                $ins->execute([$name, $email, $phone ?: null, $hash]);
                $uid = (int) $pdo->lastInsertId();
                $signupReward = 200.00;
                $w = $pdo->prepare('INSERT INTO wallets (user_id, balance) VALUES (?, ?)');
                $w->execute([$uid, $signupReward]);
                $tx = $pdo->prepare(
                    'INSERT INTO transactions (receiver_id, amount, type, category, description) VALUES (?, ?, \'credit\', \'reward\', \'Signup bonus\')'
                );
                $tx->execute([$uid, $signupReward]);
                $pdo->commit();
                login_user($uid, $name, $email, 'user');
                set_flash('success', 'Welcome to NixCash! You received ₹' . number_format($signupReward, 2) . ' signup bonus.');
                redirect('index.php');
            } catch (Throwable $e) {
                $pdo->rollBack();
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}

$pageTitle = 'Create account';
$hideBottomNav = true;
require __DIR__ . '/partials/header.php';
?>
<main class="auth-shell px-3">
    <div class="auth-card glass-card p-4 p-md-5">
        <div class="text-center mb-4">
            <div class="nix-logo fs-2 mb-1">NixCash</div>
            <p class="text-muted small mb-0">Digital wallet — fast, secure, modern</p>
        </div>
        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?= esc($error) ?></div>
        <?php endif; ?>
        <form method="post" action="" novalidate>
            <div class="mb-3">
                <label class="form-label">Full name</label>
                <input type="text" name="name" class="form-control" required maxlength="100"
                       value="<?= esc(post_string('name', 100)) ?>" autocomplete="name">
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required
                       value="<?= esc(post_email('email')) ?>" autocomplete="email">
            </div>
            <div class="mb-3">
                <label class="form-label">Phone <span class="text-muted">(optional)</span></label>
                <input type="text" name="phone" class="form-control" maxlength="20"
                       value="<?= esc(post_string('phone', 20)) ?>" autocomplete="tel">
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required minlength="6" autocomplete="new-password">
            </div>
            <div class="mb-4">
                <label class="form-label">Confirm password</label>
                <input type="password" name="password_confirm" class="form-control" required minlength="6" autocomplete="new-password">
            </div>
            <button type="submit" class="btn btn-nix-primary w-100 py-2">Create account</button>
        </form>
        <p class="text-center text-muted small mt-4 mb-0">
            Already have an account? <a href="<?= esc(url_for('login.php')) ?>" class="link-nix">Sign in</a>
        </p>
    </div>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
