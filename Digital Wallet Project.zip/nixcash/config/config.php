<?php
/**
 * NixCash — application configuration
 * Change base_url if the project folder name or path differs.
 */
return [
    'base_url'   => '/nixcash',
    'app_name'   => 'NixCash',
    /**
     * Only these identities may open /admin even if role is admin in the database.
     * Name match is case-insensitive; add verified admin emails here if needed.
     */
    'admin_operator' => [
        'names'  => ['Musavir Rehman'],
        'emails' => ['musavir@gmail.com'],
    ],
    'db' => [
        'host'    => '127.0.0.1',
        'name'    => 'nixcash',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],
];
