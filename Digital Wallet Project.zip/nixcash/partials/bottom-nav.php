<?php
$nav = current_nav();
?>
<nav class="nix-bottom-nav" aria-label="Main">
    <a href="<?= esc(url_for('index.php')) ?>" class="nix-nav-item <?= $nav === 'home' ? 'active' : '' ?>"<?= $nav === 'home' ? ' aria-current="page"' : '' ?> aria-label="Home">
        <span class="nix-nav-icon"><i class="bi bi-house-door-fill" aria-hidden="true"></i></span>
        <span class="nix-nav-label">Home</span>
    </a>
    <a href="<?= esc(url_for('pages/transactions.php')) ?>" class="nix-nav-item <?= $nav === 'transactions' ? 'active' : '' ?>"<?= $nav === 'transactions' ? ' aria-current="page"' : '' ?> aria-label="Transactions">
        <span class="nix-nav-icon"><i class="bi bi-arrow-left-right" aria-hidden="true"></i></span>
        <span class="nix-nav-label">Activity</span>
    </a>
    <a href="<?= esc(url_for('pages/goals.php')) ?>" class="nix-nav-item <?= $nav === 'goals' ? 'active' : '' ?>"<?= $nav === 'goals' ? ' aria-current="page"' : '' ?> aria-label="Goals">
        <span class="nix-nav-icon"><i class="bi bi-bullseye" aria-hidden="true"></i></span>
        <span class="nix-nav-label">Goals</span>
    </a>
    <a href="<?= esc(url_for('pages/virtual-cards.php')) ?>" class="nix-nav-item <?= $nav === 'cards' ? 'active' : '' ?>"<?= $nav === 'cards' ? ' aria-current="page"' : '' ?> aria-label="Cards">
        <span class="nix-nav-icon"><i class="bi bi-credit-card-2-front" aria-hidden="true"></i></span>
        <span class="nix-nav-label">Cards</span>
    </a>
    <a href="<?= esc(url_for('pages/profile.php')) ?>" class="nix-nav-item <?= $nav === 'profile' ? 'active' : '' ?>"<?= $nav === 'profile' ? ' aria-current="page"' : '' ?> aria-label="Profile">
        <span class="nix-nav-icon"><i class="bi bi-person-fill" aria-hidden="true"></i></span>
        <span class="nix-nav-label">Profile</span>
    </a>
</nav>
