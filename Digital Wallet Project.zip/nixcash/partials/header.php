<?php
if (!defined('NIXCASH_BASE')) {
    require_once __DIR__ . '/../includes/init.php';
}
$pageTitle = $pageTitle ?? 'NixCash';
$hideBottomNav = $hideBottomNav ?? false;
$nixStylePath = __DIR__ . '/../assets/css/style.css';
$nixStyleVer = is_file($nixStylePath) ? (int) filemtime($nixStylePath) : time();
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <script>
    (function () {
      try {
        var v = localStorage.getItem('nixcash_theme');
        document.documentElement.setAttribute('data-bs-theme', v === 'light' || v === 'dark' ? v : 'dark');
      } catch (e) {
        document.documentElement.setAttribute('data-bs-theme', 'dark');
      }
    })();
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($pageTitle) ?> — NixCash</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= esc(url_for('assets/css/style.css')) ?>?v=<?= $nixStyleVer ?>">
</head>
<body class="nix-body">
<div class="nix-bg-gradient"></div>
<div class="nix-app-wrap d-flex flex-column min-vh-100">
