<?php
$flash = get_flash();
if ($flash):
?>
<div class="position-fixed top-0 end-0 p-3 mt-5" style="z-index: 1080;">
    <div class="alert alert-<?= $flash['type'] === 'error' ? 'danger' : ($flash['type'] === 'success' ? 'success' : 'info') ?> shadow fade show" role="alert">
        <?= esc($flash['message']) ?>
    </div>
</div>
<?php endif; ?>

<?php if (empty($hideBottomNav) && current_user_id()): ?>
<?php require __DIR__ . '/bottom-nav.php'; ?>
<?php endif; ?>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php if (!empty($nixAfterBootstrapHtml ?? '')): ?>
<?= $nixAfterBootstrapHtml ?>
<?php endif; ?>
<script src="<?= esc(url_for('assets/js/main.js')) ?>"></script>
</body>
</html>
