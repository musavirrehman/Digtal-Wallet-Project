<?php
/** @var string $subTitle */
$subTitle = $subTitle ?? 'Page';
?>
<header class="nix-page-header d-flex align-items-center justify-content-between px-3 pt-3">
    <div class="d-flex align-items-center gap-2">
        <a href="<?= esc(url_for('index.php')) ?>" class="btn btn-sm nix-btn-ghost rounded-circle" title="Back"><i class="bi bi-arrow-left"></i></a>
        <h1 class="h5 mb-0 fw-semibold"><?= esc($subTitle) ?></h1>
    </div>
    <button class="btn btn-sm nix-btn-ghost rounded-pill" type="button" data-bs-toggle="offcanvas" data-bs-target="#nixMenu">
        <i class="bi bi-grid-fill"></i>
    </button>
</header>
