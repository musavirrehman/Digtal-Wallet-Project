<?php
/**
 * Same layout as the post-send receipt on the home page; filled via JS when opened from Transactions.
 */
?>
<div class="modal fade" id="modalTxReceipt" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content nix-modal-content nix-receipt-modal">
            <div class="modal-header border-0 pb-0">
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-0">
                <div id="nixReceiptCaptureTx" class="nix-receipt-capture-sheet">
                    <div class="nix-receipt-card text-center mb-4">
                        <div class="nix-receipt-success-icon mx-auto mb-3" aria-hidden="true">
                            <span class="nix-receipt-check">&#10003;</span>
                        </div>
                        <p class="text-muted small mb-1">Payment successful</p>
                        <h2 class="h3 fw-bold mb-1"><span id="nixTxRxAmount">Rs. 0.00</span></h2>
                        <p class="text-muted small mb-0" id="nixTxRxRef">TXN-0</p>
                    </div>

                    <div class="nix-receipt-details rounded-4 p-3 mb-2">
                        <div class="row g-3 small">
                            <div class="col-6">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Date &amp; time</div>
                                <div class="fw-medium" id="nixTxRxWhen">—</div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Type</div>
                                <div class="fw-medium" id="nixTxRxTypeLabel">Money sent</div>
                            </div>
                            <div class="col-12">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">From</div>
                                <div class="fw-medium" id="nixTxRxFromName">—</div>
                                <div class="text-muted" style="font-size:0.8rem;" id="nixTxRxFromEmail">—</div>
                            </div>
                            <div class="col-12 border-top border-secondary pt-3 mt-1">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">To</div>
                                <div class="fw-medium" id="nixTxRxToName">—</div>
                                <div class="text-muted" style="font-size:0.8rem;" id="nixTxRxToEmail">—</div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Category</div>
                                <div class="fw-medium" id="nixTxRxCat">—</div>
                            </div>
                            <div class="col-6">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Status</div>
                                <div class="text-success fw-medium"><span class="me-1" aria-hidden="true">&#9679;</span>Completed</div>
                            </div>
                            <div class="col-12 border-top border-secondary pt-3 mt-1 d-none" id="nixTxRxNoteRow">
                                <div class="text-muted text-uppercase" style="font-size:0.65rem;letter-spacing:0.06em;">Note</div>
                                <div class="fw-medium" id="nixTxRxNote">—</div>
                            </div>
                        </div>
                    </div>
                    <p class="text-center text-muted small mb-0 pt-1 nix-receipt-brand">NixCash</p>
                </div>

                <p class="text-center text-muted small mb-3 mb-md-4 mt-3">Saved to your activity. Download your receipt as an image.</p>

                <div class="d-grid gap-2">
                    <button type="button" class="btn btn-nix-primary" id="btnDownloadReceiptPngTx">
                        <i class="bi bi-file-earmark-image me-2"></i>Download as PNG
                    </button>
                    <button type="button" class="btn nix-btn-ghost rounded-4" id="btnDownloadReceiptJpgTx">
                        <i class="bi bi-file-earmark-image me-2"></i>Download as JPG
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
