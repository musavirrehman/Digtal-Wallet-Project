<?php
/** Slide-out menu for services — included on dashboard & inner pages */
?>
<div class="offcanvas offcanvas-end" tabindex="-1" id="nixMenu" aria-labelledby="nixMenuLabel">
    <div class="offcanvas-header border-bottom nix-menu-theme">
        <h5 class="offcanvas-title" id="nixMenuLabel"><i class="bi bi-grid-3x3-gap-fill me-2"></i>Menu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body p-0 d-flex flex-column">
        <nav class="flex-grow-1">
            <a class="nix-menu-link" href="<?= esc(url_for('index.php')) ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <a class="nix-menu-link" href="<?= esc(url_for('pages/transactions.php')) ?>">
                <i class="bi bi-receipt"></i> Transactions
            </a>
            <a class="nix-menu-link" href="<?= esc(url_for('pages/goals.php')) ?>">
                <i class="bi bi-piggy-bank"></i> Savings Goals
            </a>
            <a class="nix-menu-link" href="<?= esc(url_for('pages/split-bills.php')) ?>">
                <i class="bi bi-people"></i> Split Bills
            </a>
            <a class="nix-menu-link" href="<?= esc(url_for('pages/virtual-cards.php')) ?>">
                <i class="bi bi-credit-card"></i> Virtual Cards
            </a>
            <a class="nix-menu-link" href="<?= esc(url_for('pages/bill-payment.php')) ?>">
                <i class="bi bi-lightning-charge"></i> Bill Payment
            </a>
            <a class="nix-menu-link" href="<?= esc(url_for('pages/mobile-recharge.php')) ?>">
                <i class="bi bi-phone"></i> Mobile Recharge
            </a>
            <a class="nix-menu-link" href="<?= esc(url_for('pages/loan.php')) ?>">
                <i class="bi bi-bank2"></i> Loan
            </a>
            <a class="nix-menu-link" href="<?= esc(url_for('pages/profile.php')) ?>">
                <i class="bi bi-person-badge"></i> Profile
            </a>
        </nav>
        <div class="p-3 border-top nix-menu-theme">
            <p class="small text-muted mb-2">Appearance</p>
            <div class="nix-theme-switch" role="group" aria-label="Color theme">
                <button type="button" class="btn" data-nix-theme="dark">Dark</button>
                <button type="button" class="btn" data-nix-theme="light">Light</button>
            </div>
        </div>
    </div>
</div>
