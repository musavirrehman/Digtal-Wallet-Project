<?php
declare(strict_types=1);

/**
 * Pakistani utility / ISP names grouped by bill category (demo bill pay UI).
 *
 * @return array<string, array<string, string>> category => slug => display label
 */
function pakistani_bill_company_map(): array
{
    return [
        'electricity' => [
            'kelectric' => 'K-Electric',
            'lesco' => 'LESCO',
            'fesco' => 'FESCO',
            'mepco' => 'MEPCO',
            'gepco' => 'GEPCO',
            'iesco' => 'IESCO',
            'hesco' => 'HESCO',
            'sepco' => 'SEPCO',
            'qesco' => 'QESCO',
            'tesco' => 'TESCO',
        ],
        'gas' => [
            'ssgc' => 'SSGC (Sui Southern Gas)',
            'sngpl' => 'SNGPL (Sui Northern Gas)',
        ],
        'internet' => [
            'jazz' => 'Jazz',
            'telenor' => 'Telenor Pakistan',
            'zong' => 'Zong',
            'ufone' => 'Ufone',
            'ptcl' => 'PTCL',
            'stormfiber' => 'StormFiber',
            'nayatel' => 'Nayatel',
            'fiberlink' => 'Fiberlink',
        ],
    ];
}

function bill_company_label(string $category, string $slug): ?string
{
    $map = pakistani_bill_company_map();
    return $map[$category][$slug] ?? null;
}
