<?php
/**
 * Ensures loan_applications table exists (no separate migration required for dev).
 */
function ensure_loan_schema(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS loan_applications (
            loan_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            amount DECIMAL(12,2) NOT NULL,
            note VARCHAR(255) DEFAULT NULL,
            status ENUM(\'pending\',\'approved\',\'rejected\',\'repaid\') NOT NULL DEFAULT \'pending\',
            reviewed_by INT UNSIGNED DEFAULT NULL,
            reviewed_at TIMESTAMP NULL DEFAULT NULL,
            approved_at TIMESTAMP NULL DEFAULT NULL,
            due_date TIMESTAMP NULL DEFAULT NULL,
            remaining_amount DECIMAL(12,2) DEFAULT NULL,
            penalty_applied TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (loan_id),
            KEY idx_loan_user (user_id),
            KEY idx_loan_status (status),
            CONSTRAINT fk_loan_app_user FOREIGN KEY (user_id) REFERENCES users (user_id)
                ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT fk_loan_app_reviewer FOREIGN KEY (reviewed_by) REFERENCES users (user_id)
                ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
    $done = true;
}
