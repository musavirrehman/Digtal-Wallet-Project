<?php
/**
 * Runtime-safe schema upgrades for virtual card module.
 */

function nixcash_column_exists(PDO $pdo, string $table, string $column): bool
{
    $dbName = (string) $pdo->query('SELECT DATABASE()')->fetchColumn();
    if ($dbName === '') {
        return false;
    }
    $st = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $st->execute([$dbName, $table, $column]);
    return (int) $st->fetchColumn() > 0;
}

function nixcash_table_exists(PDO $pdo, string $table): bool
{
    $dbName = (string) $pdo->query('SELECT DATABASE()')->fetchColumn();
    if ($dbName === '') {
        return false;
    }
    $st = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?'
    );
    $st->execute([$dbName, $table]);
    return (int) $st->fetchColumn() > 0;
}

function ensure_virtual_card_schema(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    if (!nixcash_table_exists($pdo, 'virtual_cards')) {
        $pdo->exec(
            'CREATE TABLE virtual_cards (
                card_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                cardholder_name VARCHAR(100) NOT NULL,
                card_number VARCHAR(25) NOT NULL,
                expiry_date VARCHAR(7) NOT NULL,
                cvv VARCHAR(8) NOT NULL,
                is_default TINYINT(1) NOT NULL DEFAULT 0,
                brand VARCHAR(20) NOT NULL DEFAULT "visa",
                pin_hash VARCHAR(255) DEFAULT NULL,
                balance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (card_id),
                KEY idx_virtual_cards_user_created (user_id, created_at),
                CONSTRAINT fk_virtual_cards_user FOREIGN KEY (user_id) REFERENCES users(user_id)
                    ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
    }

    if (!nixcash_column_exists($pdo, 'users', 'vc_reveal_enabled')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN vc_reveal_enabled TINYINT(1) NOT NULL DEFAULT 1');
    }

    $cardColumns = [
        'cardholder_name' => "ALTER TABLE virtual_cards ADD COLUMN cardholder_name VARCHAR(100) NOT NULL DEFAULT 'NixCash User' AFTER user_id",
        'expiry_date' => "ALTER TABLE virtual_cards ADD COLUMN expiry_date VARCHAR(7) NOT NULL DEFAULT '01/30' AFTER card_number",
        'is_default' => 'ALTER TABLE virtual_cards ADD COLUMN is_default TINYINT(1) NOT NULL DEFAULT 0 AFTER cvv',
        'brand' => "ALTER TABLE virtual_cards ADD COLUMN brand VARCHAR(20) NOT NULL DEFAULT 'visa' AFTER is_default",
        'pin_hash' => 'ALTER TABLE virtual_cards ADD COLUMN pin_hash VARCHAR(255) DEFAULT NULL AFTER brand',
        'balance' => 'ALTER TABLE virtual_cards ADD COLUMN balance DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER pin_hash',
    ];

    foreach ($cardColumns as $column => $ddl) {
        if (!nixcash_column_exists($pdo, 'virtual_cards', $column)) {
            $pdo->exec($ddl);
        }
    }

    if (nixcash_column_exists($pdo, 'virtual_cards', 'expiry') && !nixcash_column_exists($pdo, 'virtual_cards', 'expiry_date')) {
        $pdo->exec("ALTER TABLE virtual_cards ADD COLUMN expiry_date VARCHAR(7) NOT NULL DEFAULT '01/30' AFTER card_number");
    }
    if (nixcash_column_exists($pdo, 'virtual_cards', 'expiry') && nixcash_column_exists($pdo, 'virtual_cards', 'expiry_date')) {
        $pdo->exec('UPDATE virtual_cards SET expiry_date = expiry WHERE (expiry_date IS NULL OR expiry_date = "" OR expiry_date = "01/30")');
    }

    if (nixcash_column_exists($pdo, 'virtual_cards', 'cardholder_name')) {
        $pdo->exec("UPDATE virtual_cards SET cardholder_name = 'NixCash User' WHERE cardholder_name = ''");
    }

    if (!nixcash_column_exists($pdo, 'virtual_cards', 'status')) {
        $pdo->exec(
            "ALTER TABLE virtual_cards ADD COLUMN status ENUM('active','blocked') NOT NULL DEFAULT 'active'"
        );
    }

    if (!nixcash_table_exists($pdo, 'virtual_card_transactions')) {
        // optional table for card activity timeline
        $pdo->exec(
            'CREATE TABLE virtual_card_transactions (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                card_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                amount DECIMAL(12,2) NOT NULL,
                merchant VARCHAR(120) NOT NULL,
                direction ENUM("debit","credit") NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vct_card_created (card_id, created_at),
                CONSTRAINT fk_vct_card FOREIGN KEY (card_id) REFERENCES virtual_cards(card_id)
                  ON DELETE CASCADE ON UPDATE CASCADE,
                CONSTRAINT fk_vct_user FOREIGN KEY (user_id) REFERENCES users(user_id)
                  ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
    }
}

