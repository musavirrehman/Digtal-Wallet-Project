<?php
/**
 * Helpers: URLs, flash messages, validation, formatting.
 */

function url_for(string $path = ''): string
{
    $path = ltrim($path, '/');
    return NIXCASH_BASE . ($path !== '' ? '/' . $path : '');
}

function redirect(string $path): void
{
    header('Location: ' . url_for($path));
    exit;
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    if (empty($_SESSION['flash'])) {
        return null;
    }
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $f;
}

function esc(?string $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function post_string(string $key, int $maxLen = 255): string
{
    $v = isset($_POST[$key]) ? trim((string) $_POST[$key]) : '';
    if (strlen($v) > $maxLen) {
        return substr($v, 0, $maxLen);
    }
    return $v;
}

function post_email(string $key): string
{
    return filter_var(post_string($key, 255), FILTER_SANITIZE_EMAIL) ?: '';
}

function post_money(string $key): float
{
    if (!isset($_POST[$key])) {
        return 0.0;
    }
    $v = str_replace(',', '', (string) $_POST[$key]);
    return max(0, round((float) $v, 2));
}

function post_int(string $key): int
{
    return isset($_POST[$key]) ? (int) $_POST[$key] : 0;
}

function format_money(float $n): string
{
    return number_format($n, 2, '.', ',');
}

/**
 * In-app notification (split bills, etc.). Silently no-ops if table is missing.
 */
function nix_notify_user(PDO $pdo, int $userId, string $kind, string $message, ?int $billId = null): void
{
    if ($userId <= 0) {
        return;
    }
    try {
        $st = $pdo->prepare(
            'INSERT INTO user_notifications (user_id, kind, message, bill_id) VALUES (?, ?, ?, ?)'
        );
        $st->execute([$userId, $kind, $message, $billId]);
    } catch (Throwable $e) {
        // unmigrated DB or connection issue
    }
}

/**
 * Notify every user with role admin (e.g. new loan request).
 */
function nix_notify_all_admins(PDO $pdo, string $kind, string $message): void
{
    if (!nixcash_users_table_has_rbac_columns($pdo)) {
        return;
    }
    try {
        $st = $pdo->query("SELECT user_id FROM users WHERE role = 'admin'");
        while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
            $aid = (int) ($row['user_id'] ?? 0);
            nix_notify_user($pdo, $aid, $kind, $message, null);
        }
    } catch (Throwable $e) {
        // ignore
    }
}

function mask_card(string $num): string
{
    $digits = preg_replace('/\D/', '', $num);
    if (strlen($digits) < 4) {
        return '••••';
    }
    return '•••• •••• •••• ' . substr($digits, -4);
}

/** Luhn check for 13–19 digit PAN strings (digits only or spaced). */
function nixcash_luhn_valid(string $number): bool
{
    $number = preg_replace('/\D/', '', $number);
    if (strlen($number) < 2) {
        return false;
    }
    $sum = 0;
    $len = strlen($number);
    for ($i = 0; $i < $len; $i++) {
        $digit = (int) $number[$len - $i - 1];
        if ($i % 2 === 1) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }
        $sum += $digit;
    }
    return $sum % 10 === 0;
}

/** Random Visa-style 16-digit PAN (starts with 4), spaced for storage/display. */
function nixcash_generate_visa_card_number_formatted(): string
{
    for ($t = 0; $t < 300; $t++) {
        $d = '4';
        for ($i = 0; $i < 15; $i++) {
            $d .= (string) random_int(0, 9);
        }
        if (nixcash_luhn_valid($d)) {
            return substr($d, 0, 4) . ' ' . substr($d, 4, 4) . ' ' . substr($d, 8, 4) . ' ' . substr($d, 12, 4);
        }
    }
    throw new RuntimeException('Could not generate a valid card number.');
}

/** Random Mastercard-style 16-digit PAN (starts with 51-55 or 2221-2720), spaced for storage/display. */
function nixcash_generate_mastercard_card_number_formatted(): string
{
    for ($t = 0; $t < 300; $t++) {
        $prefixes = ['51', '52', '53', '54', '55'];
        $d = $prefixes[random_int(0, count($prefixes) - 1)];
        for ($i = 0; $i < 14; $i++) {
            $d .= (string) random_int(0, 9);
        }
        if (nixcash_luhn_valid($d)) {
            return substr($d, 0, 4) . ' ' . substr($d, 4, 4) . ' ' . substr($d, 8, 4) . ' ' . substr($d, 12, 4);
        }
    }
    throw new RuntimeException('Could not generate a valid card number.');
}

/** Generate card number based on brand (visa or mastercard). */
function nixcash_generate_card_number_formatted(string $brand): string
{
    $brand = strtolower($brand);
    if ($brand === 'mastercard') {
        return nixcash_generate_mastercard_card_number_formatted();
    }
    return nixcash_generate_visa_card_number_formatted();
}

/** Current page path for bottom nav active state */
function current_nav(): string
{
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $script = str_replace('\\', '/', $script);
    if (preg_match('#/index\.php$#', $script) || preg_match('#/nixcash/?$#', $script)) {
        return 'home';
    }
    if (str_contains($script, '/transactions.php')) {
        return 'transactions';
    }
    if (str_contains($script, '/goals.php')) {
        return 'goals';
    }
    if (str_contains($script, '/virtual-cards.php')) {
        return 'cards';
    }
    if (str_contains($script, '/profile.php')) {
        return 'profile';
    }
    return '';
}
