<?php
/**
 * Session + config bootstrap — include first on every page.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$config = require __DIR__ . '/../config/config.php';

if (!defined('NIXCASH_BASE')) {
    define('NIXCASH_BASE', rtrim($config['base_url'], '/'));
}

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
