<?php
/**
 * Session auth helpers + login guard.
 */

function nixcash_normalize_person_name(string $name): string
{
    $name = trim(preg_replace('/\s+/u', ' ', $name));
    return mb_strtolower($name, 'UTF-8');
}

/**
 * Primary admin panel operator (Musavir Rehman or configured emails).
 */
function nixcash_is_primary_admin_identity(?string $name, ?string $email): bool
{
    global $config;
    $cfg = is_array($config ?? null) ? ($config['admin_operator'] ?? []) : [];
    $names = isset($cfg['names']) && is_array($cfg['names']) ? $cfg['names'] : ['Musavir Rehman'];
    $emails = isset($cfg['emails']) && is_array($cfg['emails']) ? $cfg['emails'] : [];
    $norm = nixcash_normalize_person_name((string) $name);
    foreach ($names as $n) {
        if (nixcash_normalize_person_name((string) $n) === $norm) {
            return true;
        }
    }
    $em = strtolower(trim((string) $email));
    if ($em !== '' && filter_var($em, FILTER_VALIDATE_EMAIL)) {
        foreach ($emails as $allowed) {
            $a = strtolower(trim((string) $allowed));
            if ($a !== '' && $a === $em) {
                return true;
            }
        }
    }
    return false;
}

/**
 * True when `users.role` exists (apply database/patch_admin_panel.sql for RBAC).
 */
function nixcash_users_table_has_rbac_columns(PDO $pdo): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $cached = false;
    try {
        $db = (string) $pdo->query('SELECT DATABASE()')->fetchColumn();
        if ($db === '') {
            return false;
        }
        $st = $pdo->prepare(
            'SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
        );
        $st->execute([$db, 'users', 'role']);
        $cached = (int) $st->fetchColumn() > 0;
    } catch (Throwable $e) {
        $cached = false;
    }
    return $cached;
}

function current_user_id(): ?int
{
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
}

function current_user_role(): string
{
    $r = $_SESSION['role'] ?? 'user';
    return $r === 'admin' ? 'admin' : 'user';
}

function require_login(): void
{
    if (current_user_id() !== null) {
        return;
    }
    $wantsJson = false;
    if (!empty($_SERVER['HTTP_ACCEPT']) && str_contains((string) $_SERVER['HTTP_ACCEPT'], 'application/json')) {
        $wantsJson = true;
    }
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        $wantsJson = true;
    }
    if ($wantsJson) {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
        }
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Please sign in to continue.']);
        exit;
    }
    set_flash('warning', 'Please sign in to continue.');
    redirect('login.php');
}

function login_user(int $userId, string $name, string $email, string $role = 'user'): void
{
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_name'] = $name;
    $_SESSION['user_email'] = $email;
    $_SESSION['role'] = $role === 'admin' ? 'admin' : 'user';
}

/**
 * Reload role/name/email/status from DB into session; block revoked or blocked accounts.
 */
function nixcash_refresh_user_role_session(PDO $pdo): void
{
    $uid = current_user_id();
    if ($uid === null) {
        return;
    }
    $hasRbac = nixcash_users_table_has_rbac_columns($pdo);
    $sql = $hasRbac
        ? 'SELECT name, email, role, status FROM users WHERE user_id = ? LIMIT 1'
        : 'SELECT name, email FROM users WHERE user_id = ? LIMIT 1';
    $st = $pdo->prepare($sql);
    $st->execute([$uid]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        logout_user();
        set_flash('warning', 'Your session is no longer valid. Please sign in again.');
        redirect('login.php');
    }
    $_SESSION['user_name'] = (string) $row['name'];
    $_SESSION['user_email'] = (string) $row['email'];
    if (!$hasRbac) {
        $_SESSION['role'] = 'user';
        return;
    }
    $status = $row['status'] ?? 'active';
    $role = ($row['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
    $_SESSION['role'] = $role;
    if ($status === 'blocked') {
        logout_user();
        set_flash('danger', 'Your account has been restricted. Contact support if this is a mistake.');
        redirect('login.php');
    }
}

/**
 * True if the signed-in user may open the admin panel (same rules as require, without redirect).
 */
function nixcash_can_open_admin_panel(PDO $pdo): bool
{
    if (current_user_id() === null) {
        return false;
    }
    nixcash_refresh_user_role_session($pdo);
    if (!nixcash_users_table_has_rbac_columns($pdo)) {
        return false;
    }
    if (current_user_role() !== 'admin') {
        return false;
    }
    return nixcash_is_primary_admin_identity($_SESSION['user_name'] ?? null, $_SESSION['user_email'] ?? null);
}

/**
 * Admin UI: must be logged in, role admin, and primary operator identity.
 */
function nixcash_require_admin_panel(PDO $pdo): void
{
    require_login();
    nixcash_refresh_user_role_session($pdo);
    if (!nixcash_users_table_has_rbac_columns($pdo)) {
        set_flash(
            'warning',
            'The admin database upgrade is not applied yet. In phpMyAdmin or MySQL, run the script database/patch_admin_panel.sql on the nixcash database, then sign in again.'
        );
        redirect('index.php');
    }
    if (current_user_role() !== 'admin') {
        set_flash('warning', 'You do not have access to the admin panel.');
        redirect('index.php');
    }
    if (!nixcash_is_primary_admin_identity($_SESSION['user_name'] ?? null, $_SESSION['user_email'] ?? null)) {
        set_flash('warning', 'Admin panel access is restricted.');
        redirect('index.php');
    }
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function user_balance(PDO $pdo, int $userId): float
{
    $st = $pdo->prepare('SELECT balance FROM wallets WHERE user_id = ? LIMIT 1');
    $st->execute([$userId]);
    $row = $st->fetch();
    return $row ? (float) $row['balance'] : 0.0;
}
