<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/auth.php';

logout_user();
set_flash('info', 'You have been signed out.');
header('Location: ' . url_for('login.php'));
exit;
