from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.dml.color import RGBColor

# NixCash Theme Colors (Dark Fintech)
DARK_BG = RGBColor(11, 14, 17)          # #0b0e11
ELEVATED_BG = RGBColor(24, 26, 32)      # #181a20
CARD_BG = RGBColor(30, 35, 41)          # #1e2329
ACCENT = RGBColor(240, 185, 11)         # #f0b90b (Gold/Yellow)
TEXT_WHITE = RGBColor(234, 236, 239)    # #eaecef
TEXT_MUTED = RGBColor(132, 142, 156)    # #848e9c
POSITIVE = RGBColor(14, 203, 129)       # #0ecb81
NEGATIVE = RGBColor(246, 70, 93)        # #f6465d

def set_slide_bg(slide, color):
    """Set solid background color for a slide"""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_title_slide(prs, title, subtitle):
    """Add an enhanced title slide with visual elements"""
    slide_layout = prs.slide_layouts[6]  # Blank layout
    slide = prs.slides.add_slide(slide_layout)
    set_slide_bg(slide, DARK_BG)
    
    # Top accent bar
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(0.2))
    shape.fill.solid()
    shape.fill.fore_color.rgb = ACCENT
    shape.line.fill.background()
    
    # Bottom accent bar
    shape2 = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(5.8), Inches(10), Inches(0.2))
    shape2.fill.solid()
    shape2.fill.fore_color.rgb = ACCENT
    shape2.line.fill.background()
    
    # Decorative circles
    circle1 = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(8.5), Inches(0.5), Inches(0.8), Inches(0.8))
    circle1.fill.solid()
    circle1.fill.fore_color.rgb = ACCENT
    circle1.fill.fore_color.brightness = 0.3
    circle1.line.fill.background()
    
    circle2 = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(0.8), Inches(4.5), Inches(0.5), Inches(0.5))
    circle2.fill.solid()
    circle2.fill.fore_color.rgb = ACCENT
    circle2.fill.fore_color.brightness = 0.5
    circle2.line.fill.background()
    
    # Main title card background
    title_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.5), Inches(1.8), Inches(7), Inches(2.2))
    title_card.fill.solid()
    title_card.fill.fore_color.rgb = ELEVATED_BG
    title_card.line.color.rgb = ACCENT
    title_card.line.width = Pt(2)
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(1.5), Inches(2.0), Inches(7), Inches(1.2))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(60)
    p.font.bold = True
    p.font.color.rgb = ACCENT
    p.alignment = PP_ALIGN.CENTER
    
    # Subtitle
    sub_box = slide.shapes.add_textbox(Inches(1.5), Inches(3.1), Inches(7), Inches(0.8))
    tf = sub_box.text_frame
    p = tf.paragraphs[0]
    p.text = subtitle
    p.font.size = Pt(20)
    p.font.color.rgb = TEXT_WHITE
    p.alignment = PP_ALIGN.CENTER
    
    # Tagline at bottom
    tag_box = slide.shapes.add_textbox(Inches(0.5), Inches(5.0), Inches(9), Inches(0.5))
    tf = tag_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Secure • Fast • Reliable Digital Payments"
    p.font.size = Pt(16)
    p.font.color.rgb = TEXT_MUTED
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_content_slide(prs, title, content_items, is_bullets=True):
    """Add a content slide with bullets or numbered items"""
    slide_layout = prs.slide_layouts[6]  # Blank layout
    slide = prs.slides.add_slide(slide_layout)
    set_slide_bg(slide, DARK_BG)
    
    # Accent bar at top
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(0.1))
    shape.fill.solid()
    shape.fill.fore_color.rgb = ACCENT
    shape.line.fill.background()
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.4), Inches(9), Inches(0.8))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = ACCENT
    
    # Content
    content_box = slide.shapes.add_textbox(Inches(0.7), Inches(1.4), Inches(8.6), Inches(5.5))
    tf = content_box.text_frame
    tf.word_wrap = True
    
    for i, item in enumerate(content_items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        
        if is_bullets:
            p.text = "• " + item
            p.font.size = Pt(20)
        else:
            p.text = f"{i+1}. {item}"
            p.font.size = Pt(20)
        
        p.font.color.rgb = TEXT_WHITE
        p.space_after = Pt(14)
        p.level = 0
    
    return slide

def add_db_schema_slide(prs):
    """Add database schema slide with ER diagram style boxes and connections"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_bg(slide, DARK_BG)
    
    # Accent bar
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(0.1))
    shape.fill.solid()
    shape.fill.fore_color.rgb = ACCENT
    shape.line.fill.background()
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(9), Inches(0.6))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Database Schema & Relationships"
    p.font.size = Pt(28)
    p.font.bold = True
    p.font.color.rgb = ACCENT
    
    # Helper function to create table box
    def create_table_box(slide, x, y, width, height, table_name, fields, pk_field, is_junction=False):
        # Box background
        box = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(width), Inches(height))
        box.fill.solid()
        box.fill.fore_color.rgb = ELEVATED_BG if not is_junction else CARD_BG
        box.line.color.rgb = ACCENT if not is_junction else TEXT_MUTED
        box.line.width = Pt(2) if not is_junction else Pt(1)
        
        # Header (table name)
        header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(width), Inches(0.35))
        header.fill.solid()
        header.fill.fore_color.rgb = ACCENT if not is_junction else RGBColor(100, 100, 120)
        header.line.fill.background()
        
        tb = slide.shapes.add_textbox(Inches(x), Inches(y + 0.05), Inches(width), Inches(0.25))
        tf = tb.text_frame
        p = tf.paragraphs[0]
        p.text = table_name
        p.font.size = Pt(11)
        p.font.bold = True
        p.font.color.rgb = DARK_BG if not is_junction else TEXT_WHITE
        p.alignment = PP_ALIGN.CENTER
        
        # Fields
        field_y = y + 0.4
        for field in fields:
            tb = slide.shapes.add_textbox(Inches(x + 0.08), Inches(field_y), Inches(width - 0.16), Inches(0.18))
            tf = tb.text_frame
            p = tf.paragraphs[0]
            # Bold the PK field
            if pk_field and pk_field in field:
                p.text = "🔑 " + field
                p.font.bold = True
            else:
                p.text = field
            p.font.size = Pt(8)
            p.font.color.rgb = TEXT_WHITE if pk_field and pk_field in field else TEXT_MUTED
            field_y += 0.19
        
        return (x + width/2, y)  # Return top center for connection
    
    # Create table boxes with positions and sizes
    # Format: (x, y, width, height, table_name, fields, pk_field, is_junction)
    tables_data = [
        # Left column
        (0.3, 0.9, 1.6, 1.3, "users", [
            "user_id INT PK",
            "name VARCHAR",
            "email VARCHAR",
            "phone VARCHAR",
            "password VARCHAR",
            "role ENUM",
            "status ENUM"
        ], "user_id", False),
        
        (0.3, 2.4, 1.6, 0.9, "wallets", [
            "wallet_id INT PK",
            "user_id INT FK",
            "balance DECIMAL"
        ], "wallet_id", False),
        
        (0.3, 3.5, 1.6, 1.0, "goals", [
            "goal_id INT PK",
            "user_id INT FK",
            "title VARCHAR",
            "target_amount DEC",
            "saved_amount DEC"
        ], "goal_id", False),
        
        (0.3, 4.7, 1.6, 1.1, "transactions", [
            "transaction_id BIGINT PK",
            "sender_id INT FK",
            "receiver_id INT FK",
            "amount DECIMAL",
            "type VARCHAR"
        ], "transaction_id", False),
        
        # Right column
        (8.1, 0.9, 1.6, 1.2, "virtual_cards", [
            "card_id INT PK",
            "user_id INT FK",
            "card_number VARCHAR",
            "expiry_date VARCHAR",
            "cvv VARCHAR",
            "status ENUM"
        ], "card_id", False),
        
        (8.1, 2.3, 1.6, 1.0, "loan_applications", [
            "loan_id BIGINT PK",
            "user_id INT FK",
            "amount DECIMAL",
            "status ENUM",
            "reviewed_by INT"
        ], "loan_id", False),
        
        (8.1, 3.5, 1.6, 1.0, "split_bills", [
            "bill_id INT PK",
            "created_by INT FK",
            "title VARCHAR",
            "total_amount DEC",
            "status ENUM"
        ], "bill_id", False),
        
        # Junction table at bottom center
        (4.2, 4.8, 1.6, 0.85, "split_bill_members", [
            "id INT PK",
            "bill_id INT FK",
            "user_id INT FK",
            "amount DECIMAL"
        ], "id", True),
    ]
    
    # Store connection points
    connection_points = {}
    
    for x, y, w, h, name, fields, pk, is_junc in tables_data:
        center_x, top_y = create_table_box(slide, x, y, w, h, name, fields, pk, is_junc)
        connection_points[name] = {
            'left': (x, y + h/2),
            'right': (x + w, y + h/2),
            'top': (center_x, y),
            'bottom': (center_x, y + h),
            'center': (center_x, y + h/2)
        }
    
    # Draw relationship lines with crow's feet notation
    relationships = [
        # (from_table, from_side, to_table, to_side, relationship_type)
        ("users", "right", "virtual_cards", "left", "1:N"),
        ("users", "bottom", "wallets", "top", "1:1"),
        ("users", "bottom", "goals", "top", "1:N"),
        ("users", "bottom", "loan_applications", "top", "1:N"),
        ("users", "right", "transactions", "left", "1:N"),
        ("users", "right", "split_bills", "left", "1:N"),
        ("split_bills", "bottom", "split_bill_members", "top", "1:N"),
    ]
    
    for from_table, from_side, to_table, to_side, rel_type in relationships:
        if from_table in connection_points and to_table in connection_points:
            x1, y1 = connection_points[from_table][from_side]
            x2, y2 = connection_points[to_table][to_side]
            
            # Convert to inches for the connector
            x1_in, y1_in = x1, y1
            x2_in, y2_in = x2, y2
            
            # Draw line
            line = slide.shapes.add_connector(
                MSO_CONNECTOR.STRAIGHT, 
                Inches(x1_in), Inches(y1_in),
                Inches(x2_in), Inches(y2_in)
            )
            line.line.color.rgb = ACCENT
            line.line.width = Pt(1.5)
            
            # Add relationship label at midpoint
            mid_x = (x1_in + x2_in) / 2
            mid_y = (y1_in + y2_in) / 2
            
            # Adjust label position based on line orientation
            if abs(x1_in - x2_in) > abs(y1_in - y2_in):  # Horizontal-ish
                label_x, label_y = mid_x, mid_y - 0.15
            else:  # Vertical-ish
                label_x, label_y = mid_x + 0.05, mid_y
            
            rel_tb = slide.shapes.add_textbox(Inches(label_x - 0.25), Inches(label_y - 0.1), Inches(0.5), Inches(0.2))
            tf = rel_tb.text_frame
            p = tf.paragraphs[0]
            p.text = rel_type
            p.font.size = Pt(9)
            p.font.bold = True
            p.font.color.rgb = ACCENT
            p.alignment = PP_ALIGN.CENTER
    
    # Legend
    legend_box = slide.shapes.add_textbox(Inches(3.5), Inches(0.25), Inches(3), Inches(0.4))
    tf = legend_box.text_frame
    p = tf.paragraphs[0]
    p.text = "🔑 Primary Key  |  FK = Foreign Key"
    p.font.size = Pt(10)
    p.font.color.rgb = TEXT_MUTED
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_features_slide(prs):
    """Add features slide with enhanced visual cards and icons"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_bg(slide, DARK_BG)
    
    # Top accent bar
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(0.12))
    shape.fill.solid()
    shape.fill.fore_color.rgb = ACCENT
    shape.line.fill.background()
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Key Features"
    p.font.size = Pt(34)
    p.font.bold = True
    p.font.color.rgb = ACCENT
    
    # Feature cards with icons (using shapes as icons)
    features = [
        ("Wallet", "Wallet Management", "Add money, Send money, Withdraw, Balance tracking", POSITIVE),
        ("Card", "Virtual Cards", "Generate cards, Load wallet, Merchant payments", ACCENT),
        ("Bill", "Bill Payments", "Electricity, Gas, Internet, Mobile recharge", RGBColor(100, 180, 255)),
        ("Goal", "Savings Goals", "Create goals, Track progress, Contribute funds", RGBColor(255, 180, 100)),
        ("Split", "Split Bills", "Create splits, Equal/Custom divide, Pay shares", RGBColor(200, 150, 255)),
        ("Loan", "Loan System", "Apply for loans, Admin review, Status tracking", RGBColor(255, 120, 120)),
    ]
    
    positions = [
        (0.4, 1.1), (5.1, 1.1),
        (0.4, 2.5), (5.1, 2.5),
        (0.4, 3.9), (5.1, 3.9),
    ]
    
    for i, (icon_type, feat_title, feat_desc, icon_color) in enumerate(features):
        x, y = positions[i]
        
        # Card background with subtle border
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(4.5), Inches(1.3))
        card.fill.solid()
        card.fill.fore_color.rgb = ELEVATED_BG
        card.line.color.rgb = CARD_BG
        card.line.width = Pt(1)
        
        # Icon circle background
        icon_bg = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x + 0.15), Inches(y + 0.25), Inches(0.6), Inches(0.6))
        icon_bg.fill.solid()
        icon_bg.fill.fore_color.rgb = icon_color
        icon_bg.fill.fore_color.brightness = -0.3
        icon_bg.line.fill.background()
        
        # Icon indicator (small shape inside)
        if icon_type == "Wallet":
            icon_shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x + 0.28), Inches(y + 0.42), Inches(0.34), Inches(0.26))
        elif icon_type == "Card":
            icon_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x + 0.28), Inches(y + 0.40), Inches(0.34), Inches(0.30))
        elif icon_type == "Bill":
            icon_shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x + 0.30), Inches(y + 0.38), Inches(0.30), Inches(0.34))
        elif icon_type == "Goal":
            icon_shape = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x + 0.30), Inches(y + 0.38), Inches(0.30), Inches(0.34))
        elif icon_type == "Split":
            icon_shape = slide.shapes.add_shape(MSO_SHAPE.PIE, Inches(x + 0.28), Inches(y + 0.38), Inches(0.34), Inches(0.34))
        else:  # Loan
            icon_shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x + 0.32), Inches(y + 0.35), Inches(0.26), Inches(0.40))
        
        icon_shape.fill.solid()
        icon_shape.fill.fore_color.rgb = icon_color
        icon_shape.line.fill.background()
        
        # Feature title
        tb = slide.shapes.add_textbox(Inches(x + 0.9), Inches(y + 0.15), Inches(3.4), Inches(0.4))
        tf = tb.text_frame
        p = tf.paragraphs[0]
        p.text = feat_title
        p.font.size = Pt(16)
        p.font.bold = True
        p.font.color.rgb = TEXT_WHITE
        
        # Feature description
        tb2 = slide.shapes.add_textbox(Inches(x + 0.9), Inches(y + 0.55), Inches(3.4), Inches(0.7))
        tf = tb2.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = feat_desc
        p.font.size = Pt(11)
        p.font.color.rgb = TEXT_MUTED
    
    return slide

def add_future_slide(prs):
    """Add future improvements slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_bg(slide, DARK_BG)
    
    # Accent bar
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(0.1))
    shape.fill.solid()
    shape.fill.fore_color.rgb = ACCENT
    shape.line.fill.background()
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.4), Inches(9), Inches(0.8))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Future Improvements"
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = ACCENT
    
    # Future items with icons representation
    improvements = [
        ("KYC Verification", "Identity verification for enhanced security and compliance"),
        ("UPI Integration", "Real payment gateway integration for actual transactions"),
        ("Investment Module", "Mutual funds, Stocks, and SIP investment options"),
        ("AI Insights", "Spending analytics and personalized financial recommendations"),
        ("Multi-Currency", "Support for international currencies and forex"),
        ("Mobile App", "Native Android/iOS apps with biometric authentication"),
    ]
    
    y_pos = 1.4
    for title, desc in improvements:
        # Bullet point (accent color circle)
        bullet = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(0.6), Inches(y_pos + 0.08), Inches(0.15), Inches(0.15))
        bullet.fill.solid()
        bullet.fill.fore_color.rgb = ACCENT
        bullet.line.fill.background()
        
        # Title
        tb = slide.shapes.add_textbox(Inches(0.9), Inches(y_pos), Inches(8.5), Inches(0.35))
        tf = tb.text_frame
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(18)
        p.font.bold = True
        p.font.color.rgb = TEXT_WHITE
        
        # Description
        tb2 = slide.shapes.add_textbox(Inches(0.9), Inches(y_pos + 0.35), Inches(8.5), Inches(0.4))
        tf = tb2.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = desc
        p.font.size = Pt(14)
        p.font.color.rgb = TEXT_MUTED
        
        y_pos += 0.9
    
    return slide

def add_tech_stack_slide(prs):
    """Add tech stack slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_bg(slide, DARK_BG)
    
    # Accent bar
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(0.1))
    shape.fill.solid()
    shape.fill.fore_color.rgb = ACCENT
    shape.line.fill.background()
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.4), Inches(9), Inches(0.8))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Tech Stack & Architecture"
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = ACCENT
    
    # Tech categories
    tech_categories = [
        ("Frontend", ["HTML5, CSS3, JavaScript", "Bootstrap 5 Framework", "Responsive Design", "Dark/Light Theme Support"]),
        ("Backend", ["PHP 8.0+ with PDO", "Session-based Authentication", "RESTful API Structure", "Transaction Management"]),
        ("Database", ["MySQL 5.7+ / MariaDB 10+", "InnoDB Engine", "Foreign Key Constraints", "ACID Compliance"]),
        ("Security", ["Password Hashing (bcrypt)", "Prepared Statements (SQL Injection Prevention)", "Session Management", "Admin Panel Access Control"]),
    ]
    
    positions = [
        (0.5, 1.4), (5.2, 1.4),
        (0.5, 3.6), (5.2, 3.6),
    ]
    
    for i, (cat_title, items) in enumerate(tech_categories):
        x, y = positions[i]
        
        # Category card
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(4.3), Inches(2))
        card.fill.solid()
        card.fill.fore_color.rgb = ELEVATED_BG
        card.line.color.rgb = CARD_BG
        
        # Category title
        tb = slide.shapes.add_textbox(Inches(x + 0.15), Inches(y + 0.1), Inches(4), Inches(0.4))
        tf = tb.text_frame
        p = tf.paragraphs[0]
        p.text = cat_title
        p.font.size = Pt(18)
        p.font.bold = True
        p.font.color.rgb = ACCENT
        
        # Items
        tb2 = slide.shapes.add_textbox(Inches(x + 0.15), Inches(y + 0.55), Inches(4), Inches(1.4))
        tf = tb2.text_frame
        tf.word_wrap = True
        
        for j, item in enumerate(items):
            if j == 0:
                p = tf.paragraphs[0]
            else:
                p = tf.add_paragraph()
            p.text = "• " + item
            p.font.size = Pt(13)
            p.font.color.rgb = TEXT_WHITE
            p.space_after = Pt(6)
    
    return slide

# Create presentation
prs = Presentation()
prs.slide_width = Inches(10)
prs.slide_height = Inches(6)

# Slide 1: Title
add_title_slide(prs, "NixCash", "Digital Wallet Web Application\nPHP + MySQL Fintech Solution")

# Slide 2: Introduction
intro_content = [
    "NixCash is a comprehensive digital wallet web application inspired by modern mobile money apps",
    "Built with PHP 8.0+ and MySQL using a dark fintech UI with Bootstrap 5",
    "Supports user registration, secure authentication, and role-based access (User/Admin)",
    "Implements PDO transactions for safe money transfers between wallets",
    "Responsive design with mobile-first approach and bottom navigation",
    "Dark/Light theme toggle for enhanced user experience"
]
add_content_slide(prs, "Introduction", intro_content)

# Slide 3: Tech Stack
add_tech_stack_slide(prs)

# Slide 4: Database Schema
add_db_schema_slide(prs)

# Slide 5: Key Features
add_features_slide(prs)

# Slide 6: Future Improvements
add_future_slide(prs)

# Save presentation
output_path = r"c:\xampp\htdocs\nixcash\NixCash_Presentation.pptx"
prs.save(output_path)
print(f"Presentation created successfully at: {output_path}")
