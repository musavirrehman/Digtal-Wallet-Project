<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/virtual-card-schema.php';
require_once dirname(__DIR__) . '/includes/loan-schema.php';

if (!defined('NIXCASH_ADMIN_ROOT')) {
    define('NIXCASH_ADMIN_ROOT', __DIR__);
}

ensure_virtual_card_schema($pdo);
ensure_loan_schema($pdo);

nixcash_require_admin_panel($pdo);
