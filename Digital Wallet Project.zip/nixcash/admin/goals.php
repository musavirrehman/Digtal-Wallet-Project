<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$rows = $pdo->query(
    'SELECT g.*, u.name AS user_name, u.email AS user_email
     FROM goals g
     INNER JOIN users u ON u.user_id = g.user_id
     ORDER BY g.created_at DESC LIMIT 300'
)->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Goals';
$adminNav = 'goals';
require __DIR__ . '/partials/layout-start.php';
?>
<div class="nix-admin-stat-card bg-body">
    <div class="table-responsive nix-admin-table-wrap">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Title</th>
                <th class="text-end">Saved</th>
                <th class="text-end">Target</th>
                <th>Progress</th>
                <th>Deadline</th>
                <th class="text-end">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $g): ?>
                <?php
                $gid = (int) $g['goal_id'];
                $target = (float) $g['target_amount'];
                $saved = (float) $g['saved_amount'];
                $pct = $target > 0 ? min(100, round(100 * $saved / $target)) : 0;
                ?>
                <tr>
                    <td><?= $gid ?></td>
                    <td>
                        <div class="fw-medium"><?= esc($g['user_name']) ?></div>
                        <div class="text-muted small"><?= esc($g['user_email']) ?></div>
                    </td>
                    <td><?= esc($g['title']) ?></td>
                    <td class="text-end">Rs. <?= esc(format_money($saved)) ?></td>
                    <td class="text-end">Rs. <?= esc(format_money($target)) ?></td>
                    <td style="min-width:140px">
                        <div class="progress" style="height:8px">
                            <div class="progress-bar" role="progressbar" style="width: <?= (int) $pct ?>%"></div>
                        </div>
                        <span class="small text-muted"><?= (int) $pct ?>%</span>
                    </td>
                    <td class="text-muted small"><?= $g['deadline'] ? esc((string) $g['deadline']) : '—' ?></td>
                    <td class="text-end">
                        <form method="post" action="<?= esc(url_for('admin/actions/goal-delete.php')) ?>" class="d-inline"
                              onsubmit="return confirm('Delete this goal?');">
                            <input type="hidden" name="goal_id" value="<?= $gid ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (count($rows) === 0): ?>
                <tr><td colspan="8" class="text-muted p-4">No goals.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/partials/layout-end.php'; ?>
