<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$mysqlVer = (string) $pdo->query('SELECT VERSION()')->fetchColumn();
$phpVer = PHP_VERSION;
$dbName = $pdo->query('SELECT DATABASE()')->fetchColumn();

$pageTitle = 'Settings';
$adminNav = 'settings';
require __DIR__ . '/partials/layout-start.php';
?>
<div class="row g-4">
    <div class="col-lg-6">
        <div class="nix-admin-stat-card p-4 bg-body">
            <h2 class="h5 mb-3">Change admin password</h2>
            <form method="post" action="<?= esc(url_for('admin/actions/password-change.php')) ?>" class="vstack gap-3" autocomplete="off">
                <div>
                    <label class="form-label">Current password</label>
                    <input type="password" name="current_password" class="form-control" required minlength="1" autocomplete="current-password">
                </div>
                <div>
                    <label class="form-label">New password</label>
                    <input type="password" name="new_password" class="form-control" required minlength="6" autocomplete="new-password">
                </div>
                <div>
                    <label class="form-label">Confirm new password</label>
                    <input type="password" name="new_password_confirm" class="form-control" required minlength="6" autocomplete="new-password">
                </div>
                <button type="submit" class="btn btn-primary">Update password</button>
            </form>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="nix-admin-stat-card p-4 bg-body">
            <h2 class="h5 mb-3">System stats</h2>
            <ul class="list-unstyled mb-0 small vstack gap-2">
                <li><span class="text-muted">PHP</span> <?= esc($phpVer) ?></li>
                <li><span class="text-muted">MySQL</span> <?= esc($mysqlVer) ?></li>
                <li><span class="text-muted">Database</span> <?= esc((string) $dbName) ?></li>
                <li><span class="text-muted">Users</span> <?= (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() ?></li>
                <li><span class="text-muted">Transactions</span> <?= (int) $pdo->query('SELECT COUNT(*) FROM transactions')->fetchColumn() ?></li>
            </ul>
        </div>
    </div>
</div>
<?php require __DIR__ . '/partials/layout-end.php'; ?>
