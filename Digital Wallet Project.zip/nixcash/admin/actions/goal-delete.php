<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/goals.php');
}

$gid = post_int('goal_id');
if ($gid <= 0) {
    set_flash('error', 'Invalid goal.');
    redirect('admin/goals.php');
}

$pdo->prepare('DELETE FROM goals WHERE goal_id = ? LIMIT 1')->execute([$gid]);
set_flash('success', 'Goal deleted.');
redirect('admin/goals.php');
