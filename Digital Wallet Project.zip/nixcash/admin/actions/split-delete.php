<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/split_bills.php');
}

$bid = post_int('bill_id');
if ($bid <= 0) {
    set_flash('error', 'Invalid bill.');
    redirect('admin/split_bills.php');
}

$pdo->prepare('DELETE FROM split_bills WHERE bill_id = ? LIMIT 1')->execute([$bid]);
set_flash('success', 'Split bill removed.');
redirect('admin/split_bills.php');
