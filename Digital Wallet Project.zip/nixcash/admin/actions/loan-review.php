<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/loans.php');
}

$loanId = post_int('loan_id');
$action = post_string('action', 20);
$adminId = current_user_id();

if ($loanId <= 0 || $adminId === null) {
    set_flash('error', 'Invalid request.');
    redirect('admin/loans.php');
}

$st = $pdo->prepare(
    'SELECT loan_id, user_id, amount, status FROM loan_applications WHERE loan_id = ? LIMIT 1'
);
$st->execute([$loanId]);
$row = $st->fetch(PDO::FETCH_ASSOC);
if (!$row || ($row['status'] ?? '') !== 'pending') {
    set_flash('error', 'This application is not pending.');
    redirect('admin/loans.php');
}

$userId = (int) $row['user_id'];
$amount = (float) $row['amount'];

if ($action === 'reject') {
    $u = $pdo->prepare(
        'UPDATE loan_applications SET status = ?, reviewed_by = ?, reviewed_at = NOW() WHERE loan_id = ? LIMIT 1'
    );
    $u->execute(['rejected', $adminId, $loanId]);
    nix_notify_user($pdo, $userId, 'loan', 'Your loan request for Rs. ' . format_money($amount) . ' was declined.', null);
    set_flash('success', 'Loan application rejected.');
    redirect('admin/loans.php');
}

if ($action !== 'approve') {
    set_flash('error', 'Unknown action.');
    redirect('admin/loans.php');
}

try {
    $pdo->beginTransaction();
    $dueDate = date('Y-m-d H:i:s', strtotime('+1 month'));
    $chk = $pdo->prepare(
        'UPDATE loan_applications SET status = ?, reviewed_by = ?, reviewed_at = NOW(), approved_at = NOW(), due_date = ?, remaining_amount = ?
         WHERE loan_id = ? AND status = ? LIMIT 1'
    );
    $chk->execute(['approved', $adminId, $dueDate, $amount, $loanId, 'pending']);
    if ($chk->rowCount() !== 1) {
        throw new RuntimeException('Concurrent update');
    }
    $pdo->prepare('UPDATE wallets SET balance = balance + ? WHERE user_id = ?')->execute([$amount, $userId]);
    $pdo->prepare(
        'INSERT INTO transactions (sender_id, receiver_id, amount, type, category, description)
         VALUES (NULL, ?, ?, ?, ?, ?)'
    )->execute([
        $userId,
        $amount,
        'loan',
        'loan',
        'Approved loan #' . $loanId,
    ]);
    $pdo->commit();
    nix_notify_user(
        $pdo,
        $userId,
        'loan',
        'Your loan of Rs. ' . format_money($amount) . ' was approved and added to your wallet.',
        null
    );
    set_flash('success', 'Loan approved and credited to the user wallet.');
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('error', 'Could not approve the loan.');
}

redirect('admin/loans.php');
