<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/cards.php');
}

$cardId = post_int('card_id');
if ($cardId <= 0) {
    set_flash('error', 'Invalid card.');
    redirect('admin/cards.php');
}

$pdo->prepare('DELETE FROM virtual_cards WHERE card_id = ? LIMIT 1')->execute([$cardId]);
set_flash('success', 'Card deleted.');
redirect('admin/cards.php');
