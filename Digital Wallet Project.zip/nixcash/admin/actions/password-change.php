<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/settings.php');
}

$current = isset($_POST['current_password']) ? (string) $_POST['current_password'] : '';
$new = isset($_POST['new_password']) ? (string) $_POST['new_password'] : '';
$new2 = isset($_POST['new_password_confirm']) ? (string) $_POST['new_password_confirm'] : '';
$uid = current_user_id();

if ($uid === null) {
    redirect('admin/settings.php');
}

if (strlen($new) < 6) {
    set_flash('error', 'New password must be at least 6 characters.');
    redirect('admin/settings.php');
}
if ($new !== $new2) {
    set_flash('error', 'New passwords do not match.');
    redirect('admin/settings.php');
}

$st = $pdo->prepare('SELECT password FROM users WHERE user_id = ? LIMIT 1');
$st->execute([$uid]);
$row = $st->fetch(PDO::FETCH_ASSOC);
if (!$row || !password_verify($current, (string) $row['password'])) {
    set_flash('error', 'Current password is incorrect.');
    redirect('admin/settings.php');
}

$hash = password_hash($new, PASSWORD_DEFAULT);
$pdo->prepare('UPDATE users SET password = ? WHERE user_id = ? LIMIT 1')->execute([$hash, $uid]);
set_flash('success', 'Password updated.');
redirect('admin/settings.php');
