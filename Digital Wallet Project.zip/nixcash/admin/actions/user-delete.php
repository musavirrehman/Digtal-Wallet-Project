<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/users.php');
}

$targetId = post_int('user_id');
$me = current_user_id();

if ($targetId <= 0 || $me === null) {
    set_flash('error', 'Invalid request.');
    redirect('admin/users.php');
}
if ($targetId === $me) {
    set_flash('error', 'You cannot delete your own account.');
    redirect('admin/users.php');
}

$st = $pdo->prepare('DELETE FROM users WHERE user_id = ? LIMIT 1');
$st->execute([$targetId]);
set_flash('success', 'User deleted.');
redirect('admin/users.php');
