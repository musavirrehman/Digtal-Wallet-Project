<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/users.php');
}

$targetId = post_int('user_id');
$action = post_string('action', 20);
$me = current_user_id();

if ($targetId <= 0 || $me === null) {
    set_flash('error', 'Invalid request.');
    redirect('admin/users.php');
}
if ($targetId === $me) {
    set_flash('error', 'You cannot change your own account this way.');
    redirect('admin/users.php');
}

if ($action === 'block') {
    $st = $pdo->prepare('UPDATE users SET status = ? WHERE user_id = ? LIMIT 1');
    $st->execute(['blocked', $targetId]);
    set_flash('success', 'User has been blocked.');
} elseif ($action === 'unblock') {
    $st = $pdo->prepare('UPDATE users SET status = ? WHERE user_id = ? LIMIT 1');
    $st->execute(['active', $targetId]);
    set_flash('success', 'User has been unblocked.');
} else {
    set_flash('error', 'Unknown action.');
}

redirect('admin/users.php');
