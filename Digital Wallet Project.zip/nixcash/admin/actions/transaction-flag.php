<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/transactions.php');
}

$tid = post_int('transaction_id');
$flag = post_string('flag', 1);

if ($tid <= 0) {
    set_flash('error', 'Invalid transaction.');
    redirect('admin/transactions.php');
}

$v = $flag === '1' ? 1 : 0;
$st = $pdo->prepare('UPDATE transactions SET admin_flagged = ? WHERE transaction_id = ? LIMIT 1');
$st->execute([$v, $tid]);
set_flash('success', $v ? 'Transaction flagged.' : 'Flag removed.');
redirect('admin/transactions.php');
