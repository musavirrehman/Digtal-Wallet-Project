<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/transactions.php');
}

$tid = post_int('transaction_id');
if ($tid <= 0) {
    set_flash('error', 'Invalid transaction.');
    redirect('admin/transactions.php');
}

$st = $pdo->prepare('DELETE FROM transactions WHERE transaction_id = ? LIMIT 1');
$st->execute([$tid]);
set_flash('warning', 'Transaction removed. Wallet balances were not adjusted.');
redirect('admin/transactions.php');
