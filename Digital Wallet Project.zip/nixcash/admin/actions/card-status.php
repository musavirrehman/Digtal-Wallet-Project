<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/cards.php');
}

$cardId = post_int('card_id');
$action = post_string('action', 20);

if ($cardId <= 0) {
    set_flash('error', 'Invalid card.');
    redirect('admin/cards.php');
}

if ($action === 'block') {
    $pdo->prepare('UPDATE virtual_cards SET status = ? WHERE card_id = ? LIMIT 1')->execute(['blocked', $cardId]);
    set_flash('success', 'Card blocked.');
} elseif ($action === 'unblock') {
    $pdo->prepare('UPDATE virtual_cards SET status = ? WHERE card_id = ? LIMIT 1')->execute(['active', $cardId]);
    set_flash('success', 'Card unblocked.');
} else {
    set_flash('error', 'Unknown action.');
}

redirect('admin/cards.php');
