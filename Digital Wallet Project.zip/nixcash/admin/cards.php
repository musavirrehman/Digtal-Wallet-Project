<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$rows = $pdo->query(
    'SELECT c.card_id, c.user_id, c.cardholder_name, c.brand, c.card_number, c.is_default,
            COALESCE(c.status, \'active\') AS card_status, c.created_at,
            u.name AS owner_name, u.email AS owner_email
     FROM virtual_cards c
     INNER JOIN users u ON u.user_id = c.user_id
     ORDER BY c.created_at DESC LIMIT 300'
)->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Virtual cards';
$adminNav = 'cards';
require __DIR__ . '/partials/layout-start.php';
?>
<div class="nix-admin-stat-card bg-body">
    <div class="table-responsive nix-admin-table-wrap">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Owner</th>
                <th>Holder</th>
                <th>Masked</th>
                <th>Brand</th>
                <th>Status</th>
                <th>Created</th>
                <th class="text-end">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $c): ?>
                <?php
                $cid = (int) $c['card_id'];
                $masked = mask_card((string) $c['card_number']);
                $st = (string) ($c['card_status'] ?? 'active');
                ?>
                <tr>
                    <td><?= $cid ?></td>
                    <td>
                        <div class="fw-medium"><?= esc($c['owner_name']) ?></div>
                        <div class="text-muted small"><?= esc($c['owner_email']) ?></div>
                    </td>
                    <td><?= esc($c['cardholder_name']) ?></td>
                    <td class="font-monospace small"><?= esc($masked) ?></td>
                    <td><?= esc(strtoupper((string) $c['brand'])) ?></td>
                    <td>
                        <?php if ($st === 'blocked'): ?>
                            <span class="badge text-bg-danger">Blocked</span>
                        <?php else: ?>
                            <span class="badge text-bg-success">Active</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted small"><?= esc(date('Y-m-d', strtotime((string) $c['created_at']))) ?></td>
                    <td class="text-end text-nowrap">
                        <?php if ($st === 'blocked'): ?>
                            <form method="post" action="<?= esc(url_for('admin/actions/card-status.php')) ?>" class="d-inline">
                                <input type="hidden" name="card_id" value="<?= $cid ?>">
                                <input type="hidden" name="action" value="unblock">
                                <button type="submit" class="btn btn-sm btn-outline-success">Unblock</button>
                            </form>
                        <?php else: ?>
                            <form method="post" action="<?= esc(url_for('admin/actions/card-status.php')) ?>" class="d-inline"
                                  onsubmit="return confirm('Block this card?');">
                                <input type="hidden" name="card_id" value="<?= $cid ?>">
                                <input type="hidden" name="action" value="block">
                                <button type="submit" class="btn btn-sm btn-outline-warning">Block</button>
                            </form>
                        <?php endif; ?>
                        <form method="post" action="<?= esc(url_for('admin/actions/card-delete.php')) ?>" class="d-inline"
                              onsubmit="return confirm('Delete this card permanently?');">
                            <input type="hidden" name="card_id" value="<?= $cid ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (count($rows) === 0): ?>
                <tr><td colspan="8" class="text-muted p-4">No cards yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/partials/layout-end.php'; ?>
