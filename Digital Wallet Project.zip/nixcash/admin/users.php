<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';
if (strlen($q) > 200) {
    $q = substr($q, 0, 200);
}

$sql = 'SELECT u.user_id, u.name, u.email, u.role, u.status, u.created_at, COALESCE(w.balance, 0) AS balance
        FROM users u
        LEFT JOIN wallets w ON w.user_id = u.user_id';
$args = [];
if ($q !== '') {
    $sql .= ' WHERE INSTR(LOWER(u.name), LOWER(?)) > 0 OR INSTR(LOWER(u.email), LOWER(?)) > 0';
    $args[] = $q;
    $args[] = $q;
}
$sql .= ' ORDER BY u.created_at DESC LIMIT 200';

$st = $pdo->prepare($sql);
$st->execute($args);
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Users';
$adminNav = 'users';
require __DIR__ . '/partials/layout-start.php';
?>
<div class="nix-admin-stat-card p-3 bg-body mb-4">
    <form class="row g-2 align-items-end" method="get" action="">
        <div class="col-md-6">
            <label class="form-label small text-muted mb-1">Search by name or email</label>
            <input type="text" name="q" class="form-control" placeholder="Search…" value="<?= esc($q) ?>">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($q !== ''): ?>
                <a class="btn btn-outline-secondary" href="<?= esc(url_for('admin/users.php')) ?>">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="nix-admin-stat-card bg-body">
    <div class="table-responsive nix-admin-table-wrap">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th class="text-end">Balance</th>
                <th>Role</th>
                <th>Status</th>
                <th>Joined</th>
                <th class="text-end">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <?php
                $rid = (int) $r['user_id'];
                $isSelf = $rid === current_user_id();
                ?>
                <tr>
                    <td><?= $rid ?></td>
                    <td class="fw-medium"><?= esc($r['name']) ?></td>
                    <td class="small"><?= esc($r['email']) ?></td>
                    <td class="text-end">Rs. <?= esc(format_money((float) $r['balance'])) ?></td>
                    <td><span class="badge bg-secondary"><?= esc($r['role']) ?></span></td>
                    <td>
                        <?php if (($r['status'] ?? 'active') === 'blocked'): ?>
                            <span class="badge text-bg-danger">Blocked</span>
                        <?php else: ?>
                            <span class="badge text-bg-success">Active</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted small"><?= esc(date('Y-m-d', strtotime((string) $r['created_at']))) ?></td>
                    <td class="text-end text-nowrap">
                        <?php if (!$isSelf): ?>
                            <?php if (($r['status'] ?? 'active') === 'blocked'): ?>
                                <form method="post" action="<?= esc(url_for('admin/actions/user-status.php')) ?>" class="d-inline">
                                    <input type="hidden" name="user_id" value="<?= $rid ?>">
                                    <input type="hidden" name="action" value="unblock">
                                    <button type="submit" class="btn btn-sm btn-outline-success">Unblock</button>
                                </form>
                            <?php else: ?>
                                <form method="post" action="<?= esc(url_for('admin/actions/user-status.php')) ?>" class="d-inline"
                                      onsubmit="return confirm('Block this user?');">
                                    <input type="hidden" name="user_id" value="<?= $rid ?>">
                                    <input type="hidden" name="action" value="block">
                                    <button type="submit" class="btn btn-sm btn-outline-warning">Block</button>
                                </form>
                            <?php endif; ?>
                            <form method="post" action="<?= esc(url_for('admin/actions/user-delete.php')) ?>" class="d-inline"
                                  onsubmit="return confirm('Permanently delete this user and all related data?');">
                                <input type="hidden" name="user_id" value="<?= $rid ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted small">You</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (count($rows) === 0): ?>
                <tr><td colspan="8" class="text-muted p-4">No users found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/partials/layout-end.php'; ?>
