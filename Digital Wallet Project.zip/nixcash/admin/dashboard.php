<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$totalUsers = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$totalTx = (int) $pdo->query('SELECT COUNT(*) FROM transactions')->fetchColumn();
$totalBal = (float) $pdo->query('SELECT COALESCE(SUM(balance), 0) FROM wallets')->fetchColumn();
$activeCards = (int) $pdo->query(
    "SELECT COUNT(*) FROM virtual_cards WHERE COALESCE(status, 'active') = 'active'"
)->fetchColumn();
$pendingSplits = (int) $pdo->query(
    "SELECT COUNT(*) FROM split_bills WHERE status IN ('pending','partial')"
)->fetchColumn();
$pendingLoans = (int) $pdo->query(
    "SELECT COUNT(*) FROM loan_applications WHERE status = 'pending'"
)->fetchColumn();
$loanQueue = $pdo->query(
    'SELECT l.loan_id, l.amount, l.created_at, u.name AS user_name, u.email AS user_email
     FROM loan_applications l
     INNER JOIN users u ON u.user_id = l.user_id
     WHERE l.status = \'pending\'
     ORDER BY l.created_at ASC
     LIMIT 8'
)->fetchAll(PDO::FETCH_ASSOC);

$usersGrowth = $pdo->query(
    "SELECT DATE(created_at) AS d, COUNT(*) AS c FROM users
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     GROUP BY DATE(created_at) ORDER BY d ASC"
)->fetchAll(PDO::FETCH_ASSOC);

$txGrowth = $pdo->query(
    "SELECT DATE(created_at) AS d, COUNT(*) AS c FROM transactions
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     GROUP BY DATE(created_at) ORDER BY d ASC"
)->fetchAll(PDO::FETCH_ASSOC);

$recentTx = $pdo->query(
    'SELECT t.transaction_id, t.amount, t.type, t.description, t.created_at, t.admin_flagged,
            us.name AS sender_name, ur.name AS recv_name
     FROM transactions t
     LEFT JOIN users us ON us.user_id = t.sender_id
     LEFT JOIN users ur ON ur.user_id = t.receiver_id
     ORDER BY t.created_at DESC LIMIT 12'
)->fetchAll(PDO::FETCH_ASSOC);

$recentUsers = $pdo->query(
    'SELECT user_id, name, email, created_at FROM users ORDER BY created_at DESC LIMIT 6'
)->fetchAll(PDO::FETCH_ASSOC);

$today = new DateTimeImmutable('today');
$uMap = [];
foreach ($usersGrowth as $row) {
    $uMap[(string) $row['d']] = (int) $row['c'];
}
$xMap = [];
foreach ($txGrowth as $row) {
    $xMap[(string) $row['d']] = (int) $row['c'];
}

// Build daily series (new users/transactions per day) for the charts
$userSeries = [];
$txSeries = [];

for ($i = 29; $i >= 0; $i--) {
    $key = $today->modify("-{$i} days")->format('Y-m-d');
    $userSeries[] = $uMap[$key] ?? 0;
    $txSeries[] = $xMap[$key] ?? 0;
}
$chartLabels = [];
for ($i = 29; $i >= 0; $i--) {
    $chartLabels[] = $today->modify("-{$i} days")->format('M j');
}

$pageTitle = 'Dashboard';
$adminNav = 'dashboard';

require __DIR__ . '/partials/layout-start.php';
?>
<div class="row g-3 mb-4">
    <div class="col-6 col-xl-3">
        <div class="nix-admin-stat-card p-3 bg-body">
            <div class="text-muted small">Total users</div>
            <div class="fs-3 fw-bold"><?= number_format($totalUsers) ?></div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="nix-admin-stat-card p-3 bg-body">
            <div class="text-muted small">Transactions</div>
            <div class="fs-3 fw-bold"><?= number_format($totalTx) ?></div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="nix-admin-stat-card p-3 bg-body">
            <div class="text-muted small">Wallet balance (sum)</div>
            <div class="fs-3 fw-bold">Rs. <?= esc(format_money($totalBal)) ?></div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="nix-admin-stat-card p-3 bg-body">
            <div class="text-muted small">Active cards</div>
            <div class="fs-3 fw-bold"><?= number_format($activeCards) ?></div>
            <div class="text-muted small">Pending splits: <?= number_format($pendingSplits) ?></div>
        </div>
    </div>
</div>

<?php if ($pendingLoans > 0): ?>
<div class="alert alert-warning d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <div>
        <strong><?= (int) $pendingLoans ?> loan request<?= $pendingLoans === 1 ? '' : 's' ?></strong> waiting for review.
    </div>
    <a class="btn btn-sm btn-dark" href="<?= esc(url_for('admin/loans.php')) ?>">Review loans</a>
</div>
<?php endif; ?>

<?php if (count($loanQueue) > 0): ?>
<div class="nix-admin-stat-card p-3 bg-body mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="h6 mb-0">Pending loans</h2>
        <a class="btn btn-sm btn-outline-primary" href="<?= esc(url_for('admin/loans.php')) ?>">Open loans</a>
    </div>
    <div class="table-responsive nix-admin-table-wrap">
        <table class="table table-sm align-middle mb-0">
            <thead class="table-light">
            <tr><th>Applicant</th><th class="text-end">Amount</th><th class="text-end">Action</th></tr>
            </thead>
            <tbody>
            <?php foreach ($loanQueue as $lq): ?>
                <tr>
                    <td>
                        <div class="fw-medium"><?= esc((string) $lq['user_name']) ?></div>
                        <div class="text-muted small"><?= esc((string) $lq['user_email']) ?></div>
                    </td>
                    <td class="text-end fw-medium">Rs. <?= esc(format_money((float) $lq['amount'])) ?></td>
                    <td class="text-end">
                        <form method="post" action="<?= esc(url_for('admin/actions/loan-review.php')) ?>" class="d-inline">
                            <input type="hidden" name="loan_id" value="<?= (int) $lq['loan_id'] ?>">
                            <input type="hidden" name="action" value="approve">
                            <button type="submit" class="btn btn-sm btn-success">Approve</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<div class="row g-4 mb-4">
    <div class="col-lg-6">
        <div class="nix-admin-stat-card p-3 bg-body h-100">
            <h2 class="h6 mb-3">Daily New Users (Last 30 Days)</h2>
            <div class="nix-chart-container">
                <?php
                $maxUsersDaily = max($userSeries) ?: 1;
                $userBars = [];
                for ($i = 0; $i < 30; $i++) {
                    $count = $userSeries[$i] ?? 0;
                    $height = $maxUsersDaily > 0 ? ($count / $maxUsersDaily) * 100 : 0;
                    $label = $chartLabels[$i] ?? '';
                    $showNumber = $count > 0 && $height > 15;
                    $userBars[] = ['height' => $height, 'count' => $count, 'label' => $label, 'showNumber' => $showNumber];
                }
                $ySteps = 4;
                ?>
                <div class="nix-chart-y-axis">
                    <?php for ($i = $ySteps; $i >= 0; $i--): ?>
                        <span><?= round($maxUsersDaily * ($i / $ySteps)) ?></span>
                    <?php endfor; ?>
                </div>
                <div class="nix-chart-grid">
                    <?php for ($i = 1; $i < $ySteps; $i++): ?>
                        <div class="nix-grid-line" style="bottom: <?= ($i / $ySteps) * 100 ?>%"></div>
                    <?php endfor; ?>
                </div>
                <div class="nix-chart-area">
                    <div class="nix-bars">
                        <?php foreach ($userBars as $bar): ?>
                            <div class="nix-bar-wrapper <?= $bar['showNumber'] ? 'always-show' : '' ?>" title="<?= esc($bar['label']) ?>: <?= $bar['count'] ?> users">
                                <span class="nix-bar-count"><?= $bar['count'] > 0 ? $bar['count'] : '' ?></span>
                                <div class="nix-bar nix-bar-users" style="height: <?= $bar['height'] ?>%" data-count="<?= $bar['count'] > 0 ? $bar['count'] : '' ?>"></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="nix-chart-labels">
                    <?php foreach ([0, 7, 14, 21, 29] as $idx): ?>
                        <span><?= esc($chartLabels[$idx] ?? '') ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="nix-admin-stat-card p-3 bg-body h-100">
            <h2 class="h6 mb-3">Daily Transactions (Last 30 Days)</h2>
            <div class="nix-chart-container">
                <?php
                $maxTxDaily = max($txSeries) ?: 1;
                $txBars = [];
                for ($i = 0; $i < 30; $i++) {
                    $count = $txSeries[$i] ?? 0;
                    $height = $maxTxDaily > 0 ? ($count / $maxTxDaily) * 100 : 0;
                    $label = $chartLabels[$i] ?? '';
                    $showNumber = $count > 0 && $height > 15;
                    $txBars[] = ['height' => $height, 'count' => $count, 'label' => $label, 'showNumber' => $showNumber];
                }
                ?>
                <div class="nix-chart-y-axis">
                    <?php for ($i = $ySteps; $i >= 0; $i--): ?>
                        <span><?= round($maxTxDaily * ($i / $ySteps)) ?></span>
                    <?php endfor; ?>
                </div>
                <div class="nix-chart-grid">
                    <?php for ($i = 1; $i < $ySteps; $i++): ?>
                        <div class="nix-grid-line" style="bottom: <?= ($i / $ySteps) * 100 ?>%"></div>
                    <?php endfor; ?>
                </div>
                <div class="nix-chart-area">
                    <div class="nix-bars">
                        <?php foreach ($txBars as $bar): ?>
                            <div class="nix-bar-wrapper <?= $bar['showNumber'] ? 'always-show' : '' ?>" title="<?= esc($bar['label']) ?>: <?= $bar['count'] ?> transactions">
                                <span class="nix-bar-count"><?= $bar['count'] > 0 ? $bar['count'] : '' ?></span>
                                <div class="nix-bar nix-bar-tx" style="height: <?= $bar['height'] ?>%" data-count="<?= $bar['count'] > 0 ? $bar['count'] : '' ?>"></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="nix-chart-labels">
                    <?php foreach ([0, 7, 14, 21, 29] as $idx): ?>
                        <span><?= esc($chartLabels[$idx] ?? '') ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="nix-admin-stat-card p-3 bg-body">
            <h2 class="h6 mb-3">Recent transactions</h2>
            <div class="table-responsive nix-admin-table-wrap">
                <table class="table table-sm table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th>When</th>
                        <th>Type</th>
                        <th>Parties</th>
                        <th class="text-end">Amount</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recentTx as $t): ?>
                        <tr class="<?= !empty($t['admin_flagged']) ? 'table-warning' : '' ?>">
                            <td class="text-muted small"><?= esc(date('M j, H:i', strtotime((string) $t['created_at']))) ?></td>
                            <td><?= esc($t['type']) ?><?= !empty($t['admin_flagged']) ? ' <span class="badge text-bg-warning nix-admin-badge-flag">Flagged</span>' : '' ?></td>
                            <td class="small"><?= esc(trim(($t['sender_name'] ?? '—') . ' → ' . ($t['recv_name'] ?? '—'))) ?></td>
                            <td class="text-end fw-medium">Rs. <?= esc(format_money((float) $t['amount'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (count($recentTx) === 0): ?>
                        <tr><td colspan="4" class="text-muted small">No transactions yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <a class="btn btn-sm btn-outline-primary mt-3" href="<?= esc(url_for('admin/transactions.php')) ?>">Manage transactions</a>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="nix-admin-stat-card p-3 bg-body mb-3">
            <h2 class="h6 mb-3">New accounts</h2>
            <ul class="list-group list-group-flush">
                <?php foreach ($recentUsers as $u): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center px-0 bg-transparent">
                        <div>
                            <div class="fw-medium"><?= esc($u['name']) ?></div>
                            <div class="text-muted small"><?= esc($u['email']) ?></div>
                        </div>
                        <span class="text-muted small"><?= esc(date('M j', strtotime((string) $u['created_at']))) ?></span>
                    </li>
                <?php endforeach; ?>
                <?php if (count($recentUsers) === 0): ?>
                    <li class="list-group-item px-0 bg-transparent text-muted small">No users.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<?php
ob_start();
?>
<style>
.nix-chart-container { height: 220px; display: flex; flex-direction: column; position: relative; }
.nix-chart-y-axis { position: absolute; left: 0; top: 0; bottom: 30px; width: 30px; display: flex; flex-direction: column; justify-content: space-between; align-items: flex-end; padding-right: 5px; font-size: 10px; color: #9ca3af; border-right: 1px solid #e5e7eb; }
.nix-chart-area { margin-left: 35px; flex: 1; display: flex; flex-direction: column; }
.nix-bars { display: flex; align-items: flex-end; justify-content: space-between; flex: 1; gap: 3px; padding: 10px 0; border-bottom: 1px solid #e5e7eb; }
.nix-bar-wrapper { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; height: 100%; cursor: pointer; position: relative; }
.nix-bar-count { font-size: 9px; font-weight: 600; color: #374151; margin-bottom: 3px; opacity: 0; transition: opacity 0.2s; }
.nix-bar-wrapper:hover .nix-bar-count { opacity: 1; }
.nix-bar-wrapper.always-show .nix-bar-count { opacity: 1; }
.nix-bar { width: 100%; border-radius: 4px 4px 0 0; transition: all 0.2s; min-height: 3px; position: relative; }
.nix-bar::after { content: attr(data-count); position: absolute; top: -16px; left: 50%; transform: translateX(-50%); font-size: 9px; font-weight: 700; color: #374151; white-space: nowrap; }
.nix-bar:hover { opacity: 0.85; transform: scaleX(1.1); }
.nix-bar-users { background: linear-gradient(180deg, #818cf8 0%, #6366f1 100%); box-shadow: 0 2px 8px rgba(99, 102, 241, 0.3); }
.nix-bar-tx { background: linear-gradient(180deg, #38bdf8 0%, #0ea5e9 100%); box-shadow: 0 2px 8px rgba(14, 165, 233, 0.3); }
.nix-chart-labels { display: flex; justify-content: space-between; font-size: 10px; color: #6b7280; padding-top: 8px; margin-left: 35px; }
.nix-chart-grid { position: absolute; left: 35px; right: 0; top: 10px; bottom: 30px; pointer-events: none; }
.nix-grid-line { border-top: 1px dashed #e5e7eb; position: absolute; left: 0; right: 0; }
</style>
<?php
$adminExtraScripts = ob_get_clean();
require __DIR__ . '/partials/layout-end.php';
