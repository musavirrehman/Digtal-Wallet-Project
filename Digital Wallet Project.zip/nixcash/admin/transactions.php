<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$dateFrom = isset($_GET['date_from']) ? trim((string) $_GET['date_from']) : '';
$dateTo = isset($_GET['date_to']) ? trim((string) $_GET['date_to']) : '';
$filterUser = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;
$filterType = isset($_GET['type']) ? trim((string) $_GET['type']) : '';
if (strlen($filterType) > 32) {
    $filterType = substr($filterType, 0, 32);
}

$sql = 'SELECT t.*, us.name AS sender_name, ur.name AS recv_name, us.email AS sender_email, ur.email AS recv_email
        FROM transactions t
        LEFT JOIN users us ON us.user_id = t.sender_id
        LEFT JOIN users ur ON ur.user_id = t.receiver_id
        WHERE 1=1';
$args = [];
if ($dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
    $sql .= ' AND DATE(t.created_at) >= ?';
    $args[] = $dateFrom;
}
if ($dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
    $sql .= ' AND DATE(t.created_at) <= ?';
    $args[] = $dateTo;
}
if ($filterUser > 0) {
    $sql .= ' AND (t.sender_id = ? OR t.receiver_id = ?)';
    $args[] = $filterUser;
    $args[] = $filterUser;
}
if ($filterType !== '') {
    $sql .= ' AND t.type = ?';
    $args[] = $filterType;
}
$sql .= ' ORDER BY t.created_at DESC LIMIT 300';

$st = $pdo->prepare($sql);
$st->execute($args);
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

$types = $pdo->query('SELECT DISTINCT type FROM transactions ORDER BY type ASC')->fetchAll(PDO::FETCH_COLUMN);
$usersList = $pdo->query('SELECT user_id, name, email FROM users ORDER BY name ASC LIMIT 500')->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Transactions';
$adminNav = 'transactions';
require __DIR__ . '/partials/layout-start.php';
?>
<div class="nix-admin-stat-card p-3 bg-body mb-4">
    <form class="row g-2 align-items-end" method="get" action="">
        <div class="col-6 col-md-2">
            <label class="form-label small text-muted mb-0">From</label>
            <input type="date" name="date_from" class="form-control form-control-sm" value="<?= esc($dateFrom) ?>">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small text-muted mb-0">To</label>
            <input type="date" name="date_to" class="form-control form-control-sm" value="<?= esc($dateTo) ?>">
        </div>
        <div class="col-md-3">
            <label class="form-label small text-muted mb-0">User</label>
            <select name="user_id" class="form-select form-select-sm">
                <option value="0">All users</option>
                <?php foreach ($usersList as $u): ?>
                    <option value="<?= (int) $u['user_id'] ?>" <?= $filterUser === (int) $u['user_id'] ? 'selected' : '' ?>>
                        <?= esc($u['name'] . ' — ' . $u['email']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <label class="form-label small text-muted mb-0">Type</label>
            <select name="type" class="form-select form-select-sm">
                <option value="">All</option>
                <?php foreach ($types as $tp): ?>
                    <option value="<?= esc((string) $tp) ?>" <?= $filterType === (string) $tp ? 'selected' : '' ?>><?= esc((string) $tp) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
            <a class="btn btn-sm btn-outline-secondary" href="<?= esc(url_for('admin/transactions.php')) ?>">Reset</a>
        </div>
    </form>
</div>

<div class="nix-admin-stat-card bg-body">
    <div class="table-responsive nix-admin-table-wrap">
        <table class="table table-sm table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>When</th>
                <th>Type</th>
                <th>From</th>
                <th>To</th>
                <th class="text-end">Amount</th>
                <th>Flag</th>
                <th class="text-end">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $t): ?>
                <?php $tid = (int) $t['transaction_id']; ?>
                <tr class="<?= !empty($t['admin_flagged']) ? 'table-warning' : '' ?>">
                    <td><?= $tid ?></td>
                    <td class="text-muted small"><?= esc(date('Y-m-d H:i', strtotime((string) $t['created_at']))) ?></td>
                    <td><?= esc($t['type']) ?></td>
                    <td class="small"><?= esc($t['sender_name'] ?? '—') ?></td>
                    <td class="small"><?= esc($t['recv_name'] ?? '—') ?></td>
                    <td class="text-end">Rs. <?= esc(format_money((float) $t['amount'])) ?></td>
                    <td>
                        <?php if (!empty($t['admin_flagged'])): ?>
                            <span class="badge text-bg-warning">Flagged</span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end text-nowrap">
                        <form method="post" action="<?= esc(url_for('admin/actions/transaction-flag.php')) ?>" class="d-inline">
                            <input type="hidden" name="transaction_id" value="<?= $tid ?>">
                            <input type="hidden" name="flag" value="<?= !empty($t['admin_flagged']) ? '0' : '1' ?>">
                            <button type="submit" class="btn btn-sm btn-outline-secondary">
                                <?= !empty($t['admin_flagged']) ? 'Unflag' : 'Flag' ?>
                            </button>
                        </form>
                        <form method="post" action="<?= esc(url_for('admin/actions/transaction-delete.php')) ?>" class="d-inline"
                              onsubmit="return confirm('Delete this transaction row? Wallet balances will NOT be recalculated.');">
                            <input type="hidden" name="transaction_id" value="<?= $tid ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (count($rows) === 0): ?>
                <tr><td colspan="8" class="text-muted p-4">No transactions match.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/partials/layout-end.php'; ?>
