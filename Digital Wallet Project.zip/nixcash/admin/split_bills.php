<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$rows = $pdo->query(
    'SELECT b.*, u.name AS creator_name, u.email AS creator_email,
            (SELECT COUNT(*) FROM split_bill_members m WHERE m.bill_id = b.bill_id) AS member_count,
            (SELECT COUNT(*) FROM split_bill_members m WHERE m.bill_id = b.bill_id AND m.paid_status = 1) AS paid_count
     FROM split_bills b
     INNER JOIN users u ON u.user_id = b.created_by
     ORDER BY b.created_at DESC LIMIT 200'
)->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Split bills';
$adminNav = 'split_bills';
require __DIR__ . '/partials/layout-start.php';
?>
<div class="nix-admin-stat-card bg-body">
    <div class="table-responsive nix-admin-table-wrap">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Creator</th>
                <th class="text-end">Total</th>
                <th>Bill status</th>
                <th>Paid / members</th>
                <th>Created</th>
                <th class="text-end">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $b): ?>
                <?php $bid = (int) $b['bill_id']; ?>
                <tr>
                    <td><?= $bid ?></td>
                    <td class="fw-medium"><?= esc($b['title']) ?></td>
                    <td>
                        <div><?= esc($b['creator_name']) ?></div>
                        <div class="text-muted small"><?= esc($b['creator_email']) ?></div>
                    </td>
                    <td class="text-end">Rs. <?= esc(format_money((float) $b['total_amount'])) ?></td>
                    <td><span class="badge bg-secondary"><?= esc($b['status']) ?></span></td>
                    <td class="small"><?= (int) $b['paid_count'] ?> / <?= (int) $b['member_count'] ?> paid</td>
                    <td class="text-muted small"><?= esc(date('Y-m-d', strtotime((string) $b['created_at']))) ?></td>
                    <td class="text-end">
                        <form method="post" action="<?= esc(url_for('admin/actions/split-delete.php')) ?>" class="d-inline"
                              onsubmit="return confirm('Remove this split bill and all member rows?');">
                            <input type="hidden" name="bill_id" value="<?= $bid ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (count($rows) === 0): ?>
                <tr><td colspan="8" class="text-muted p-4">No split bills.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/partials/layout-end.php'; ?>
