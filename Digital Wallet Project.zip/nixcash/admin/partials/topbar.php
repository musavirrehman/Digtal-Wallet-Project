<?php
declare(strict_types=1);
$f = get_flash();
?>
<header class="nix-admin-topbar py-3 px-3 px-md-4 d-flex flex-wrap align-items-center justify-content-between gap-2">
    <div class="d-flex align-items-center gap-3">
        <button class="btn btn-outline-secondary d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#nixAdminMenu" aria-label="Open menu">
            <i class="bi bi-list"></i>
        </button>
        <h1 class="h5 mb-0 fw-semibold"><?= esc($pageTitle ?? 'Admin') ?></h1>
    </div>
    <div class="d-flex align-items-center gap-2">
        <span class="text-muted small d-none d-sm-inline"><?= esc($_SESSION['user_name'] ?? 'Admin') ?></span>
        <a class="btn btn-outline-secondary btn-sm" href="<?= esc(url_for('logout.php')) ?>"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
    </div>
</header>
<?php if ($f): ?>
    <?php
    $ft = (string) ($f['type'] ?? 'info');
    if ($ft === 'success') {
        $flashClass = 'success';
    } elseif ($ft === 'warning') {
        $flashClass = 'warning';
    } elseif ($ft === 'danger' || $ft === 'error') {
        $flashClass = 'danger';
    } else {
        $flashClass = 'info';
    }
    ?>
    <div class="px-3 px-md-4">
        <div class="alert alert-<?= esc($flashClass) ?> py-2 mb-0 small"><?= esc($f['message']) ?></div>
    </div>
<?php endif; ?>

<div class="offcanvas offcanvas-start d-md-none text-bg-dark" tabindex="-1" id="nixAdminMenu">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Menu</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body p-0">
        <nav class="nav flex-column px-2">
            <a class="nav-link text-white-50" href="<?= esc(url_for('admin/dashboard.php')) ?>">Dashboard</a>
            <a class="nav-link text-white-50" href="<?= esc(url_for('admin/users.php')) ?>">Users</a>
            <a class="nav-link text-white-50" href="<?= esc(url_for('admin/transactions.php')) ?>">Transactions</a>
            <a class="nav-link text-white-50" href="<?= esc(url_for('admin/cards.php')) ?>">Cards</a>
            <a class="nav-link text-white-50" href="<?= esc(url_for('admin/goals.php')) ?>">Goals</a>
            <a class="nav-link text-white-50" href="<?= esc(url_for('admin/split_bills.php')) ?>">Split bills</a>
            <a class="nav-link text-white-50" href="<?= esc(url_for('admin/loans.php')) ?>">Loans</a>
            <a class="nav-link text-white-50" href="<?= esc(url_for('admin/settings.php')) ?>">Settings</a>
            <hr class="border-secondary">
            <a class="nav-link text-white-50" href="<?= esc(url_for('index.php')) ?>">User app</a>
        </nav>
    </div>
</div>
