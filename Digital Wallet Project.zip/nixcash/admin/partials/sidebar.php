<?php
declare(strict_types=1);
$nav = static function (string $id, string $href, string $icon, string $label) use ($adminNav): void {
    $active = $adminNav === $id ? ' active' : '';
    ?>
    <a class="nav-link<?= $active ?>" href="<?= esc(url_for($href)) ?>">
        <i class="bi <?= esc($icon) ?> me-2"></i><?= esc($label) ?>
    </a>
    <?php
};
?>
<aside class="nix-admin-sidebar p-3 d-none d-md-block">
    <div class="brand fs-5 text-white mb-4 px-2">NixCash <span class="text-primary" style="color:var(--nix-admin-accent)!important;">Admin</span></div>
    <nav class="nav flex-column small">
        <?php $nav('dashboard', 'admin/dashboard.php', 'bi-speedometer2', 'Dashboard'); ?>
        <?php $nav('users', 'admin/users.php', 'bi-people', 'Users'); ?>
        <?php $nav('transactions', 'admin/transactions.php', 'bi-arrow-left-right', 'Transactions'); ?>
        <?php $nav('cards', 'admin/cards.php', 'bi-credit-card-2-front', 'Cards'); ?>
        <?php $nav('goals', 'admin/goals.php', 'bi-bullseye', 'Goals'); ?>
        <?php $nav('split_bills', 'admin/split_bills.php', 'bi-receipt', 'Split bills'); ?>
        <?php $nav('loans', 'admin/loans.php', 'bi-bank', 'Loans'); ?>
        <?php $nav('settings', 'admin/settings.php', 'bi-gear', 'Settings'); ?>
    </nav>
    <hr class="border-secondary my-4">
    <a class="nav-link text-secondary" href="<?= esc(url_for('index.php')) ?>">
        <i class="bi bi-wallet2 me-2"></i>User app
    </a>
</aside>
