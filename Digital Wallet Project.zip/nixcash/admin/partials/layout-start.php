<?php
declare(strict_types=1);
$pageTitle = $pageTitle ?? 'Admin';
$adminNav = $adminNav ?? '';
$adminExtraScripts = $adminExtraScripts ?? '';
$nixAdminCss = dirname(__DIR__, 2) . '/assets/css/admin.css';
$nixAdminCssVer = is_file($nixAdminCss) ? (int) filemtime($nixAdminCss) : time();
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($pageTitle) ?> — NixCash Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= esc(url_for('assets/css/admin.css')) ?>?v=<?= $nixAdminCssVer ?>">
</head>
<body class="nix-admin-body">
<div class="d-flex flex-column flex-md-row w-100">
<?php require __DIR__ . '/sidebar.php'; ?>
<div class="nix-admin-main d-flex flex-column min-vh-100 w-100">
<?php require __DIR__ . '/topbar.php'; ?>
<main class="flex-grow-1 p-3 p-md-4">
