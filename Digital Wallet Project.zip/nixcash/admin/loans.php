<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$pageTitle = 'Loans';
$adminNav = 'loans';

$rows = $pdo->query(
    'SELECT l.loan_id, l.amount, l.note, l.status, l.created_at, l.reviewed_at,
            l.approved_at, l.due_date, l.remaining_amount, l.penalty_applied,
            u.name AS user_name, u.email AS user_email,
            a.name AS reviewer_name
     FROM loan_applications l
     INNER JOIN users u ON u.user_id = l.user_id
     LEFT JOIN users a ON a.user_id = l.reviewed_by
     ORDER BY l.status = \'pending\' DESC, l.created_at DESC'
)->fetchAll(PDO::FETCH_ASSOC);

require __DIR__ . '/partials/layout-start.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4 mb-0">Loan applications</h1>
    <?php
    $pendingLoanCount = 0;
    foreach ($rows as $__r) {
        if (($__r['status'] ?? '') === 'pending') {
            ++$pendingLoanCount;
        }
    }
    ?>
    <span class="badge text-bg-warning"><?= (int) $pendingLoanCount ?> pending</span>
        <span class="badge text-bg-success">
            <?php
            $approvedCount = 0;
            foreach ($rows as $__r) {
                if (($__r['status'] ?? '') === 'approved') {
                    ++$approvedCount;
                }
            }
            echo $approvedCount;
            ?> active
        </span>
</div>

<div class="nix-admin-stat-card p-3 bg-body">
    <div class="table-responsive nix-admin-table-wrap">
        <table class="table table-sm table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>When</th>
                <th>User</th>
                <th class="text-end">Amount</th>
                <th>Note</th>
                <th>Status</th>
                <th class="text-end">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="text-muted small"><?= esc(date('M j, H:i', strtotime((string) $r['created_at']))) ?></td>
                    <td>
                        <div class="fw-medium"><?= esc((string) $r['user_name']) ?></div>
                        <div class="text-muted small"><?= esc((string) $r['user_email']) ?></div>
                    </td>
                    <td class="text-end fw-medium">Rs. <?= esc(format_money((float) $r['amount'])) ?></td>
                    <td class="small text-muted"><?= esc((string) ($r['note'] ?? '')) ?></td>
                    <td>
                                            <?php
                                            $status = $r['status'] ?? '';
                                            $badgeClass = $status === 'approved' ? 'success' : ($status === 'rejected' ? 'danger' : ($status === 'repaid' ? 'info' : 'warning'));
                                            ?>
                                            <span class="badge text-bg-<?= $badgeClass ?>"><?= esc((string) $status) ?></span>
                                            <?php if ($status === 'approved' && !empty($r['due_date'])): ?>
                                                <?php $isLate = strtotime($r['due_date']) < time(); ?>
                                                <div class="small mt-1 <?= $isLate ? 'text-danger' : 'text-muted' ?>">
                                                    Due: <?= esc(date('M j, Y', strtotime((string) $r['due_date']))) ?>
                                                    <?php if ($isLate): ?>
                                                        <span class="badge bg-danger">OVERDUE</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="small text-muted">Remaining: Rs. <?= esc(format_money((float) ($r['remaining_amount'] ?? $r['amount']))) ?></div>
                                            <?php endif; ?>
                                        </td>
                    <td class="text-end">
                        <?php if (($r['status'] ?? '') === 'pending'): ?>
                            <form method="post" action="<?= esc(url_for('admin/actions/loan-review.php')) ?>" class="d-inline">
                                <input type="hidden" name="loan_id" value="<?= (int) $r['loan_id'] ?>">
                                <input type="hidden" name="action" value="approve">
                                <button type="submit" class="btn btn-sm btn-success">Approve</button>
                            </form>
                            <form method="post" action="<?= esc(url_for('admin/actions/loan-review.php')) ?>" class="d-inline ms-1">
                                <input type="hidden" name="loan_id" value="<?= (int) $r['loan_id'] ?>">
                                <input type="hidden" name="action" value="reject">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Reject</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted small"><?= esc((string) ($r['reviewer_name'] ?? '—')) ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (count($rows) === 0): ?>
                <tr><td colspan="6" class="text-muted small">No loan applications.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/partials/layout-end.php'; ?>
