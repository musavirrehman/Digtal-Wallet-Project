<?php
/**
 * JSON: suggest users by email or name (for send-money autocomplete).
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/config/database.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['users' => []]);
    exit;
}

require_login();

$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';
if (strlen($q) < 2) {
    echo json_encode(['users' => []]);
    exit;
}

$uid = current_user_id();
$rbac = nixcash_users_table_has_rbac_columns($pdo);
$statusSql = $rbac ? ' AND (status = \'active\' OR status IS NULL)' : '';
$st = $pdo->prepare(
    "SELECT email, name FROM users
     WHERE user_id != ?{$statusSql}
       AND (INSTR(LOWER(email), LOWER(?)) > 0 OR INSTR(LOWER(name), LOWER(?)) > 0)
     ORDER BY email ASC
     LIMIT 10"
);
$st->execute([$uid, $q, $q]);
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['users' => $rows], JSON_UNESCAPED_UNICODE);
