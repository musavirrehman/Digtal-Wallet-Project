<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

if (current_user_id() !== null) {
    nixcash_refresh_user_role_session($pdo);
    if (current_user_role() === 'admin' && nixcash_is_primary_admin_identity($_SESSION['user_name'] ?? null, $_SESSION['user_email'] ?? null)) {
        redirect('admin/dashboard.php');
    }
    redirect('index.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = post_email('email');
    $pass = isset($_POST['password']) ? (string) $_POST['password'] : '';

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } elseif ($pass === '') {
        $error = 'Enter your password.';
    } else {
        $hasRbac = nixcash_users_table_has_rbac_columns($pdo);
        $sql = $hasRbac
            ? 'SELECT user_id, name, email, password, role, status FROM users WHERE email = ? LIMIT 1'
            : 'SELECT user_id, name, email, password FROM users WHERE email = ? LIMIT 1';
        $st = $pdo->prepare($sql);
        $st->execute([$email]);
        $row = $st->fetch();
        if (!$row || !password_verify($pass, $row['password'])) {
            $error = 'Invalid email or password.';
        } elseif ($hasRbac && (($row['status'] ?? 'active') === 'blocked')) {
            $error = 'This account has been restricted. Contact support if you need help.';
        } else {
            $role = (!$hasRbac || (($row['role'] ?? 'user') !== 'admin')) ? 'user' : 'admin';
            login_user((int) $row['user_id'], $row['name'], $row['email'], $role);
            set_flash('success', 'Signed in successfully.');
            if ($hasRbac && $role === 'admin' && nixcash_is_primary_admin_identity($row['name'], $row['email'])) {
                redirect('admin/dashboard.php');
            }
            redirect('index.php');
        }
    }
}

$pageTitle = 'Sign in';
$hideBottomNav = true;
require __DIR__ . '/partials/header.php';
?>
<main class="auth-shell px-3">
    <div class="auth-card glass-card p-4 p-md-5">
        <div class="text-center mb-4">
            <div class="nix-logo fs-2 mb-1">NixCash</div>
            <p class="text-muted small mb-0">Welcome back</p>
        </div>
        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?= esc($error) ?></div>
        <?php endif; ?>
        <form method="post" action="" novalidate>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required
                       value="<?= esc(post_email('email')) ?>" autocomplete="email">
            </div>
            <div class="mb-4">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn btn-nix-primary w-100 py-2">Sign in</button>
        </form>
        <p class="text-center text-muted small mt-4 mb-0">
            New here? <a href="<?= esc(url_for('register.php')) ?>" class="link-nix">Create an account</a>
        </p>
    </div>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
